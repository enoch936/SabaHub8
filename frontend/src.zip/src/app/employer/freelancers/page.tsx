"use client";

import { useQuery } from "@tanstack/react-query";
import { Alert, Avatar, Card, CardContent, Chip, Grid, Stack, Typography } from "@mui/material";
import { getPublicProfile, listDirectoryUsers, type UserProfile } from "@/lib/api";

type FreelancerCard = {
  id: string;
  fullName: string;
  username?: string;
  online?: boolean;
  profile?: UserProfile | null;
};

export default function EmployerFreelancersPage() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["employer", "freelancers"],
    queryFn: async () => {
      const directory = await listDirectoryUsers(80);
      const freelancers = directory.users.filter((user) => user.roles?.includes("FREELANCER"));

      const profiles = await Promise.all(
        freelancers.map(async (user) => {
          try {
            const profile = await getPublicProfile(user.id);
            return {
              id: user.id,
              fullName: user.fullName || user.username || "Freelancer",
              username: user.username,
              online: user.online,
              profile,
            } satisfies FreelancerCard;
          } catch {
            return {
              id: user.id,
              fullName: user.fullName || user.username || "Freelancer",
              username: user.username,
              online: user.online,
              profile: null,
            } satisfies FreelancerCard;
          }
        }),
      );

      return profiles;
    },
  });

  if (isLoading) {
    return <Typography>Loading freelancer profiles...</Typography>;
  }

  return (
    <Stack spacing={2.2}>
      <Stack spacing={0.5}>
        <Typography variant="h4" fontWeight={800}>Freelancers</Typography>
        <Typography variant="body2" color="text.secondary">
          Review freelancer profiles, skills, and availability before you hire.
        </Typography>
      </Stack>

      {error ? <Alert severity="error">Unable to load freelancer profiles right now.</Alert> : null}
      {!data?.length ? <Alert severity="info">No freelancer profiles are available yet.</Alert> : null}

      <Grid container spacing={2}>
        {(data || []).map((freelancer) => (
          <Grid key={freelancer.id} size={{ xs: 12, md: 6, xl: 4 }}>
            <Card sx={{ height: "100%" }}>
              <CardContent>
                <Stack spacing={1.25}>
                  <Stack direction="row" spacing={1.2} alignItems="center">
                    <Avatar>{freelancer.fullName.charAt(0).toUpperCase()}</Avatar>
                    <Stack spacing={0.2}>
                      <Typography variant="h6" fontWeight={700}>{freelancer.fullName}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {freelancer.profile?.expertise || freelancer.username || "Freelancer"}
                      </Typography>
                    </Stack>
                    <Chip
                      size="small"
                      label={freelancer.online ? "Online" : "Offline"}
                      color={freelancer.online ? "success" : "default"}
                      sx={{ ml: "auto" }}
                    />
                  </Stack>

                  <Typography variant="body2" color="text.secondary">
                    {freelancer.profile?.bio || "Public freelancer profile available for employer review."}
                  </Typography>

                  <Stack direction="row" spacing={0.75} useFlexGap flexWrap="wrap">
                    {(freelancer.profile?.skills || []).slice(0, 5).map((skill) => (
                      <Chip key={skill} size="small" variant="outlined" label={skill} />
                    ))}
                    {freelancer.profile?.location ? <Chip size="small" variant="outlined" label={freelancer.profile.location} /> : null}
                    {freelancer.profile?.availability ? <Chip size="small" variant="outlined" label={freelancer.profile.availability} /> : null}
                  </Stack>
                </Stack>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Stack>
  );
}
