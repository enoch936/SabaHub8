"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Box,
  CardContent,
  Chip,
  Grid,
  Stack,
  Typography,
} from "@mui/material";
import TimelineRoundedIcon from "@mui/icons-material/TimelineRounded";
import VerifiedRoundedIcon from "@mui/icons-material/VerifiedRounded";
import SoftButton from "@/components/mui/SoftButton";
import SoftCard from "@/components/mui/SoftCard";
import {
  type Contract,
  type Job,
  type WalletSnapshot,
  getWallet,
  listContracts,
  listEmployerJobs,
} from "@/lib/api";
import NoSsrResponsiveContainer from "@/components/charts/NoSsrResponsiveContainer";
import { Bar, BarChart, CartesianGrid, Tooltip, XAxis, YAxis } from "recharts";

const stageBoard = [
  { title: "Brief Submitted", detail: "New briefs ready for proposal intake" },
  { title: "Proposal Review", detail: "Shortlist and evaluate top candidates" },
  { title: "Contract Setup", detail: "Define milestones and release cadence" },
  { title: "Delivery", detail: "Track execution and close acceptance" },
];

export default function EmployerDashboardPage() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [wallet, setWallet] = useState<WalletSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      setError(null);

      const [jobsRes, contractsRes, walletRes] = await Promise.allSettled([
        listEmployerJobs(),
        listContracts(),
        getWallet(),
      ]);

      if (jobsRes.status === "fulfilled") {
        setJobs(Array.isArray(jobsRes.value) ? jobsRes.value : []);
      }
      if (contractsRes.status === "fulfilled") {
        setContracts(Array.isArray(contractsRes.value) ? contractsRes.value : []);
      }
      if (walletRes.status === "fulfilled") {
        setWallet(walletRes.value || null);
      }

      if (jobsRes.status === "rejected" && contractsRes.status === "rejected" && walletRes.status === "rejected") {
        setError("Unable to load employer workspace data.");
      }

      setLoading(false);
    };

    void load();
  }, []);

  const metrics = useMemo(() => {
    const openJobs = jobs.filter((job) => job.status === "OPEN").length;
    const activeContracts = contracts.filter((contract) => contract.status === "ACTIVE").length;
    const completedContracts = contracts.filter((contract) => contract.status === "COMPLETED").length;

    return [
      {
        label: "Open Briefs",
        value: openJobs,
        helper: `${jobs.length} total`,
        gradient: "linear-gradient(135deg, #0b5bd1 0%, #3b82f6 100%)",
      },
      {
        label: "Active Contracts",
        value: activeContracts,
        helper: `${completedContracts} completed`,
        gradient: "linear-gradient(135deg, #22c55e 0%, #84cc16 100%)",
      },
      {
        label: "Escrow Held",
        value: `$${Math.round(wallet?.escrowHeld || 0).toLocaleString()}`,
        helper: `Balance $${Math.round(wallet?.balance || 0).toLocaleString()}`,
        gradient: "linear-gradient(135deg, #f59e0b 0%, #f97316 100%)",
      },
      {
        label: "Pipeline Health",
        value: jobs.length > 0 ? `${Math.round((activeContracts / Math.max(1, jobs.length)) * 100)}%` : "0%",
        helper: "Hiring execution ratio",
        gradient: "linear-gradient(135deg, #0ea5e9 0%, #22d3ee 100%)",
      },
    ];
  }, [contracts, jobs, wallet]);

  const trendData = useMemo(
    () => [
      { lane: "Briefing", value: Math.max(1, jobs.length) },
      { lane: "Review", value: Math.max(1, Math.round(jobs.length * 0.8)) },
      { lane: "Contracting", value: Math.max(1, contracts.length) },
      { lane: "Delivery", value: Math.max(1, Math.round(contracts.length * 0.7)) },
    ],
    [contracts.length, jobs.length],
  );

  return (
    <Stack spacing={2.2}>
      {error ? <Alert severity="error">{error}</Alert> : null}

      <SoftCard
        sx={{
          border: "none",
          color: "common.white",
          background:
            "linear-gradient(120deg, #043873 0%, #0b5bd1 58%, #22d3ee 100%), radial-gradient(900px 280px at 0% 0%, rgba(255,255,255,0.18), transparent 65%)",
        }}
      >
        <CardContent>
          <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" spacing={1.2}>
            <Box>
              <Typography variant="overline" sx={{ opacity: 0.92 }} fontWeight={800}>
                Employer Workspace
              </Typography>
              <Typography variant="h4" fontWeight={900}>
                Hiring & Delivery Command
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.93, maxWidth: 760 }}>
                Structured, static board for posting briefs, reviewing proposals, and managing contract delivery.
              </Typography>
            </Box>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={1}>
              <SoftButton component={Link} href="/employer/post-project" variant="contained" sx={{ bgcolor: "#fff", color: "#043873" }}>
                Post New Brief
              </SoftButton>
              <SoftButton component={Link} href="/employer/proposals" variant="outlined" sx={{ color: "#fff", borderColor: "rgba(255,255,255,0.8)" }}>
                Review Proposals
              </SoftButton>
            </Stack>
          </Stack>
        </CardContent>
      </SoftCard>

      <Grid container spacing={1.25}>
        {metrics.map((item) => (
          <Grid key={item.label} size={{ xs: 12, sm: 6, xl: 3 }}>
            <SoftCard sx={{ border: "none", color: "white", background: item.gradient }}>
              <CardContent>
                <Typography variant="body2" sx={{ opacity: 0.9 }}>
                  {item.label}
                </Typography>
                <Typography variant="h4" fontWeight={900}>
                  {item.value}
                </Typography>
                <Typography variant="caption" sx={{ opacity: 0.88 }}>
                  {item.helper}
                </Typography>
              </CardContent>
            </SoftCard>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <SoftCard sx={{ border: "1px solid", borderColor: "divider" }}>
            <CardContent>
              <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
                <Typography variant="h6" fontWeight={800}>
                  Hiring Pipeline Overview
                </Typography>
                <Chip icon={<TimelineRoundedIcon />} label="Static board" size="small" variant="outlined" />
              </Stack>
              <Box sx={{ height: 260 }}>
                <NoSsrResponsiveContainer fallbackHeight={260}>
                  <BarChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="lane" />
                    <YAxis width={28} />
                    <Tooltip />
                    <Bar dataKey="value" fill="#0b5bd1" radius={[8, 8, 0, 0]} isAnimationActive={false} />
                  </BarChart>
                </NoSsrResponsiveContainer>
              </Box>
            </CardContent>
          </SoftCard>
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <SoftCard sx={{ border: "1px solid", borderColor: "divider", height: "100%" }}>
            <CardContent>
              <Typography variant="h6" fontWeight={800} sx={{ mb: 1.2 }}>
                Delivery Steps
              </Typography>
              <Stack spacing={1}>
                {stageBoard.map((stage, index) => (
                  <Box key={stage.title} sx={{ p: 1, borderRadius: 2, border: "1px solid", borderColor: "divider" }}>
                    <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.2 }}>
                      <Chip size="small" label={index + 1} color={index < 2 ? "success" : "default"} />
                      <Typography variant="subtitle2" fontWeight={800}>
                        {stage.title}
                      </Typography>
                    </Stack>
                    <Typography variant="body2" color="text.secondary">
                      {stage.detail}
                    </Typography>
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </SoftCard>
        </Grid>
      </Grid>

      <SoftCard sx={{ border: "1px solid", borderColor: "divider" }}>
        <CardContent>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.2 }}>
            <Typography variant="h6" fontWeight={800}>
              Recent Briefs
            </Typography>
            <Chip icon={<VerifiedRoundedIcon />} label={loading ? "Loading" : `${jobs.length} briefs`} size="small" variant="outlined" />
          </Stack>

          <Stack spacing={1}>
            {jobs.slice(0, 6).map((job) => (
              <Box key={job.id} sx={{ p: 1.1, borderRadius: 2, border: "1px solid", borderColor: "divider" }}>
                <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" spacing={1}>
                  <Box>
                    <Typography variant="subtitle2" fontWeight={800}>
                      {job.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {(job.description || "").slice(0, 140) || "No description"}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      Budget: ${Math.round(job.budgetMin || 0).toLocaleString()} - ${Math.round(job.budgetMax || 0).toLocaleString()} {job.currency || "USD"}
                    </Typography>
                  </Box>
                  <Stack direction={{ xs: "row", md: "column" }} spacing={0.8} alignItems={{ md: "flex-end" }}>
                    <Chip size="small" label={job.status || "OPEN"} color={job.status === "OPEN" ? "success" : "default"} />
                    <SoftButton component={Link} href={`/employer/proposals/${job.id}`} size="small" variant="outlined">
                      Manage Proposals
                    </SoftButton>
                  </Stack>
                </Stack>
              </Box>
            ))}
            {!loading && jobs.length === 0 ? <Typography color="text.secondary">No briefs yet. Start by posting your first brief.</Typography> : null}
          </Stack>
        </CardContent>
      </SoftCard>
    </Stack>
  );
}
