"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import { Alert, Box, Chip, Stack, Typography } from "@mui/material";
import ProtectedLayout from "@/app/(protected)/layout";
import ZipJobsBoard, { type ZipJobItem } from "@/components/jobs/ZipJobsBoard";
import { mapToZipJobCard } from "@/components/jobs/jobCardMapper";

type Job = {
  id: string;
  title: string;
  description: string;
  deliverableType?: string;
  engagementType?: string;
  budgetMin?: number;
  budgetMax?: number;
  currency?: string;
  slaDeliveryDays?: number;
  minYearsExperience?: number;
  requiredSkills?: string[];
  status?: string;
  createdAt?: string;
  closingDate?: string;
  sampleImageUrls?: string[];
};

const fallbackCover = "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=900&h=500&fit=crop";
const fallbackAvatar = "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=96&h=96&fit=crop";

type SavedFilter = "all" | "open" | "closing-soon";

export default function SavedJobsPage() {
  const router = useRouter();
  const [savedJobIds, setSavedJobIds] = useState<string[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<SavedFilter>("all");

  useEffect(() => {
    const saved = localStorage.getItem("savedJobs");
    if (!saved) {
      setLoading(false);
      return;
    }

    const ids = JSON.parse(saved) as string[];
    setSavedJobIds(ids);
    void fetchJobDetails(ids);
  }, []);

  const fetchJobDetails = async (jobIds: string[]) => {
    if (!jobIds.length) {
      setJobs([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const responses = await Promise.all(jobIds.map((id) => axios.get(`/api/jobs/${id}`)));
      setJobs(responses.map((r) => r.data));
    } catch (err) {
      console.error("Failed to fetch saved jobs:", err);
      setError("Unable to load saved jobs right now.");
      setJobs([]);
    } finally {
      setLoading(false);
    }
  };

  const filteredJobs = useMemo(() => {
    const now = new Date();
    return jobs.filter((job) => {
      if (filterStatus === "open") return (job.status || "").toUpperCase() === "OPEN";
      if (filterStatus === "closing-soon") {
        if (!job.closingDate) return false;
        const closingDate = new Date(job.closingDate);
        const daysUntilClosing = Math.floor((closingDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        return daysUntilClosing <= 7 && daysUntilClosing > 0;
      }
      return true;
    });
  }, [filterStatus, jobs]);

  const uiJobs = useMemo<ZipJobItem[]>(() => {
    return filteredJobs.map((job) =>
      mapToZipJobCard(job, {
        fallbackCover,
        fallbackAvatar,
        employerName: "Saved opportunity",
      }),
    );
  }, [filteredJobs]);

  const removeSaved = (jobId: string) => {
    const updated = savedJobIds.filter((id) => id !== jobId);
    setSavedJobIds(updated);
    localStorage.setItem("savedJobs", JSON.stringify(updated));
    setJobs((prev) => prev.filter((job) => job.id !== jobId));
  };

  return (
    <ProtectedLayout>
      <Box sx={{ display: "grid", gap: 2 }}>
        {error ? <Alert severity="error">{error}</Alert> : null}

        <Stack direction="row" spacing={1} useFlexGap flexWrap="wrap">
          <Chip label="All" clickable color={filterStatus === "all" ? "primary" : "default"} onClick={() => setFilterStatus("all")} />
          <Chip label="Open" clickable color={filterStatus === "open" ? "success" : "default"} onClick={() => setFilterStatus("open")} />
          <Chip label="Closing Soon" clickable color={filterStatus === "closing-soon" ? "warning" : "default"} onClick={() => setFilterStatus("closing-soon")} />
        </Stack>

        {!loading && uiJobs.length === 0 ? (
          <Box sx={{ border: "1px solid", borderColor: "divider", borderRadius: 3, p: 3, textAlign: "center", bgcolor: "background.paper" }}>
            <Typography variant="h6" fontWeight={700}>No saved jobs</Typography>
            <Typography color="text.secondary" sx={{ mt: 0.5 }}>Start saving jobs from advanced search to track opportunities.</Typography>
          </Box>
        ) : null}

        <ZipJobsBoard
          title="Saved Jobs"
          subtitle="Track and revisit opportunities you bookmarked"
          jobs={uiJobs}
          loading={loading}
          primaryActionLabel="View Job"
          secondaryActionLabel="Remove Saved"
          loadMoreLabel="Browse More Jobs"
          onApply={(job) => router.push(`/jobs/${job.id}`)}
          onContact={(job) => removeSaved(job.id)}
          onLoadMore={() => router.push("/jobs/advanced-search")}
        />
      </Box>
    </ProtectedLayout>
  );
}
