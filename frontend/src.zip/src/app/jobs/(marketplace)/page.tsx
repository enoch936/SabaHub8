"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import { Alert, Box } from "@mui/material";
import ProtectedLayout from "@/app/(protected)/layout";
import ZipJobsBoard, { type ZipJobItem } from "@/components/jobs/ZipJobsBoard";
import { mapToZipJobCard } from "@/components/jobs/jobCardMapper";
import { useSession } from "@/lib/session";

type ApiJob = {
  id: string;
  companyName?: string;
  title: string;
  description: string;
  categoryId?: string;
  budgetMin?: number;
  budgetMax?: number;
  currency?: string;
  slaDeliveryDays?: number;
  requiredSkills?: string[];
  minYearsExperience?: number;
  createdAt?: string;
  sampleImageUrls?: string[];
};

const fallbackCover = "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=900&h=500&fit=crop";
const fallbackAvatar = "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=96&h=96&fit=crop";

export default function JobsPage() {
  const router = useRouter();
  const backendBase = process.env.NEXT_PUBLIC_BACKEND_URL;
  const role = useSession((state) => state.role);
  const isEmployerMode = role === "EMPLOYER";
  const isFreelancerMode = role === "FREELANCER";

  const [jobs, setJobs] = useState<ApiJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [page, setPage] = useState(0);

  useEffect(() => {
    void fetchJobs(page);
  }, [page]);

  const fetchJobs = async (currentPage = 0) => {
    setLoading(true);
    setErrorMessage(null);
    const params: Record<string, string | number> = { page: currentPage, size: 20 };

    try {
      const response = await axios.get("/api/v2/jobs/search", { params });
      setJobs(response.data.content || response.data || []);
    } catch (error) {
      if (backendBase) {
        try {
          const directResponse = await axios.get(`${backendBase.replace(/\/$/, "")}/api/v2/jobs/search`, { params });
          setJobs(directResponse.data.content || directResponse.data || []);
          return;
        } catch {
          // fall through to user-facing error
        }
      }
      console.error("Error fetching jobs:", error);
      setErrorMessage("Unable to load jobs right now. Please retry.");
      setJobs([]);
    } finally {
      setLoading(false);
    }
  };

  const uiJobs = useMemo<ZipJobItem[]>(() => {
    return jobs.map((job) =>
      mapToZipJobCard(job, {
        fallbackCover,
        fallbackAvatar,
        employerName: job.companyName || "Verified employer",
        category: job.categoryId || undefined,
      }),
    );
  }, [jobs]);

  return (
    <ProtectedLayout>
      <Box sx={{ display: "grid", gap: 2 }}>
        {errorMessage ? <Alert severity="warning">{errorMessage}</Alert> : null}

        <ZipJobsBoard
          title="Job Listings"
          subtitle={isEmployerMode ? "Find the best talent for your projects" : "Discover opportunities that match your skills"}
          jobs={uiJobs}
          loading={loading}
          primaryActionLabel={isFreelancerMode ? "Apply Now" : "View Job"}
          secondaryActionLabel="Contact"
          loadMoreLabel="Load More Jobs"
          showPostButton={isEmployerMode}
          onPostJob={() => router.push("/jobs/post")}
          onApply={(job) => {
            if (isFreelancerMode) {
              router.push(`/jobs/${job.id}#apply`);
              return;
            }
            router.push(`/jobs/${job.id}`);
          }}
          onContact={(job) => router.push(`/chat?jobId=${encodeURIComponent(job.id)}`)}
          onLoadMore={() => setPage((prev) => prev + 1)}
        />
      </Box>
    </ProtectedLayout>
  );
}
