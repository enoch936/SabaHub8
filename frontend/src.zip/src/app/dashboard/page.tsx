import { redirect } from "next/navigation";

export default function DashboardPage() {
  redirect("/jobs");
}
              <Card
                sx={{
                  borderRadius: "8px",
                  border: "1px solid",
                  borderColor: "divider",
                  boxShadow: "none",
                  backgroundImage: "none",
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Stack direction="row" justifyContent="space-between" spacing={1.5}>
                    <Box>
                      <Typography sx={{ fontSize: "0.875rem", color: "#717182" }}>
                        {item.label}
                      </Typography>
                      <Typography sx={{ mt: 1, fontSize: "1.25rem", fontWeight: 600, lineHeight: 1.5 }}>
                        {item.value}
                      </Typography>
                      <Stack direction="row" spacing={0.6} alignItems="center" sx={{ mt: 1 }}>
                        {positive ? (
                          <TrendingUpRoundedIcon color="success" sx={{ fontSize: 18 }} />
                        ) : (
                          <TrendingDownRoundedIcon sx={{ fontSize: 18, color: "#22c55e" }} />
                        )}
                        <Typography
                          variant="caption"
                          fontWeight={700}
                          color="#22c55e"
                        >
                          {item.change}
                        </Typography>
                      </Stack>
                    </Box>

                    <Box
                      sx={{
                        width: 48,
                        height: 48,
                        borderRadius: "8px",
                        display: "grid",
                        placeItems: "center",
                        bgcolor: alpha("#3b82f6", 0.1),
                        color: "#3b82f6",
                        flexShrink: 0,
                      }}
                    >
                      {dashboardIcon(item.icon)}
                    </Box>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>

      <Grid container spacing={3}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card
            sx={{
              borderRadius: "8px",
              border: "1px solid",
              borderColor: "divider",
              boxShadow: "none",
              backgroundImage: "none",
              height: "100%",
            }}
          >
            <CardContent sx={{ p: 3 }}>
              <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
                <Box>
                  <Typography sx={{ fontSize: "1.125rem", fontWeight: 500, lineHeight: 1.5 }}>
                    Earnings Overview
                  </Typography>
                  <Typography sx={{ fontSize: "0.875rem", color: "#717182" }}>
                    Payout and earnings trend for the selected timeframe.
                  </Typography>
                </Box>
              </Stack>

              <Box sx={{ height: 300 }}>
                <NoSsrResponsiveContainer fallbackHeight={300}>
                  <AreaChart data={chartData} margin={{ top: 8, right: 12, left: -18, bottom: 0 }}>
                    <defs>
                      <linearGradient id="dashboardEarnings" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="month" axisLine={false} tickLine={false} />
                    <YAxis axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="earnings"
                      stroke="#3b82f6"
                      fill="url(#dashboardEarnings)"
                      strokeWidth={2.2}
                      isAnimationActive={false}
                    />
                  </AreaChart>
                </NoSsrResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <Card
            sx={{
              borderRadius: "8px",
              border: "1px solid",
              borderColor: "divider",
              boxShadow: "none",
              backgroundImage: "none",
              height: "100%",
            }}
          >
            <CardContent sx={{ p: 3 }}>
              <Typography sx={{ fontSize: "1.125rem", fontWeight: 500, lineHeight: 1.5 }}>
                By Category
              </Typography>
              <Typography sx={{ fontSize: "0.875rem", color: "#717182", mb: 2 }}>
                Distribution of projects by specialization.
              </Typography>

              <Box sx={{ height: 300 }}>
                <NoSsrResponsiveContainer fallbackHeight={300}>
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${((percent ?? 0) * 100).toFixed(0)}%`}
                      dataKey="value"
                      nameKey="name"
                      outerRadius={80}
                      isAnimationActive={false}
                    >
                      {categoryData.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </NoSsrResponsiveContainer>
              </Box>

              <Stack spacing={1.1}>
                {categoryData.map((item) => (
                  <Stack key={item.name} direction="row" alignItems="center" justifyContent="space-between">
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Box
                        sx={{
                          width: 10,
                          height: 10,
                          borderRadius: "50%",
                          bgcolor: item.color,
                        }}
                      />
                      <Typography sx={{ fontSize: "0.875rem" }}>{item.name}</Typography>
                    </Stack>
                    <Typography sx={{ fontSize: "0.875rem", fontWeight: 600 }}>
                      {item.value}%
                    </Typography>
                  </Stack>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid size={{ xs: 12, lg: 7 }}>
          <Card
            sx={{
              borderRadius: "8px",
              border: "1px solid",
              borderColor: "divider",
              boxShadow: "none",
              backgroundImage: "none",
              height: "100%",
            }}
          >
            <CardContent sx={{ p: 3 }}>
              <Typography sx={{ fontSize: "1.125rem", fontWeight: 500, lineHeight: 1.5 }}>
                Recent Activity
              </Typography>
              <Typography sx={{ fontSize: "0.875rem", color: "#717182", mb: 2 }}>
                Latest jobs, contracts, and project events.
              </Typography>

              <Stack spacing={2}>
                {activity.map((item) => (
                  <Box
                    key={item.id}
                    sx={{
                      p: 2,
                      borderRadius: "8px",
                      bgcolor: "action.hover",
                    }}
                  >
                    <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={1}>
                      <Stack direction="row" spacing={1.1} alignItems="center">
                        <Box>
                          <Typography sx={{ fontSize: "0.875rem", fontWeight: 500 }}>
                            {item.title}
                          </Typography>
                          <Typography sx={{ fontSize: "0.75rem", color: "#717182" }}>
                            {item.client}
                          </Typography>
                        </Box>
                      </Stack>
                      <Stack alignItems="flex-end" spacing={0.5} sx={{ flexShrink: 0 }}>
                        <Typography sx={{ fontSize: "0.875rem", fontWeight: 600 }}>
                          ${item.amount.toLocaleString()}
                        </Typography>
                        <Chip
                          size="small"
                          label={item.status}
                          sx={{
                            textTransform: "capitalize",
                            borderRadius: 999,
                            bgcolor:
                              item.status === "completed"
                                ? "#dcfce7"
                                : item.status === "active"
                                  ? "#dbeafe"
                                  : "#fef3c7",
                            color:
                              item.status === "completed"
                                ? "#15803d"
                                : item.status === "active"
                                  ? "#1d4ed8"
                                  : "#a16207",
                            fontWeight: 700,
                          }}
                        />
                      </Stack>
                    </Stack>
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 5 }}>
          <Card
            sx={{
              borderRadius: "8px",
              border: "1px solid",
              borderColor: "divider",
              boxShadow: "none",
              backgroundImage: "none",
              height: "100%",
            }}
          >
            <CardContent sx={{ p: 3 }}>
              <Typography sx={{ fontSize: "1.125rem", fontWeight: 500, lineHeight: 1.5 }}>
                Jobs Completed
              </Typography>
              <Typography sx={{ fontSize: "0.875rem", color: "#717182", mb: 2 }}>
                Total completed items by period.
              </Typography>

              <Box sx={{ height: 260 }}>
                <NoSsrResponsiveContainer fallbackHeight={260}>
                  <BarChart data={chartData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="month" axisLine={false} tickLine={false} />
                    <YAxis axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Bar dataKey="jobs" radius={[8, 8, 0, 0]} fill="#8b5cf6" isAnimationActive={false} />
                  </BarChart>
                </NoSsrResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
