"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import {
  Alert,
  Box,
  Checkbox,
  Divider,
  FormControlLabel,
  Grid,
  IconButton,
  InputAdornment,
  Stack,
  Typography,
} from "@mui/material";
import {
  AutoAwesome,
  Bolt,
  Shield,
  VerifiedUser,
  Visibility,
  VisibilityOff,
} from "@mui/icons-material";
import { isAuthenticated, resolveWorkspaceRouteFromToken } from "@/lib/auth";
import SoftButton from "@/components/mui/SoftButton";
import SoftCard from "@/components/mui/SoftCard";
import SoftPageShell from "@/components/mui/SoftPageShell";
import SoftTextField from "@/components/mui/SoftTextField";

type FormState = {
  identifier: string;
  password: string;
  remember: boolean;
};

type Status = {
  type: "idle" | "success" | "error";
  message: string;
};

const defaultFormState: FormState = {
  identifier: "",
  password: "",
  remember: false,
};

const highlights = [
  {
    icon: <Shield fontSize="small" />,
    title: "Secure Identity Layer",
    detail: "MFA-ready authentication flow with enterprise-grade session handling.",
  },
  {
    icon: <Bolt fontSize="small" />,
    title: "Real-Time Ops",
    detail: "Live contracts, payouts, and notifications in one execution workspace.",
  },
  {
    icon: <VerifiedUser fontSize="small" />,
    title: "Trusted Delivery",
    detail: "Auditable workflows from hiring to completion and settlement.",
  },
];

function validate(state: FormState) {
  const errors: Partial<Record<keyof FormState, string>> = {};
  if (state.identifier.trim().length < 3) errors.identifier = "Enter email or username";
  if (state.password.length < 8) errors.password = "Password must be at least 8 characters";
  return errors;
}

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState<FormState>(() => ({ ...defaultFormState }));
  const [status, setStatus] = useState<Status>({ type: "idle", message: "" });
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    if (isAuthenticated()) {
      const token = localStorage.getItem("auth_token");
      router.push(resolveWorkspaceRouteFromToken(token));
    }
  }, [router]);

  const handleChange = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
    setStatus({ type: "idle", message: "" });
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const validation = validate(form);

    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      setStatus({ type: "error", message: "Please fix the highlighted fields." });
      return;
    }

    try {
      const response = await fetch(`/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: form.identifier, password: form.password }),
      });

      const data = await response.json().catch(() => null);

      if (!response.ok) {
        setStatus({ type: "error", message: data?.error ?? data?.message ?? "Login failed" });
        return;
      }

      if (data?.token) {
        localStorage.setItem("auth_token", data.token);
        setStatus({ type: "success", message: "Logged in successfully. Redirecting..." });
        setTimeout(() => router.push(resolveWorkspaceRouteFromToken(data.token)), 500);
        return;
      }

      setStatus({ type: "error", message: "Login failed - no token received" });
    } catch {
      setStatus({ type: "error", message: "Network error. Backend not reachable." });
    }
  };

  const infoNote = useMemo(() => "Use a strong password and avoid sharing credentials.", []);

  return (
    <SoftPageShell py={5}>
      <Grid container spacing={2.2} alignItems="stretch" sx={{ maxWidth: 1180, mx: "auto" }}>
        <Grid size={{ xs: 12, md: 6 }}>
          <SoftCard sx={{ height: "100%" }}>
            <Stack spacing={2.25} sx={{ p: { xs: 2.2, md: 3.2 }, height: "100%" }}>
              <Stack spacing={1.2}>
                <Typography variant="overline" color="primary.main" fontWeight={800}>SABAHUB
                </Typography>
                <Typography variant="h3" fontWeight={800}>
                  Welcome Back To SabaHub
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Access your hiring, contract, and payout operations from one AI-native control surface.
                </Typography>
              </Stack>

              <SoftCard
                variant="outlined"
                sx={{
                  borderStyle: "dashed",
                  bgcolor: (theme) =>
                    theme.palette.mode === "light" ? "rgba(14,165,233,0.06)" : "rgba(56,189,248,0.12)",
                }}
              >
                <Stack direction="row" spacing={1.2} alignItems="center" sx={{ p: 1.5 }}>
                  <AutoAwesome color="primary" fontSize="small" />
                  <Typography variant="body2" color="text.secondary">
                    Unified command layer for employers, freelancers, and operations teams.
                  </Typography>
                </Stack>
              </SoftCard>

              <Stack spacing={1.2} sx={{ mt: 0.5 }}>
                {highlights.map((item) => (
                  <SoftCard key={item.title} variant="outlined" sx={{ boxShadow: "none" }}>
                    <Stack direction="row" spacing={1.2} sx={{ p: 1.4 }}>
                      <Box
                        sx={{
                          width: 30,
                          height: 30,
                          borderRadius: 1.5,
                          display: "grid",
                          placeItems: "center",
                          bgcolor: "primary.main",
                          color: "primary.contrastText",
                          flexShrink: 0,
                        }}
                      >
                        {item.icon}
                      </Box>
                      <Box>
                        <Typography variant="subtitle2" fontWeight={700}>
                          {item.title}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {item.detail}
                        </Typography>
                      </Box>
                    </Stack>
                  </SoftCard>
                ))}
              </Stack>
            </Stack>
          </SoftCard>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <SoftCard sx={{ height: "100%" }}>
            <Stack spacing={2} sx={{ p: { xs: 2.2, md: 3.2 } }}>
              <Box>
                <Typography variant="h4" fontWeight={800}>
                  Sign In
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Continue where your team left off.
                </Typography>
              </Box>

              <Box component="form" onSubmit={handleSubmit} noValidate>
                <Stack spacing={1.5}>
                  <SoftTextField
                    label="Email or Username"
                    type="text"
                    value={form.identifier}
                    onChange={(e) => handleChange("identifier", e.target.value)}
                    error={!!errors.identifier}
                    helperText={errors.identifier}
                    autoComplete="username"
                    fullWidth
                  />

                  <SoftTextField
                    label="Password"
                    type={showPassword ? "text" : "password"}
                    value={form.password}
                    onChange={(e) => handleChange("password", e.target.value)}
                    error={!!errors.password}
                    helperText={errors.password}
                    autoComplete="current-password"
                    fullWidth
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton onClick={() => setShowPassword((prev) => !prev)} edge="end">
                            {showPassword ? <VisibilityOff /> : <Visibility />}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                  />

                  <Stack direction="row" justifyContent="space-between" alignItems="center">
                    <FormControlLabel
                      control={<Checkbox checked={form.remember} onChange={(e) => handleChange("remember", e.target.checked)} />}
                      label="Remember me"
                    />
                    <SoftButton component={Link} href="/forgot-password" variant="text" size="small" sx={{ px: 0.5 }}>
                      Forgot password?
                    </SoftButton>
                  </Stack>

                  <SoftButton type="submit" variant="contained" size="large" disabled={status.type === "success"}>
                    {status.type === "success" ? "Logging in..." : "Login"}
                  </SoftButton>

                  <Divider>Or continue with</Divider>
                  <Grid container spacing={1}>
                    <Grid size={{ xs: 4 }}>
                      <SoftButton fullWidth variant="outlined">Google</SoftButton>
                    </Grid>
                    <Grid size={{ xs: 4 }}>
                      <SoftButton fullWidth variant="outlined">GitHub</SoftButton>
                    </Grid>
                    <Grid size={{ xs: 4 }}>
                      <SoftButton fullWidth variant="outlined">LinkedIn</SoftButton>
                    </Grid>
                  </Grid>

                  <Typography variant="caption" color="text.secondary">
                    {infoNote}
                  </Typography>

                  <Typography variant="body2" color="text.secondary">
                    Don&apos;t have an account?{" "}
                    <SoftButton component={Link} href="/register" variant="text" size="small" sx={{ px: 0.5 }}>
                      Register
                    </SoftButton>
                  </Typography>

                  {status.message ? (
                    <Alert severity={status.type === "success" ? "success" : "error"}>{status.message}</Alert>
                  ) : null}
                </Stack>
              </Box>
            </Stack>
          </SoftCard>
        </Grid>
      </Grid>
    </SoftPageShell>
  );
}
