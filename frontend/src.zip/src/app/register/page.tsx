"use client";

import Link from "next/link";
import { FormEvent, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Alert,
  Box,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  Radio,
  RadioGroup,
  Stack,
  Step,
  StepLabel,
  Stepper,
  Typography,
} from "@mui/material";
import { RocketLaunch, Security, Verified } from "@mui/icons-material";
import SoftButton from "@/components/mui/SoftButton";
import SoftCard from "@/components/mui/SoftCard";
import SoftPageShell from "@/components/mui/SoftPageShell";
import SoftTextField from "@/components/mui/SoftTextField";
import { resolveWorkspaceRouteFromToken } from "@/lib/auth";

type StepKey = "form" | "otp";
type Role = "FREELANCER" | "EMPLOYER";

type StatusState = {
  type: "error" | "success";
  message: string;
} | null;

const onboardingSignals = [
  {
    icon: <Security fontSize="small" />,
    title: "Verified Identity",
    detail: "Email/SMS verification protects account access and team operations.",
  },
  {
    icon: <RocketLaunch fontSize="small" />,
    title: "Fast Go-Live",
    detail: "Start projects, contracts, and milestone workflows immediately after signup.",
  },
  {
    icon: <Verified fontSize="small" />,
    title: "Enterprise Ready",
    detail: "Role-based workspace model for freelancers, employers, and admins.",
  },
];

export default function RegisterPage() {
  const router = useRouter();
  const [step, setStep] = useState<StepKey>("form");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [firstName, setFirstName] = useState("");
  const [middleName, setMiddleName] = useState("");
  const [lastName, setLastName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [role, setRole] = useState<Role>("FREELANCER");
  const [emailOTP, setEmailOTP] = useState("");
  const [status, setStatus] = useState<StatusState>(null);
  const [loading, setLoading] = useState(false);

  const activeStep = step === "form" ? 0 : 1;
  const uniqueId = useMemo(
    () => username.trim().toLowerCase().replace(/[^a-z0-9._-]/g, ""),
    [username]
  );

  async function requestOTP(e?: FormEvent) {
    e?.preventDefault();
    setStatus(null);

    if (uniqueId.length < 3) {
      setStatus({ type: "error", message: "Username must produce at least 3 valid characters for your unique ID." });
      return;
    }

    if (password.length < 8) {
      setStatus({ type: "error", message: "Password must be at least 8 characters" });
      return;
    }
    if (password !== confirmPassword) {
      setStatus({ type: "error", message: "Passwords do not match" });
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`/api/auth/otp/request-registration`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, phoneNumber, firstName, middleName, lastName }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        setStatus({ type: "error", message: data?.message || "Failed to send OTP" });
        setLoading(false);
        return;
      }
      setStatus({ type: "success", message: "OTP sent. Check your email or SMS." });
      setStep("otp");
    } catch {
      setStatus({ type: "error", message: "Network error" });
    } finally {
      setLoading(false);
    }
  }

  async function verifyAndRegister(e: FormEvent) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);

    try {
      const verifyRes = await fetch(`/api/auth/otp/verify-email`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otpCode: emailOTP }),
      });

      if (!verifyRes.ok) {
        setStatus({ type: "error", message: "Invalid OTP code" });
        setLoading(false);
        return;
      }

      const registerRes = await fetch(`/api/auth/otp/complete-registration`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, username: uniqueId, password, role, firstName, middleName, lastName, phoneNumber }),
      });

      const data = await registerRes.json().catch(() => null);

      if (!registerRes.ok) {
        setStatus({ type: "error", message: data?.message || data?.error || "Registration failed" });
        setLoading(false);
        return;
      }

      if (data?.token) {
        localStorage.setItem("auth_token", data.token);
        router.push(resolveWorkspaceRouteFromToken(data.token));
      } else {
        setStatus({ type: "error", message: "Registration successful but no token returned" });
      }
    } catch {
      setStatus({ type: "error", message: "Network error" });
    } finally {
      setLoading(false);
    }
  }

  const subtitle = useMemo(
    () =>
      step === "form"
        ? "Create your organization-ready workspace in minutes."
        : "Confirm your verification code to activate your account.",
    [step]
  );

  return (
    <SoftPageShell py={5}>
      <Grid container spacing={2.2} alignItems="stretch" sx={{ maxWidth: 1180, mx: "auto" }}>
        <Grid size={{ xs: 12, md: 5 }}>
          <SoftCard sx={{ height: "100%" }}>
            <Stack spacing={2.2} sx={{ p: { xs: 2.2, md: 3.2 }, height: "100%" }}>
              <Box>
                <Typography variant="overline" color="primary.main" fontWeight={800}>
                  Join SabaHub
                </Typography>
                <Typography variant="h3" fontWeight={800}>
                  Build Your SaaS Talent Workspace
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 0.8 }}>
                  Teams use SabaHub to centralize job delivery, contract execution, and payout compliance.
                </Typography>
              </Box>

              <Stepper activeStep={activeStep} alternativeLabel>
                <Step>
                  <StepLabel>Profile</StepLabel>
                </Step>
                <Step>
                  <StepLabel>Verification</StepLabel>
                </Step>
              </Stepper>

              <Stack spacing={1.1}>
                {onboardingSignals.map((item) => (
                  <SoftCard key={item.title} variant="outlined" sx={{ boxShadow: "none" }}>
                    <Stack direction="row" spacing={1.2} sx={{ p: 1.35 }}>
                      <Box
                        sx={{
                          width: 30,
                          height: 30,
                          borderRadius: 1.5,
                          bgcolor: "secondary.main",
                          color: "secondary.contrastText",
                          display: "grid",
                          placeItems: "center",
                          flexShrink: 0,
                        }}
                      >
                        {item.icon}
                      </Box>
                      <Box>
                        <Typography variant="subtitle2" fontWeight={700}>
                          {item.title}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {item.detail}
                        </Typography>
                      </Box>
                    </Stack>
                  </SoftCard>
                ))}
              </Stack>
            </Stack>
          </SoftCard>
        </Grid>

        <Grid size={{ xs: 12, md: 7 }}>
          <SoftCard sx={{ height: "100%" }}>
            <Stack spacing={2} sx={{ p: { xs: 2.2, md: 3.2 } }}>
              <Box>
                <Typography variant="h4" fontWeight={800}>
                  {step === "form" ? "Create Account" : "Verify Account"}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {subtitle}
                </Typography>
              </Box>

              {step === "form" ? (
                <Stack spacing={1.5} component="form" onSubmit={requestOTP}>
                  <Grid container spacing={1.2}>
                    <Grid size={{ xs: 12, sm: 4 }}>
                      <SoftTextField label="First name" value={firstName} onChange={(e) => setFirstName(e.target.value)} required fullWidth />
                    </Grid>
                    <Grid size={{ xs: 12, sm: 4 }}>
                      <SoftTextField label="Middle name" value={middleName} onChange={(e) => setMiddleName(e.target.value)} fullWidth />
                    </Grid>
                    <Grid size={{ xs: 12, sm: 4 }}>
                      <SoftTextField label="Last name" value={lastName} onChange={(e) => setLastName(e.target.value)} required fullWidth />
                    </Grid>
                  </Grid>

                  <SoftTextField type="email" label="Email" value={email} onChange={(e) => setEmail(e.target.value)} required fullWidth />
                  <SoftTextField label="Username" value={username} onChange={(e) => setUsername(e.target.value)} required fullWidth />
                  <SoftTextField
                    label="Unique ID (auto from username)"
                    value={uniqueId ? `@${uniqueId}` : ""}
                    fullWidth
                    slotProps={{ input: { readOnly: true } }}
                    helperText="This ID is automatically generated and is not editable."
                  />
                  <SoftTextField label="Phone number (optional)" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} fullWidth />

                  <Grid container spacing={1.2}>
                    <Grid size={{ xs: 12, sm: 6 }}>
                      <SoftTextField type="password" label="Password" value={password} onChange={(e) => setPassword(e.target.value)} required fullWidth />
                    </Grid>
                    <Grid size={{ xs: 12, sm: 6 }}>
                      <SoftTextField
                        type="password"
                        label="Confirm password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                        fullWidth
                      />
                    </Grid>
                  </Grid>

                  <FormControl>
                    <FormLabel>I am a:</FormLabel>
                    <RadioGroup row value={role} onChange={(e) => setRole(e.target.value as Role)}>
                      <FormControlLabel value="FREELANCER" control={<Radio />} label="Freelancer" />
                      <FormControlLabel value="EMPLOYER" control={<Radio />} label="Employer" />
                    </RadioGroup>
                  </FormControl>

                  <SoftButton type="submit" variant="contained" disabled={loading}>
                    {loading ? "Sending code..." : "Continue"}
                  </SoftButton>

                  <Typography variant="body2" color="text.secondary">
                    Already have an account?{" "}
                    <SoftButton component={Link} href="/login" variant="text" size="small" sx={{ px: 0.5 }}>
                      Sign in
                    </SoftButton>
                  </Typography>
                </Stack>
              ) : (
                <Stack spacing={1.5} component="form" onSubmit={verifyAndRegister}>
                  <SoftTextField
                    label="6-digit OTP"
                    inputMode="numeric"
                    value={emailOTP}
                    onChange={(e) => setEmailOTP(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    fullWidth
                  />

                  <SoftButton type="submit" variant="contained" disabled={loading || emailOTP.length !== 6}>
                    {loading ? "Verifying..." : "Verify & Create Account"}
                  </SoftButton>

                  <Stack direction="row" spacing={1}>
                    <SoftButton variant="outlined" onClick={() => setStep("form")}>Back</SoftButton>
                    <SoftButton variant="text" onClick={() => requestOTP()}>Resend code</SoftButton>
                  </Stack>
                </Stack>
              )}

              {status ? <Alert severity={status.type}>{status.message}</Alert> : null}
            </Stack>
          </SoftCard>
        </Grid>
      </Grid>
    </SoftPageShell>
  );
}
