"use client";

import { useEffect, useState } from "react";
import { Alert, Box, Card, CardContent, Chip, Container, Stack, Typography } from "@mui/material";
import { SegmentedThemeToggle, useTheme } from "@/components/useTheme";

export default function ThemeTestPage() {
  const { theme, mounted } = useTheme();
  const [htmlClasses, setHtmlClasses] = useState("");
  const [storedTheme, setStoredTheme] = useState("");
  const [colorScheme, setColorScheme] = useState("");

  useEffect(() => {
    if (!mounted) return;

    const checkState = () => {
      const html = document.documentElement;
      setHtmlClasses(html.className);
      setStoredTheme(window.localStorage.getItem("sabahub-theme") || "not set");
      setColorScheme(document.documentElement.style.colorScheme || "not set");
    };

    checkState();
    const interval = setInterval(checkState, 500);
    return () => clearInterval(interval);
  }, [mounted]);

  return (
    <Box sx={{ py: 3, minHeight: "100vh", background: "linear-gradient(180deg, #f6f8fb 0%, #ffffff 45%)" }}>
      <Container maxWidth="md">
        <Stack spacing={2}>
          <Typography variant="h4" fontWeight={800}>Theme Debug Test</Typography>

          <Card sx={{ borderRadius: 3 }}>
            <CardContent>
              <Typography variant="h6" fontWeight={700} sx={{ mb: 1.25 }}>Current Theme State</Typography>
              <Stack spacing={1}>
                <Row label="Current Hook Theme" value={mounted ? theme : "loading..."} />
                <Row label="HTML Classes" value={htmlClasses || "none"} />
                <Row label="LocalStorage sabahub-theme" value={storedTheme} />
                <Row label="color-scheme" value={colorScheme} />
              </Stack>
            </CardContent>
          </Card>

          <Card sx={{ borderRadius: 3 }}>
            <CardContent>
              <Typography variant="h6" fontWeight={700} sx={{ mb: 1.25 }}>Test Toggle</Typography>
              {mounted ? <SegmentedThemeToggle /> : <Alert severity="warning">Loading theme system...</Alert>}
            </CardContent>
          </Card>

          <Card sx={{ borderRadius: 3 }}>
            <CardContent>
              <Typography variant="h6" fontWeight={700} sx={{ mb: 1.25 }}>Expected Behavior</Typography>
              <Stack direction="row" spacing={0.75} useFlexGap flexWrap="wrap">
                <Chip label="Background changes instantly" size="small" />
                <Chip label="HTML class updates" size="small" />
                <Chip label="LocalStorage updates" size="small" />
                <Chip label="Theme persists on refresh" size="small" />
              </Stack>
            </CardContent>
          </Card>
        </Stack>
      </Container>
    </Box>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <Stack direction={{ xs: "column", sm: "row" }} spacing={0.75} alignItems={{ sm: "center" }}>
      <Typography variant="body2" fontWeight={700}>{label}:</Typography>
      <Box component="code" sx={{ px: 1, py: 0.5, borderRadius: 1, bgcolor: "grey.100", fontSize: 12, overflowX: "auto" }}>
        {value}
      </Box>
    </Stack>
  );
}
