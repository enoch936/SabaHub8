"use client";

import AdminSupportOperationsWorkspace from "@/components/admin/AdminSupportOperationsWorkspace";

export default function AdminChatPage() {
  return <AdminSupportOperationsWorkspace />;
}
