"use client";

import Link from "next/link";
import { Suspense, useEffect, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  AppBar,
  Box,
  Chip,
  Collapse,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItemIcon,
  ListItemButton,
  ListItemText,
  ListSubheader,
  Stack,
  Toolbar,
  Typography,
  useMediaQuery,
} from "@mui/material";
import { alpha, useTheme } from "@mui/material/styles";
import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import AdminPanelSettingsRoundedIcon from "@mui/icons-material/AdminPanelSettingsRounded";
import DashboardRoundedIcon from "@mui/icons-material/DashboardRounded";
import ExpandLessRoundedIcon from "@mui/icons-material/ExpandLessRounded";
import ExpandMoreRoundedIcon from "@mui/icons-material/ExpandMoreRounded";
import ThemeToggle from "@/components/mui/ThemeToggle";
import SoftButton from "@/components/mui/SoftButton";
import {
  adminHierarchy,
  adminNavigationGroups,
  type AdminHierarchyChild,
  type AdminHierarchyItem,
  createInitialExpandedParents,
} from "@/lib/admin/navigation";
import { adminListContent, adminListJobs, listDisputes } from "@/lib/api";
import { bootstrapSession, useSession } from "@/lib/session";
import { isTokenUsable, logout } from "@/lib/auth";

const DRAWER_WIDTH = 264;

type ModerationSidebarBadges = {
  flaggedJobs: number;
  openDisputes: number;
  unpublishedPolicyUpdates: number;
  total: number;
};

const emptyModerationBadges: ModerationSidebarBadges = {
  flaggedJobs: 0,
  openDisputes: 0,
  unpublishedPolicyUpdates: 0,
  total: 0,
};

function isLikelyFlaggedJob(job: { title?: string | null; description?: string | null; status?: string | null }) {
  const status = (job.status ?? "").toUpperCase();
  const combined = `${job.title ?? ""} ${job.description ?? ""}`.toLowerCase();
  const suspicious = ["scam", "fraud", "fake", "crypto giveaway", "guaranteed return"];
  return status === "OPEN" && suspicious.some((term) => combined.includes(term));
}

function routeMatches(pathname: string, href: string) {
  return pathname === href || pathname.startsWith(`${href}/`);
}

function childMatches(pathname: string, sectionQuery: string | null, child: AdminHierarchyChild) {
  if (child.section) {
    return routeMatches(pathname, child.href) && sectionQuery === child.section;
  }
  return routeMatches(pathname, child.href);
}

function itemMatches(pathname: string, sectionQuery: string | null, item: AdminHierarchyItem) {
  return routeMatches(pathname, item.href) || (item.children ?? []).some((child) => childMatches(pathname, sectionQuery, child));
}

function childHref(child: AdminHierarchyChild) {
  if (child.section) {
    return `${child.href}?section=${child.section}`;
  }
  return child.href;
}

function resolveActiveAdminContext(pathname: string, sectionQuery: string | null) {
  for (const group of adminNavigationGroups) {
    for (const item of group.items) {
      const matchedChild = item.children?.find((child) => childMatches(pathname, sectionQuery, child)) ?? null;
      if (matchedChild || routeMatches(pathname, item.href)) {
        return { group, item, child: matchedChild };
      }
    }
  }

  const fallbackItem = adminHierarchy.find((item) => itemMatches(pathname, sectionQuery, item)) ?? null;
  return { group: null, item: fallbackItem, child: null };
}

function AdminLayoutContent({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const sectionQuery = searchParams.get("section");
  const role = useSession((s) => s.role);
  const clearSession = useSession((s) => s.clear);

  const theme = useTheme();
  const isDesktop = useMediaQuery(theme.breakpoints.up("lg"));
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedParents, setExpandedParents] = useState<Record<string, boolean>>(createInitialExpandedParents);
  const [moderationBadges, setModerationBadges] = useState<ModerationSidebarBadges>(emptyModerationBadges);
  const activeContext = useMemo(() => resolveActiveAdminContext(pathname, sectionQuery), [pathname, sectionQuery]);
  const activeAccent = activeContext.group?.accent ?? "#18283b";
  const activeLabel = activeContext.child?.label ?? activeContext.item?.label ?? "Command Center";
  const activeDescription = activeContext.child
    ? activeContext.item?.description ?? "Focused administrative controls."
    : activeContext.item?.description ?? "Governance, operations, and systems";
  const liveStatusLabel = moderationBadges.total > 0 ? `${moderationBadges.total} live alerts` : "Nominal";
  const isDarkMode = theme.palette.mode === "dark";

  useEffect(() => {
    const currentParent = adminHierarchy.find((item) => itemMatches(pathname, sectionQuery, item));
    if (currentParent) {
      setExpandedParents((prev) => ({ ...prev, [currentParent.key]: true }));
    }
  }, [pathname, sectionQuery]);

  useEffect(() => {
    setSidebarOpen(isDesktop);
  }, [isDesktop]);

  useEffect(() => {
    bootstrapSession();
    const token = localStorage.getItem("auth_token");
    if (!isTokenUsable(token)) {
      clearSession();
      localStorage.removeItem("auth_token");
      router.replace("/login");
    }
  }, [clearSession, router]);

  useEffect(() => {
    if (role && role !== "ADMIN") {
      router.replace("/forbidden");
    }
  }, [role, router]);

  useEffect(() => {
    if (!isDesktop) {
      setSidebarOpen(false);
    }
  }, [isDesktop, pathname]);

  useEffect(() => {
    let cancelled = false;

    const loadModerationBadges = async () => {
      try {
        const [jobs, disputes, content] = await Promise.all([adminListJobs(), listDisputes(), adminListContent()]);

        if (cancelled) {
          return;
        }

        const flaggedJobs = jobs.filter((job) => isLikelyFlaggedJob(job)).length;
        const openDisputes = disputes.filter((dispute) => {
          const status = (dispute.status ?? "").toUpperCase();
          return status === "OPEN" || status === "INVESTIGATING";
        }).length;
        const unpublishedPolicyUpdates = content.filter((item) => (item.status ?? "").toUpperCase() === "DRAFT").length;

        setModerationBadges({
          flaggedJobs,
          openDisputes,
          unpublishedPolicyUpdates,
          total: flaggedJobs + openDisputes + unpublishedPolicyUpdates,
        });
      } catch {
        if (!cancelled) {
          setModerationBadges(emptyModerationBadges);
        }
      }
    };

    void loadModerationBadges();

    return () => {
      cancelled = true;
    };
  }, []);

  const itemBadgeValue = (itemKey: string) => {
    if (itemKey === "content-moderation") {
      return moderationBadges.total;
    }
    return 0;
  };

  const childBadgeValue = (childKey: string) => {
    if (childKey === "moderation-jobs") {
      return moderationBadges.flaggedJobs;
    }
    if (childKey === "moderation-content") {
      return moderationBadges.unpublishedPolicyUpdates;
    }
    if (childKey === "moderation-disputes") {
      return moderationBadges.openDisputes;
    }
    return 0;
  };

  const onLogout = () => {
    clearSession();
    logout();
    router.replace("/login");
  };

  const drawer = useMemo(
    () => (
      <Box sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
        <Box sx={{ px: 1.1, pt: 1.1, pb: 0.9 }}>
          <Box
            sx={{
              position: "relative",
              overflow: "hidden",
              borderRadius: 3.2,
              px: 1.25,
              py: 1.2,
              border: "1px solid",
              borderColor: alpha(activeAccent, isDarkMode ? 0.34 : 0.18),
              background: `linear-gradient(160deg, ${alpha(activeAccent, isDarkMode ? 0.28 : 0.14)} 0%, ${alpha(activeAccent, isDarkMode ? 0.12 : 0.04)} 58%, ${alpha("#ffffff", isDarkMode ? 0.02 : 0.4)} 100%)`,
              boxShadow: `0 18px 40px ${alpha(activeAccent, isDarkMode ? 0.22 : 0.1)}`,
              "&::before": {
                content: '""',
                position: "absolute",
                inset: "-20% auto auto 58%",
                width: 120,
                height: 120,
                borderRadius: "50%",
                background: alpha("#ffffff", isDarkMode ? 0.08 : 0.3),
                filter: "blur(8px)",
              },
            }}
          >
            <Stack direction="row" spacing={1} alignItems="center" sx={{ position: "relative", zIndex: 1 }}>
              <Box
                sx={{
                  width: 34,
                  height: 34,
                  borderRadius: 2,
                  display: "grid",
                  placeItems: "center",
                  color: "common.white",
                  background: `linear-gradient(145deg, ${activeAccent}, ${alpha(activeAccent, 0.72)})`,
                  boxShadow: `0 10px 22px ${alpha(activeAccent, 0.28)}`,
                }}
              >
                <AdminPanelSettingsRoundedIcon sx={{ fontSize: 18 }} />
              </Box>
              <Box sx={{ minWidth: 0 }}>
                <Typography variant="overline" sx={{ color: alpha(theme.palette.text.primary, 0.72), letterSpacing: "0.18em", lineHeight: 1, fontSize: 8.6 }}>
                  ADMIN
                </Typography>
                <Typography variant="subtitle2" fontWeight={900} sx={{ lineHeight: 1.08, fontSize: 13.4 }}>
                  Admin Console
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: "block", fontSize: 10.2 }}>
                  {activeContext.group?.label ?? "Control plane"} domain
                </Typography>
              </Box>
            </Stack>

            <Stack direction="row" spacing={0.75} useFlexGap flexWrap="wrap" sx={{ mt: 1.15, position: "relative", zIndex: 1 }}>
              <Chip
                label={activeLabel}
                size="small"
                sx={{
                  height: 22,
                  borderRadius: 999,
                  bgcolor: alpha("#ffffff", isDarkMode ? 0.08 : 0.72),
                  border: "1px solid",
                  borderColor: alpha(activeAccent, isDarkMode ? 0.38 : 0.16),
                  ".MuiChip-label": { px: 1, fontSize: 10.4, fontWeight: 800 },
                }}
              />
              <Chip
                label={liveStatusLabel}
                size="small"
                color={moderationBadges.total > 0 ? "warning" : "success"}
                variant={moderationBadges.total > 0 ? "filled" : "outlined"}
                sx={{ height: 22, ".MuiChip-label": { px: 1, fontSize: 10.2, fontWeight: 800 } }}
              />
            </Stack>
          </Box>
        </Box>

        <Box sx={{ px: 0.9, pb: 0.7 }}>
          <ListItemButton
            component={Link}
            href="/admin"
            selected={pathname === "/admin"}
            sx={{
              borderRadius: 1.5,
              mb: 0.45,
              py: 0.58,
              px: 0.75,
              bgcolor: pathname === "/admin" ? "rgba(24,40,59,0.08)" : "transparent",
              border: "1px solid",
              borderColor: pathname === "/admin" ? "rgba(24,40,59,0.14)" : "transparent",
              transition: "background-color 160ms ease, border-color 160ms ease",
              "&:hover": { bgcolor: "rgba(24,40,59,0.05)" },
              "&.Mui-selected": {
                bgcolor: "rgba(24,40,59,0.08)",
                boxShadow: "inset 2px 0 0 #18283b",
              },
              "&.Mui-selected:hover": { bgcolor: "rgba(24,40,59,0.08)" },
            }}
          >
            <ListItemIcon sx={{ minWidth: 26, color: pathname === "/admin" ? "#18283b" : "text.secondary" }}>
              <DashboardRoundedIcon sx={{ fontSize: 16 }} />
            </ListItemIcon>
            <ListItemText
              primary="Command Center"
              secondary="Overview and alerts"
              primaryTypographyProps={{ fontWeight: pathname === "/admin" ? 800 : 700, fontSize: 12.4, lineHeight: 1.1 }}
              secondaryTypographyProps={{ fontSize: 10, color: "text.secondary", lineHeight: 1.15 }}
            />
          </ListItemButton>
        </Box>

        <Divider />

        <Box sx={{ flex: 1, overflowY: "auto", px: 0.8, py: 0.7 }}>
          {adminNavigationGroups.map((group) => (
            <List
              key={group.key}
              dense
              subheader={
                <ListSubheader
                  component="div"
                  sx={{
                    bgcolor: "transparent",
                    px: 0.7,
                    py: 0.22,
                    fontWeight: 900,
                    fontSize: 9.4,
                    letterSpacing: "0.14em",
                    color: group.accent,
                    textTransform: "uppercase",
                    lineHeight: 1.2,
                  }}
                >
                  {group.label}
                </ListSubheader>
              }
              sx={{ mb: 0.28 }}
            >
              {group.items.map((item) => {
                const itemSelected = itemMatches(pathname, sectionQuery, item);
                const isExpanded = expandedParents[item.key];
                const hasChildren = Boolean(item.children?.length);
                const badgeValue = itemBadgeValue(item.key);

                return (
                  <Box key={item.key}>
                    <Stack direction="row" spacing={0.4} alignItems="stretch">
                      <ListItemButton
                        onClick={() => router.push(item.href)}
                        selected={itemSelected}
                        sx={{
                          flex: 1,
                          borderRadius: 1.5,
                          mb: 0.12,
                          py: 0.54,
                          px: 0.72,
                          alignItems: "flex-start",
                          border: "1px solid transparent",
                          transition: "background-color 160ms ease, border-color 160ms ease",
                          "&:hover": { bgcolor: alpha(group.accent, 0.05) },
                          "&.Mui-selected": {
                            bgcolor: alpha(group.accent, 0.07),
                            borderColor: alpha(group.accent, 0.16),
                            boxShadow: `inset 2px 0 0 ${group.accent}`,
                          },
                          "&.Mui-selected:hover": { bgcolor: alpha(group.accent, 0.07) },
                        }}
                      >
                        <ListItemIcon sx={{ minWidth: 24, mt: 0.03, color: itemSelected ? group.accent : "text.secondary" }}>
                          {item.icon}
                        </ListItemIcon>
                        <ListItemText
                          primary={item.label}
                          secondary={item.description}
                          primaryTypographyProps={{
                            fontWeight: itemSelected ? 800 : 700,
                            fontSize: 12.2,
                            lineHeight: 1.15,
                            color: itemSelected ? group.accent : "text.primary",
                          }}
                          secondaryTypographyProps={{ fontSize: 9.9, lineHeight: 1.15, color: "text.secondary", sx: { mt: 0.1 } }}
                        />
                        {badgeValue > 0 ? (
                          <Chip
                            label={badgeValue}
                            size="small"
                            color="warning"
                            sx={{
                              ml: 0.6,
                              height: 18,
                              minWidth: 18,
                              ".MuiChip-label": { px: 0.75, fontSize: 10, fontWeight: 800 },
                            }}
                          />
                        ) : null}
                      </ListItemButton>

                      {hasChildren ? (
                        <IconButton
                          size="small"
                          aria-label={isExpanded ? `Collapse ${item.label}` : `Expand ${item.label}`}
                          onClick={(event) => {
                            event.preventDefault();
                            event.stopPropagation();
                            setExpandedParents((prev) => ({ ...prev, [item.key]: !prev[item.key] }));
                          }}
                          sx={{
                            alignSelf: "center",
                            width: 22,
                            height: 22,
                            color: itemSelected ? group.accent : "text.secondary",
                            borderRadius: 1.25,
                            bgcolor: isExpanded ? alpha(group.accent, 0.07) : "transparent",
                          }}
                        >
                          {isExpanded ? <ExpandLessRoundedIcon sx={{ fontSize: 15 }} /> : <ExpandMoreRoundedIcon sx={{ fontSize: 15 }} />}
                        </IconButton>
                      ) : null}
                    </Stack>

                    {hasChildren ? (
                      <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                        <List
                          dense
                          disablePadding
                          sx={{
                            ml: 2.35,
                            mb: 0.22,
                            pl: 0.62,
                            borderLeft: `1px solid ${alpha(group.accent, 0.14)}`,
                          }}
                        >
                          {item.children?.map((child) => {
                            const childSelected = childMatches(pathname, sectionQuery, child);
                            const childBadge = childBadgeValue(child.key);

                            return (
                              <ListItemButton
                                key={child.key}
                                component={Link}
                                href={childHref(child)}
                                selected={childSelected}
                                sx={{
                                  borderRadius: 1.35,
                                  mb: 0.1,
                                  py: 0.32,
                                  px: 0.62,
                                  transition: "background-color 160ms ease",
                                  "&:hover": { bgcolor: alpha(group.accent, 0.05) },
                                  "&.Mui-selected": {
                                    bgcolor: alpha(group.accent, 0.07),
                                  },
                                }}
                              >
                                <ListItemIcon sx={{ minWidth: 18, color: childSelected ? group.accent : "text.secondary" }}>
                                  {child.icon}
                                </ListItemIcon>
                                <ListItemText
                                  primary={child.label}
                                  primaryTypographyProps={{
                                    fontSize: 11.1,
                                    fontWeight: childSelected ? 700 : 600,
                                    lineHeight: 1.15,
                                    color: childSelected ? group.accent : "text.primary",
                                  }}
                                />
                                {childBadge > 0 ? (
                                  <Chip
                                    label={childBadge}
                                    size="small"
                                    color="warning"
                                    variant="outlined"
                                    sx={{
                                      ml: 0.6,
                                      height: 17,
                                      minWidth: 17,
                                      ".MuiChip-label": { px: 0.6, fontSize: 9.5, fontWeight: 700 },
                                    }}
                                  />
                                ) : null}
                              </ListItemButton>
                            );
                          })}
                        </List>
                      </Collapse>
                    ) : null}
                  </Box>
                );
              })}
            </List>
          ))}
        </Box>

        <Box sx={{ px: 1.05, pb: 1.05, pt: 0.4 }}>
          <Box
            sx={{
              borderRadius: 2.8,
              px: 1.15,
              py: 1,
              border: "1px solid",
              borderColor: alpha(activeAccent, isDarkMode ? 0.28 : 0.14),
              bgcolor: alpha(activeAccent, isDarkMode ? 0.1 : 0.04),
            }}
          >
            <Typography variant="overline" sx={{ fontSize: 8.4, letterSpacing: "0.16em", color: alpha(theme.palette.text.secondary, 0.9) }}>
              Live Posture
            </Typography>
            <Typography variant="subtitle2" fontWeight={800} sx={{ mt: 0.2, fontSize: 12.4, lineHeight: 1.1 }}>
              {activeLabel}
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: 0.45, lineHeight: 1.2 }}>
              {activeDescription}
            </Typography>
            <Stack direction="row" spacing={0.75} useFlexGap flexWrap="wrap" sx={{ mt: 1 }}>
              <Chip
                label={role ?? "ADMIN"}
                size="small"
                variant="outlined"
                sx={{ height: 21, ".MuiChip-label": { px: 0.9, fontSize: 10, fontWeight: 700 } }}
              />
              <Chip
                label={liveStatusLabel}
                size="small"
                color={moderationBadges.total > 0 ? "warning" : "success"}
                variant={moderationBadges.total > 0 ? "filled" : "outlined"}
                sx={{ height: 21, ".MuiChip-label": { px: 0.9, fontSize: 10, fontWeight: 700 } }}
              />
            </Stack>
          </Box>
        </Box>
      </Box>
    ),
    [
      activeAccent,
      activeContext.group?.label,
      activeDescription,
      activeLabel,
      expandedParents,
      isDarkMode,
      liveStatusLabel,
      moderationBadges,
      pathname,
      role,
      router,
      sectionQuery,
      theme.palette.text.primary,
      theme.palette.text.secondary,
    ],
  );

  return (
    <Box
      className="sheet-shell"
      sx={{
        minHeight: "100vh",
        position: "relative",
        overflow: "hidden",
        bgcolor: (t) => (t.palette.mode === "light" ? "#f4f7fb" : t.palette.background.default),
        "&::before": {
          content: '""',
          position: "absolute",
          inset: 0,
          pointerEvents: "none",
          background: `radial-gradient(820px 420px at 10% -10%, ${alpha(activeAccent, isDarkMode ? 0.18 : 0.1)} 0%, transparent 68%), radial-gradient(760px 360px at 100% 0%, ${alpha(activeAccent, isDarkMode ? 0.12 : 0.06)} 0%, transparent 72%)`,
        },
      }}
    >
      <AppBar
        position="fixed"
        color="inherit"
        elevation={0}
        sx={{
          borderBottom: "1px solid",
          borderColor: alpha(activeAccent, isDarkMode ? 0.22 : 0.12),
          bgcolor: alpha(theme.palette.background.paper, isDarkMode ? 0.82 : 0.74),
          backdropFilter: "blur(18px)",
          boxShadow: `0 14px 36px ${alpha("#07101d", isDarkMode ? 0.4 : 0.06)}`,
        }}
      >
        <Toolbar
          sx={{
            gap: 1,
            px: { xs: 1, sm: 1.25 },
            py: { xs: 0.5, sm: 0 },
            minHeight: { xs: "64px !important", sm: "60px !important" },
          }}
        >
          <IconButton
            onClick={() => setSidebarOpen((prev) => !prev)}
            edge="start"
            aria-label={sidebarOpen ? "Hide menu" : "Show menu"}
            sx={{
              width: 38,
              height: 38,
              borderRadius: 2,
              border: "1px solid",
              borderColor: alpha(activeAccent, isDarkMode ? 0.28 : 0.14),
              bgcolor: alpha(activeAccent, isDarkMode ? 0.16 : 0.05),
            }}
          >
            <MenuRoundedIcon sx={{ fontSize: 18 }} />
          </IconButton>

          <Stack sx={{ flexGrow: 1, minWidth: 0 }}>
            <Stack direction="row" spacing={0.75} useFlexGap flexWrap="wrap" alignItems="center" sx={{ mb: 0.25 }}>
              <Chip
                label={activeContext.group?.label ?? "Executive"}
                size="small"
                sx={{
                  height: 20,
                  borderRadius: 999,
                  bgcolor: alpha(activeAccent, isDarkMode ? 0.2 : 0.08),
                  color: activeAccent,
                  border: "1px solid",
                  borderColor: alpha(activeAccent, isDarkMode ? 0.34 : 0.14),
                  ".MuiChip-label": { px: 0.9, fontSize: 9.8, fontWeight: 800, letterSpacing: "0.04em" },
                }}
              />
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: 10.4 }}>
                {activeLabel}
              </Typography>
            </Stack>
            <Typography variant="subtitle2" fontWeight={900} sx={{ fontSize: 13.8, lineHeight: 1.08 }}>
              Admin Control Plane
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ fontSize: 10.2 }}>
              {activeDescription}
            </Typography>
          </Stack>

          <Stack direction="row" spacing={0.75} alignItems="center" sx={{ display: { xs: "none", md: "flex" } }}>
            <Chip
              label={liveStatusLabel}
              size="small"
              color={moderationBadges.total > 0 ? "warning" : "success"}
              variant={moderationBadges.total > 0 ? "filled" : "outlined"}
              sx={{ height: 22, ".MuiChip-label": { px: 1, fontSize: 10.2, fontWeight: 800 } }}
            />
            <Chip
              label={role ?? "ADMIN"}
              size="small"
              variant="outlined"
              sx={{
                height: 22,
                borderColor: alpha(activeAccent, isDarkMode ? 0.32 : 0.16),
                ".MuiChip-label": { px: 1, fontSize: 10.2, fontWeight: 700 },
              }}
            />
          </Stack>

          <Box
            sx={{
              display: "grid",
              placeItems: "center",
              width: 38,
              height: 38,
              borderRadius: 2,
              border: "1px solid",
              borderColor: alpha(activeAccent, isDarkMode ? 0.28 : 0.14),
              bgcolor: alpha(activeAccent, isDarkMode ? 0.14 : 0.05),
            }}
          >
            <ThemeToggle />
          </Box>
          <SoftButton
            onClick={onLogout}
            variant="contained"
            color="error"
            size="small"
            sx={{
              px: { xs: 1.15, sm: 1.6 },
              minWidth: { xs: "auto", sm: 94 },
              borderRadius: 2.6,
              background: "linear-gradient(135deg, #c2410c, #ef4444)",
              boxShadow: "0 12px 26px rgba(239, 68, 68, 0.18)",
            }}
          >
            Logout
          </SoftButton>
        </Toolbar>
      </AppBar>

      <Box sx={{ display: "flex" }}>
        <Drawer
          variant={isDesktop ? "persistent" : "temporary"}
          open={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          ModalProps={{ keepMounted: true }}
          sx={{
            width: DRAWER_WIDTH,
            flexShrink: 0,
            "& .MuiDrawer-paper": {
              width: DRAWER_WIDTH,
              boxSizing: "border-box",
              top: { xs: 64, sm: 60 },
              height: { xs: "calc(100vh - 64px)", sm: "calc(100vh - 60px)" },
              borderRight: "1px solid",
              borderColor: alpha(activeAccent, isDarkMode ? 0.22 : 0.12),
              bgcolor: alpha(theme.palette.background.paper, isDarkMode ? 0.9 : 0.82),
              backdropFilter: "blur(18px)",
              boxShadow: "none",
              overflowX: "hidden",
            },
          }}
        >
          {drawer}
        </Drawer>

        <Box
          component="main"
          sx={{
            flexGrow: 1,
            ml: isDesktop && sidebarOpen ? `${DRAWER_WIDTH}px` : 0,
            p: 0,
            width: "100%",
            maxWidth: "100%",
            transition: "margin-left 180ms ease",
          }}
        >
          <Toolbar sx={{ minHeight: { xs: 64, sm: 60 } }} />
          <Box
            sx={{
              minHeight: { xs: "calc(100vh - 64px)", sm: "calc(100vh - 60px)" },
              overflowX: "hidden",
              position: "relative",
              "&::before": {
                content: '""',
                position: "absolute",
                inset: "0 0 auto 0",
                height: 220,
                pointerEvents: "none",
                background: `linear-gradient(180deg, ${alpha(activeAccent, isDarkMode ? 0.12 : 0.06)} 0%, transparent 100%)`,
              },
            }}
          >
            <Box sx={{ position: "relative", zIndex: 1 }}>{children}</Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <Suspense fallback={null}>
      <AdminLayoutContent>{children}</AdminLayoutContent>
    </Suspense>
  );
}
