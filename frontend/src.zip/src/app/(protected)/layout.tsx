"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Box, useMediaQuery } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import Navbar from "@/components/Navbar";
import Sidebar from "@/components/Sidebar";
import { WORKSPACE_HEADER_HEIGHT, WORKSPACE_SIDEBAR_WIDTH } from "@/components/workspace-shell";
import { isTokenUsable, resolveWorkspaceRouteFromToken } from "@/lib/auth";
import { useChatInbox } from "@/lib/chatInbox";
import { useNotifications } from "@/lib/notifications";
import { getRoleFallbackRoute, isRoleAllowedOnPath } from "@/lib/role-mode";
import { bootstrapSession, useSession } from "@/lib/session";

export default function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const theme = useTheme();
  const isDesktop = useMediaQuery(theme.breakpoints.up("lg"));
  const connectInbox = useChatInbox((s) => s.connect);
  const connectNotifications = useNotifications((s) => s.connect);
  const role = useSession((s) => s.role);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [desktopSidebarVisible, setDesktopSidebarVisible] = useState(true);
  const [desktopSidebarWidth, setDesktopSidebarWidth] = useState(WORKSPACE_SIDEBAR_WIDTH);

  useEffect(() => {
    bootstrapSession();
    const token = localStorage.getItem("auth_token");
    if (!isTokenUsable(token)) {
      localStorage.removeItem("auth_token");
      router.replace("/login");
      return;
    }

    const targetRoute = resolveWorkspaceRouteFromToken(token);
    if (targetRoute === "/admin") {
      router.replace("/admin");
      return;
    }

    void connectNotifications();
    void connectInbox();
  }, [connectInbox, connectNotifications, router]);

  useEffect(() => {
    if (!role) return;
    if (!isRoleAllowedOnPath(pathname, role)) {
      router.replace(getRoleFallbackRoute(role));
    }
  }, [pathname, role, router]);

  useEffect(() => {
    if (isDesktop) {
      setSidebarOpen(false);
    }
  }, [isDesktop]);

  const handleMenuToggle = () => {
    if (isDesktop) {
      setDesktopSidebarVisible((visible) => !visible);
      return;
    }

    setSidebarOpen((open) => !open);
  };

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "background.default" }}>
      <Navbar onMenuToggle={handleMenuToggle} />
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        desktopVisible={desktopSidebarVisible}
        onDesktopWidthChange={setDesktopSidebarWidth}
      />

      <Box
        component="main"
        sx={{
          pt: `${WORKSPACE_HEADER_HEIGHT}px`,
          minHeight: "100vh",
          ml: { lg: `${desktopSidebarWidth}px` },
          width: { lg: `calc(100% - ${desktopSidebarWidth}px)` },
          transition: "margin-left 220ms ease, width 220ms ease",
        }}
      >
        <Box sx={{ p: { xs: 2, md: 3 } }}>{children}</Box>
      </Box>
    </Box>
  );
}
