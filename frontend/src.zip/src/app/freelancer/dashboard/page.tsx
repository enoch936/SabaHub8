"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Box,
  CardContent,
  Chip,
  CircularProgress,
  Grid,
  LinearProgress,
  Stack,
  Typography,
} from "@mui/material";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";
import DescriptionIcon from "@mui/icons-material/Description";
import WorkIcon from "@mui/icons-material/Work";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import SendIcon from "@mui/icons-material/Send";
import SoftButton from "@/components/mui/SoftButton";
import SoftCard from "@/components/mui/SoftCard";
import { api } from "@/lib/api";

interface FreelancerAnalytics {
  totalEarnings: number;
  currentBalance: number;
  pendingBalance: number;
  completedProjects: number;
  activeProjects: number;
  totalProposals: number;
  acceptedProposals: number;
  successRate: number;
  rating: number;
  reviewCount: number;
  jobSuccessScore: number;
}

interface Contract {
  id: string;
  projectTitle: string;
  employerName: string;
  status: string;
  totalAmount: number;
  startDate: string;
  deadline: string;
  workType: string;
}

interface Proposal {
  id: string;
  projectTitle: string;
  bidAmount: number;
  status: string;
  submittedAt: string;
}

export default function FreelancerDashboard() {
  const [analytics, setAnalytics] = useState<FreelancerAnalytics | null>(null);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const results = await Promise.allSettled([
          api.get("/freelancer/workspace/analytics"),
          api.get("/freelancer/workspace/contracts"),
          api.get("/freelancer/workspace/proposals"),
        ]);

        const analyticsRes = results[0];
        const contractsRes = results[1];
        const proposalsRes = results[2];

        if (analyticsRes.status === "fulfilled" && analyticsRes.value.status < 400) {
          setAnalytics(analyticsRes.value.data as FreelancerAnalytics);
        }
        if (contractsRes.status === "fulfilled" && contractsRes.value.status < 400) {
          setContracts((contractsRes.value.data as Contract[]) || []);
        }
        if (proposalsRes.status === "fulfilled" && proposalsRes.value.status < 400) {
          setProposals((proposalsRes.value.data as Proposal[]) || []);
        }

        const allFailed = [analyticsRes, contractsRes, proposalsRes].every(
          (res) => res.status === "rejected" || (res.status === "fulfilled" && res.value.status >= 400),
        );
        if (allFailed) {
          setError("Failed to load freelancer workspace data.");
        }
      } catch {
        setError("Failed to load freelancer workspace data.");
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, []);

  const statsCards = useMemo(
    () => [
      {
        title: "Total Earnings",
        value: `$${analytics?.totalEarnings.toLocaleString() || 0}`,
        icon: <AttachMoneyIcon />,
        note: "All-time",
        gradient: "linear-gradient(135deg, #0b5bd1 0%, #3b82f6 100%)",
      },
      {
        title: "Current Balance",
        value: `$${analytics?.currentBalance.toLocaleString() || 0}`,
        icon: <TrendingUpIcon />,
        note: `Pending $${analytics?.pendingBalance.toLocaleString() || 0}`,
        gradient: "linear-gradient(135deg, #0ea5e9 0%, #22d3ee 100%)",
      },
      {
        title: "Active Projects",
        value: String(analytics?.activeProjects || 0),
        icon: <WorkIcon />,
        note: `${analytics?.completedProjects || 0} completed`,
        gradient: "linear-gradient(135deg, #22c55e 0%, #84cc16 100%)",
      },
      {
        title: "Success Rate",
        value: `${analytics?.successRate.toFixed(1) || 0}%`,
        icon: <DescriptionIcon />,
        note: `${analytics?.rating.toFixed(1) || 0}★ average`,
        gradient: "linear-gradient(135deg, #f59e0b 0%, #f97316 100%)",
      },
    ],
    [analytics],
  );

  const activeContracts = contracts.filter((contract) => contract.status === "ACTIVE");

  if (loading) {
    return (
      <Box sx={{ minHeight: "65vh", display: "grid", placeItems: "center" }}>
        <Stack spacing={1} alignItems="center">
          <CircularProgress />
          <Typography>Loading freelancer workspace...</Typography>
        </Stack>
      </Box>
    );
  }

  return (
    <Stack spacing={2.2}>
      {error ? <Alert severity="error">{error}</Alert> : null}

      <SoftCard
        sx={{
          border: "none",
          color: "common.white",
          background:
            "linear-gradient(120deg, #043873 0%, #0b5bd1 56%, #22d3ee 100%), radial-gradient(840px 280px at 0% 0%, rgba(255,255,255,0.2), transparent 64%)",
        }}
      >
        <CardContent>
          <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" spacing={1.2}>
            <Stack spacing={0.6}>
              <Typography variant="overline" sx={{ opacity: 0.9 }} fontWeight={800}>
                Freelancer Workspace
              </Typography>
              <Typography variant="h4" fontWeight={900}>
                Delivery & Earnings Board
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.92, maxWidth: 760 }}>
                A static, sheet-style command board for proposals, contracts, productivity, and payout health.
              </Typography>
            </Stack>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={1}>
              <SoftButton component={Link} href="/freelancer/projects/search" variant="contained" startIcon={<SendIcon />} sx={{ bgcolor: "#fff", color: "#043873" }}>
                Find Projects
              </SoftButton>
              <SoftButton component={Link} href="/freelancer/earnings" variant="outlined" sx={{ color: "#fff", borderColor: "rgba(255,255,255,0.8)" }}>
                Earnings Sheet
              </SoftButton>
            </Stack>
          </Stack>
        </CardContent>
      </SoftCard>

      <Grid container spacing={1.25}>
        {statsCards.map((stat) => (
          <Grid key={stat.title} size={{ xs: 12, sm: 6, xl: 3 }}>
            <SoftCard sx={{ border: "none", color: "white", background: stat.gradient }}>
              <CardContent>
                <Stack direction="row" justifyContent="space-between" spacing={1}>
                  <Stack spacing={0.45}>
                    <Typography variant="body2" sx={{ opacity: 0.9 }}>
                      {stat.title}
                    </Typography>
                    <Typography variant="h4" fontWeight={900}>
                      {stat.value}
                    </Typography>
                    <Typography variant="caption" sx={{ opacity: 0.9 }}>
                      {stat.note}
                    </Typography>
                  </Stack>
                  <Box sx={{ opacity: 0.85 }}>{stat.icon}</Box>
                </Stack>
              </CardContent>
            </SoftCard>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2}>
        <Grid size={{ xs: 12, lg: 7 }}>
          <SoftCard sx={{ border: "1px solid", borderColor: "divider" }}>
            <CardContent>
              <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1.2 }}>
                <Typography variant="h6" fontWeight={800}>
                  Active Contracts
                </Typography>
                <Chip label={`${activeContracts.length} active`} size="small" color="success" variant="outlined" />
              </Stack>
              <Stack spacing={1}>
                {activeContracts.slice(0, 4).map((contract) => (
                  <Box key={contract.id} sx={{ p: 1.1, borderRadius: 2, border: "1px solid", borderColor: "divider" }}>
                    <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" spacing={1}>
                      <Stack spacing={0.3}>
                        <Typography variant="subtitle2" fontWeight={800}>
                          {contract.projectTitle}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {contract.employerName} • {contract.workType}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Deadline {new Date(contract.deadline).toLocaleDateString()}
                        </Typography>
                      </Stack>
                      <Stack direction={{ xs: "row", md: "column" }} spacing={0.6} alignItems={{ md: "flex-end" }}>
                        <Typography variant="subtitle2" fontWeight={900}>
                          ${contract.totalAmount.toLocaleString()}
                        </Typography>
                        <Chip size="small" label={contract.status} color="success" />
                      </Stack>
                    </Stack>
                  </Box>
                ))}
                {activeContracts.length === 0 ? <Typography color="text.secondary">No active contracts yet.</Typography> : null}
              </Stack>
            </CardContent>
          </SoftCard>
        </Grid>

        <Grid size={{ xs: 12, lg: 5 }}>
          <SoftCard sx={{ border: "1px solid", borderColor: "divider", height: "100%" }}>
            <CardContent>
              <Typography variant="h6" fontWeight={800} sx={{ mb: 1.2 }}>
                Proposal Pipeline
              </Typography>
              <Stack spacing={1}>
                {[
                  { label: "Submitted", value: analytics?.totalProposals || proposals.length, progress: 100 },
                  { label: "Accepted", value: analytics?.acceptedProposals || proposals.filter((p) => p.status === "ACCEPTED").length, progress: analytics?.totalProposals ? ((analytics.acceptedProposals || 0) / Math.max(1, analytics.totalProposals)) * 100 : 0 },
                  { label: "Job Success", value: `${analytics?.jobSuccessScore?.toFixed(1) || "0.0"}%`, progress: analytics?.jobSuccessScore || 0 },
                ].map((lane) => (
                  <Box key={lane.label} sx={{ p: 1, borderRadius: 2, border: "1px solid", borderColor: "divider" }}>
                    <Stack direction="row" justifyContent="space-between" sx={{ mb: 0.5 }}>
                      <Typography variant="body2">{lane.label}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {lane.value}
                      </Typography>
                    </Stack>
                    <LinearProgress variant="determinate" value={Math.max(0, Math.min(100, Number(lane.progress) || 0))} sx={{ borderRadius: 999 }} />
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </SoftCard>
        </Grid>
      </Grid>

      <Grid container spacing={1.25}>
        {[
          { title: "Profile", href: "/freelancer/profile", icon: <AccountCircleIcon /> },
          { title: "Time Tracker", href: "/freelancer/time-tracker", icon: <AccessTimeIcon /> },
          { title: "Earnings", href: "/freelancer/earnings", icon: <AttachMoneyIcon /> },
          { title: "Projects", href: "/freelancer/projects/search", icon: <WorkIcon /> },
        ].map((action) => (
          <Grid key={action.title} size={{ xs: 12, sm: 6, md: 3 }}>
            <SoftCard component={Link} href={action.href} sx={{ border: "1px solid", borderColor: "divider", textDecoration: "none" }}>
              <CardContent>
                <Stack spacing={0.7}>
                  <Box sx={{ color: "primary.main" }}>{action.icon}</Box>
                  <Typography fontWeight={800}>{action.title}</Typography>
                </Stack>
              </CardContent>
            </SoftCard>
          </Grid>
        ))}
      </Grid>
    </Stack>
  );
}
