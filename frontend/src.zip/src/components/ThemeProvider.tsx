"use client";

import { ReactNode, useEffect } from "react";

type ThemeMode = "light" | "dark";

function getSystemMode(): ThemeMode {
  if (typeof window === "undefined") return "light";
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function getResolvedMode(): ThemeMode {
  if (typeof window === "undefined") return "light";
  const saved = localStorage.getItem("sabahub-theme");
  if (saved === "light" || saved === "dark") return saved;
  return getSystemMode();
}

function applyMode(mode: ThemeMode) {
  const root = document.documentElement;
  root.classList.remove("dark", "light");
  root.classList.add(mode);
  root.setAttribute("data-theme", mode);
  root.style.colorScheme = mode;
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  useEffect(() => {
    const sync = () => applyMode(getResolvedMode());
    sync();

    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onSystemChange = () => {
      const saved = localStorage.getItem("sabahub-theme");
      if (saved !== "light" && saved !== "dark") sync();
    };

    if (typeof media.addEventListener === "function") {
      media.addEventListener("change", onSystemChange);
    } else {
      media.addListener(onSystemChange);
    }

    const onStorage = (event: StorageEvent) => {
      if (event.key === "sabahub-theme") sync();
    };
    window.addEventListener("storage", onStorage);

    return () => {
      if (typeof media.removeEventListener === "function") {
        media.removeEventListener("change", onSystemChange);
      } else {
        media.removeListener(onSystemChange);
      }
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  return <>{children}</>;
}
