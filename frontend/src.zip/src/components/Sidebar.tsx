"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import {
  AccountBalanceWallet,
  AssignmentTurnedIn,
  ChevronLeft,
  ChevronRight,
  DashboardRounded,
  Description,
  Forum,
  Groups,
  HelpOutline,
  Logout,
  PostAdd,
  Psychology,
  QueryStats,
  Settings,
  Storefront,
  Work,
} from "@mui/icons-material";
import {
  Badge,
  Box,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Stack,
  Tooltip,
  Typography,
  useMediaQuery,
} from "@mui/material";
import { alpha, useTheme } from "@mui/material/styles";
import { useChatInbox } from "@/lib/chatInbox";
import { useSession } from "@/lib/session";
import { workspaceRoutes } from "@/lib/workspace-routes";
import {
  WORKSPACE_HEADER_HEIGHT,
  WORKSPACE_MOBILE_SIDEBAR_WIDTH,
  WORKSPACE_SIDEBAR_COLLAPSED_WIDTH,
  WORKSPACE_SIDEBAR_WIDTH,
} from "@/components/workspace-shell";

type NavItem = {
  id: string;
  href: string;
  label: string;
  icon: React.ReactNode;
  matchNested?: boolean;
};

type WorkspaceRole = "ADMIN" | "EMPLOYER" | "FREELANCER";

const NAV_ITEMS: Record<WorkspaceRole, { primary: NavItem[]; utility: NavItem[] }> = {
  ADMIN: {
    primary: [
      { id: "admin-dashboard", href: "/admin", label: "Dashboard", icon: <DashboardRounded /> },
      { id: "admin-jobs", href: "/jobs", label: "Marketplace Jobs", icon: <Work />, matchNested: true },
      { id: "admin-analytics", href: workspaceRoutes.analytics, label: "Analytics", icon: <QueryStats />, matchNested: true },
      { id: "admin-content", href: workspaceRoutes.help, label: "Content", icon: <AssignmentTurnedIn />, matchNested: true },
      { id: "admin-disputes", href: "/admin/disputes", label: "Disputes", icon: <Description />, matchNested: true },
    ],
    utility: [
      { id: "admin-messages", href: "/chat", label: "Messages", icon: <Forum />, matchNested: true },
      { id: "admin-settings", href: workspaceRoutes.settings, label: "Settings", icon: <Settings />, matchNested: true },
    ],
  },
  EMPLOYER: {
    primary: [
      { id: "employer-workspace", href: workspaceRoutes.home, label: "Workspace", icon: <DashboardRounded /> },
      { id: "employer-jobs", href: workspaceRoutes.manageJobs, label: "My Jobs", icon: <Work />, matchNested: true },
      { id: "employer-find-talent", href: workspaceRoutes.home, label: "Find Talent", icon: <Groups />, matchNested: true },
      { id: "employer-post-brief", href: workspaceRoutes.createJob, label: "Post Brief", icon: <PostAdd />, matchNested: true },
      { id: "employer-contracts", href: workspaceRoutes.contracts, label: "Contracts", icon: <Description />, matchNested: true },
      { id: "employer-analytics", href: workspaceRoutes.analytics, label: "Analytics", icon: <QueryStats />, matchNested: true },
      { id: "employer-wallet", href: workspaceRoutes.wallet, label: "Wallet", icon: <AccountBalanceWallet />, matchNested: true },
    ],
    utility: [
      { id: "employer-messages", href: "/chat", label: "Messages", icon: <Forum />, matchNested: true },
      { id: "employer-ai", href: workspaceRoutes.assistant, label: "AI Workspace", icon: <Psychology />, matchNested: true },
      { id: "employer-settings", href: workspaceRoutes.settings, label: "Company Settings", icon: <Settings />, matchNested: true },
    ],
  },
  FREELANCER: {
    primary: [
      { id: "freelancer-workspace", href: workspaceRoutes.home, label: "Workspace", icon: <DashboardRounded /> },
      { id: "freelancer-find-jobs", href: workspaceRoutes.home, label: "Find Jobs", icon: <Work />, matchNested: true },
      { id: "freelancer-my-jobs", href: workspaceRoutes.manageJobs, label: "My Jobs", icon: <Storefront />, matchNested: true },
      { id: "freelancer-projects", href: workspaceRoutes.home, label: "Projects", icon: <AssignmentTurnedIn />, matchNested: true },
      { id: "freelancer-contracts", href: workspaceRoutes.contracts, label: "Contracts", icon: <Description />, matchNested: true },
      { id: "freelancer-earnings", href: workspaceRoutes.wallet, label: "Earnings", icon: <QueryStats />, matchNested: true },
      { id: "freelancer-wallet", href: workspaceRoutes.wallet, label: "Wallet", icon: <AccountBalanceWallet />, matchNested: true },
    ],
    utility: [
      { id: "freelancer-messages", href: "/chat", label: "Messages", icon: <Forum />, matchNested: true },
      { id: "freelancer-ai", href: workspaceRoutes.assistant, label: "AI Workspace", icon: <Psychology />, matchNested: true },
      { id: "freelancer-settings", href: workspaceRoutes.settings, label: "Settings", icon: <Settings />, matchNested: true },
    ],
  },
};

export default function Sidebar({
  isOpen,
  onClose,
  desktopVisible = true,
  onDesktopWidthChange,
}: {
  isOpen: boolean;
  onClose: () => void;
  desktopVisible?: boolean;
  onDesktopWidthChange?: (width: number) => void;
}) {
  const pathname = usePathname();
  const theme = useTheme();
  const isDesktop = useMediaQuery(theme.breakpoints.up("lg"));
  const role = (useSession((s) => s.role) || "FREELANCER") as WorkspaceRole;
  const clear = useSession((s) => s.clear);
  const unreadMessages = useChatInbox((s) => s.unreadMessages);
  const [collapsed, setCollapsed] = useState(false);
  const [rememberedItemId, setRememberedItemId] = useState<string>("");

  useEffect(() => {
    if (typeof window === "undefined") return;
    const storedValue = window.localStorage.getItem("sidebar_collapsed");
    if (storedValue !== null) {
      setCollapsed(storedValue === "true");
    }
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem("sidebar_collapsed", String(collapsed));
  }, [collapsed]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const storedValue = window.localStorage.getItem("main_sidebar_active_item");
    if (storedValue) {
      setRememberedItemId(storedValue);
    }
  }, []);

  const desktopWidth = collapsed ? WORKSPACE_SIDEBAR_COLLAPSED_WIDTH : WORKSPACE_SIDEBAR_WIDTH;
  const activeDesktopWidth = desktopVisible ? desktopWidth : 0;

  useEffect(() => {
    onDesktopWidthChange?.(activeDesktopWidth);
  }, [activeDesktopWidth, onDesktopWidthChange]);

  const navConfig = useMemo(() => NAV_ITEMS[role] || NAV_ITEMS.FREELANCER, [role]);

  const homeRouteIds = useMemo(
    () => navConfig.primary.filter((item) => item.href === workspaceRoutes.home).map((item) => item.id),
    [navConfig],
  );

  const walletRouteIds = useMemo(
    () => navConfig.primary.filter((item) => item.href === workspaceRoutes.wallet).map((item) => item.id),
    [navConfig],
  );

  const handleLogout = () => {
    clear();
    localStorage.removeItem("auth_token");
    window.location.href = "/login";
  };

  const isActive = (item: NavItem) => {
    if (item.href === workspaceRoutes.home) {
      if (pathname !== workspaceRoutes.home) return false;
      // Keep the clicked item pinned when multiple nav entries share /jobs.
      if (homeRouteIds.length > 1) {
        return rememberedItemId ? rememberedItemId === item.id : homeRouteIds[0] === item.id;
      }
      return true;
    }

    if (item.href === workspaceRoutes.wallet && walletRouteIds.length > 1) {
      if (!(pathname === workspaceRoutes.wallet || pathname?.startsWith(`${workspaceRoutes.wallet}/`))) return false;
      return rememberedItemId ? rememberedItemId === item.id : walletRouteIds[0] === item.id;
    }

    if (item.href === "/admin") {
      return pathname === "/admin";
    }

    if (item.matchNested) {
      return pathname === item.href || pathname?.startsWith(`${item.href}/`);
    }

    return pathname === item.href;
  };

  const renderNavItem = (item: NavItem) => {
    const active = isActive(item);
    const compact = isDesktop && collapsed;
    const showMessageBadge = item.href === "/chat" && unreadMessages > 0;

    const row = (
      <ListItemButton
        key={item.id}
        selected={active}
        aria-current={active ? "page" : undefined}
        component={Link}
        href={item.href}
        onClick={() => {
          setRememberedItemId(item.id);
          if (typeof window !== "undefined") {
            window.localStorage.setItem("main_sidebar_active_item", item.id);
          }
          if (!isDesktop) onClose();
        }}
        sx={{
          minHeight: 44,
          px: compact ? 1.25 : 1.5,
          py: 1.25,
          borderRadius: "8px",
          justifyContent: compact ? "center" : "flex-start",
          mb: 0.35,
          color: active
            ? theme.palette.common.white
            : "#717182",
          bgcolor: active
            ? theme.palette.mode === "light"
              ? "#111827"
              : alpha(theme.palette.common.white, 0.12)
            : "transparent",
          "&:hover": {
            bgcolor: active
              ? theme.palette.mode === "light"
                ? "#111827"
                : alpha(theme.palette.common.white, 0.18)
              : alpha(theme.palette.text.primary, theme.palette.mode === "light" ? 0.05 : 0.08),
            color: active ? theme.palette.common.white : "#030213",
          },
          "& .MuiListItemIcon-root": {
            minWidth: compact ? 0 : 36,
            color: active ? theme.palette.common.white : "#717182",
          },
        }}
      >
        <ListItemIcon>
          {showMessageBadge ? (
            <Badge badgeContent={unreadMessages > 99 ? "99+" : unreadMessages} color="error">
              {item.icon}
            </Badge>
          ) : (
            item.icon
          )}
        </ListItemIcon>
        {!compact ? (
          <ListItemText
            primary={item.label}
            primaryTypographyProps={{ fontSize: 14, fontWeight: 500 }}
          />
        ) : null}
      </ListItemButton>
    );

    if (compact) {
      return (
        <Tooltip key={item.id} title={item.label} placement="right">
          {row}
        </Tooltip>
      );
    }

    return row;
  };

  const content = (
    <Box
      sx={{
        width: isDesktop ? desktopWidth : WORKSPACE_MOBILE_SIDEBAR_WIDTH,
        height: "100%",
        display: "flex",
        flexDirection: "column",
        bgcolor: "background.paper",
        borderRight: "1px solid",
        borderColor: "divider",
      }}
    >
      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        sx={{
          minHeight: 64,
          px: 2,
          borderBottom: "1px solid",
          borderColor: "divider",
        }}
      >
        {isDesktop && collapsed ? null : (
          <Stack direction="row" alignItems="center" spacing={1.1} sx={{ minWidth: 0 }}>
            <Box
              sx={{
                width: 32,
                height: 32,
                borderRadius: "8px",
                background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
                flexShrink: 0,
              }}
            />
            <Typography variant="subtitle1" fontWeight={600} noWrap>
              SabaHub
            </Typography>
          </Stack>
        )}

        {isDesktop ? (
          <IconButton
            onClick={() => setCollapsed((current) => !current)}
            sx={{
              ml: "auto",
              p: 1,
              borderRadius: "8px",
            }}
          >
            {collapsed ? <ChevronRight /> : <ChevronLeft />}
          </IconButton>
        ) : null}
      </Stack>

      <Box sx={{ flex: 1, overflowY: "auto", px: 1.5, py: 2 }}>
        <List dense disablePadding>
          {navConfig.primary.map(renderNavItem)}
        </List>
      </Box>

      <Divider />

      <Box sx={{ p: 1.5 }}>
        <List dense disablePadding>
          {navConfig.utility.map(renderNavItem)}

          {isDesktop && collapsed ? (
            <Tooltip title="Help" placement="right">
              <ListItemButton
                sx={{
                  minHeight: 44,
                  px: 1.25,
                  py: 1.25,
                  borderRadius: "8px",
                  justifyContent: "center",
                  mb: 0.35,
                  color: "#717182",
                }}
              >
                <ListItemIcon sx={{ minWidth: 0, color: "inherit" }}>
                  <HelpOutline />
                </ListItemIcon>
              </ListItemButton>
            </Tooltip>
          ) : (
            <ListItemButton
              sx={{
                minHeight: 44,
                px: 1.6,
                py: 1.25,
                borderRadius: "8px",
                justifyContent: "flex-start",
                mb: 0.35,
                color: "#717182",
              }}
            >
              <ListItemIcon sx={{ minWidth: 36, color: "inherit" }}>
                <HelpOutline />
              </ListItemIcon>
              <ListItemText primary="Help" primaryTypographyProps={{ fontSize: 14, fontWeight: 600 }} />
            </ListItemButton>
          )}
        </List>
      </Box>

      <Divider />

      <Box sx={{ p: 1.5 }}>
        <ListItemButton
          onClick={handleLogout}
          sx={{
            minHeight: 44,
            px: isDesktop && collapsed ? 1.25 : 1.6,
            py: 1.25,
            borderRadius: "8px",
            justifyContent: isDesktop && collapsed ? "center" : "flex-start",
            color: "#717182",
            "&:hover": {
              color: "error.main",
              bgcolor: alpha(theme.palette.error.main, 0.08),
            },
          }}
        >
          <ListItemIcon sx={{ minWidth: isDesktop && collapsed ? 0 : 36 }}>
            <Logout />
          </ListItemIcon>
          {!(isDesktop && collapsed) ? <ListItemText primary="Logout" primaryTypographyProps={{ fontSize: 14, fontWeight: 500 }} /> : null}
        </ListItemButton>
      </Box>
    </Box>
  );

  if (isDesktop) {
    if (!desktopVisible) {
      return null;
    }

    return (
      <Box
        sx={{
          position: "fixed",
          top: WORKSPACE_HEADER_HEIGHT,
          left: 0,
          bottom: 0,
          width: desktopWidth,
          zIndex: (muiTheme) => muiTheme.zIndex.drawer + 1,
        }}
      >
        {content}
      </Box>
    );
  }

  return (
    <Drawer
      open={isOpen}
      onClose={onClose}
      variant="temporary"
      ModalProps={{ keepMounted: true }}
      PaperProps={{
        sx: {
          width: WORKSPACE_MOBILE_SIDEBAR_WIDTH,
          top: WORKSPACE_HEADER_HEIGHT,
          height: `calc(100% - ${WORKSPACE_HEADER_HEIGHT}px)`,
        },
      }}
    >
      {content}
    </Drawer>
  );
}
