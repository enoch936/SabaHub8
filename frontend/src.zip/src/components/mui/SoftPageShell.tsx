"use client";

import { ReactNode } from "react";
import { alpha } from "@mui/material/styles";
import { Box, Container, ContainerProps } from "@mui/material";

type SoftPageShellProps = {
  children: ReactNode;
  containerProps?: ContainerProps;
  noContainer?: boolean;
  py?: number;
};

export default function SoftPageShell({ children, containerProps, noContainer = false, py = 3 }: SoftPageShellProps) {
  return (
    <Box
      className="sheet-shell"
      sx={{
        minHeight: "100vh",
        py,
        position: "relative",
        overflow: "clip",
        isolation: "isolate",
        "&::before": {
          content: '""',
          position: "absolute",
          inset: 0,
          pointerEvents: "none",
          background: (theme) =>
            `radial-gradient(780px 360px at 0% 0%, ${alpha(theme.palette.primary.main, theme.palette.mode === "light" ? 0.08 : 0.2)} 0%, transparent 68%),
             radial-gradient(680px 320px at 100% 0%, ${alpha(theme.palette.secondary.main, theme.palette.mode === "light" ? 0.08 : 0.16)} 0%, transparent 68%)`,
          zIndex: 0,
        },
        "&::after": {
          content: '""',
          position: "absolute",
          inset: "auto -20% -30% auto",
          width: { xs: 260, md: 420 },
          height: { xs: 260, md: 420 },
          pointerEvents: "none",
          filter: "blur(80px)",
          borderRadius: "50%",
          bgcolor: (theme) => alpha(theme.palette.primary.main, theme.palette.mode === "light" ? 0.12 : 0.26),
          zIndex: 0,
        },
      }}
    >
      {noContainer ? (
        <Box sx={{ position: "relative", zIndex: 1 }}>{children}</Box>
      ) : (
        <Container maxWidth="xl" className="sheet-container" sx={{ position: "relative", zIndex: 1 }} {...containerProps}>
          {children}
        </Container>
      )}
    </Box>
  );
}
