"use client";

import { ReactNode, useEffect, useMemo, useState } from "react";
import { CssBaseline, StyledEngineProvider, ThemeProvider, createTheme, responsiveFontSizes } from "@mui/material";
import { alpha, darken, lighten } from "@mui/material/styles";

function detectMode(): "light" | "dark" {
  if (typeof window === "undefined") return "light";

  const root = document.documentElement;
  const dataTheme = root.getAttribute("data-theme");
  if (dataTheme === "dark" || dataTheme === "light") return dataTheme;
  if (root.classList.contains("dark")) return "dark";
  if (window.matchMedia("(prefers-color-scheme: dark)").matches) return "dark";
  return "light";
}

function hasStoredMode(): boolean {
  if (typeof window === "undefined") return false;
  const saved = localStorage.getItem("sabahub-theme");
  return saved === "light" || saved === "dark";
}

export default function MuiAppProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<"light" | "dark">("light");

  useEffect(() => {
    const sync = () => setMode(detectMode());
    sync();

    const root = document.documentElement;
    const observer = new MutationObserver(sync);
    observer.observe(root, { attributes: true, attributeFilter: ["class", "data-theme"] });

    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onSystemChange = () => {
      if (!hasStoredMode()) sync();
    };
    if (typeof media.addEventListener === "function") {
      media.addEventListener("change", onSystemChange);
    } else {
      media.addListener(onSystemChange);
    }

    const onStorage = (event: StorageEvent) => {
      if (event.key === "sabahub-theme") sync();
    };
    window.addEventListener("storage", onStorage);

    return () => {
      observer.disconnect();
      if (typeof media.removeEventListener === "function") {
        media.removeEventListener("change", onSystemChange);
      } else {
        media.removeListener(onSystemChange);
      }
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("light", "dark");
    root.classList.add(mode);
    root.setAttribute("data-theme", mode);
    root.style.colorScheme = mode;
  }, [mode]);

  const theme = useMemo(() => {
    const isLight = mode === "light";
    const transition = "background-color 160ms ease, color 160ms ease, border-color 160ms ease, box-shadow 160ms ease";

    const primary = isLight ? "#0ea5e9" : "#38bdf8";
    const secondary = isLight ? "#14b8a6" : "#2dd4bf";
    const bg = isLight ? "#f4f8ff" : "#070f1d";
    const paper = isLight ? "#fbfdff" : "#0f1a2e";

    const base = createTheme({
      palette: {
        mode,
        primary: {
          main: primary,
          light: lighten(primary, 0.16),
          dark: darken(primary, 0.22),
          contrastText: "#03111f",
        },
        secondary: {
          main: secondary,
          light: lighten(secondary, 0.12),
          dark: darken(secondary, 0.2),
          contrastText: "#032420",
        },
        success: {
          main: isLight ? "#16a34a" : "#4ade80",
        },
        warning: {
          main: isLight ? "#f59e0b" : "#fbbf24",
        },
        error: {
          main: isLight ? "#ef4444" : "#f87171",
        },
        text: {
          primary: isLight ? "#0b1220" : "#e2ebff",
          secondary: isLight ? "#4a5b7a" : "#9fb1d9",
        },
        divider: isLight ? "rgba(13, 27, 55, 0.12)" : "rgba(144, 168, 212, 0.26)",
        background: {
          default: bg,
          paper,
        },
      },
      shape: {
        borderRadius: 16,
      },
      typography: {
        fontFamily: "var(--font-sans), ui-sans-serif, sans-serif",
        h1: { fontFamily: "var(--font-display), var(--font-sans), sans-serif", fontWeight: 700, letterSpacing: "-0.03em", lineHeight: 1.02, fontSize: "clamp(2.2rem, 5vw, 3.7rem)" },
        h2: { fontFamily: "var(--font-display), var(--font-sans), sans-serif", fontWeight: 700, letterSpacing: "-0.026em", lineHeight: 1.05, fontSize: "clamp(1.95rem, 4vw, 3.2rem)" },
        h3: { fontFamily: "var(--font-display), var(--font-sans), sans-serif", fontWeight: 700, letterSpacing: "-0.022em", lineHeight: 1.08, fontSize: "clamp(1.6rem, 3vw, 2.45rem)" },
        h4: { fontFamily: "var(--font-display), var(--font-sans), sans-serif", fontWeight: 670, letterSpacing: "-0.018em", lineHeight: 1.12, fontSize: "clamp(1.32rem, 2.2vw, 1.95rem)" },
        h5: { fontFamily: "var(--font-display), var(--font-sans), sans-serif", fontWeight: 650, letterSpacing: "-0.014em", lineHeight: 1.14, fontSize: "clamp(1.16rem, 1.8vw, 1.5rem)" },
        h6: { fontFamily: "var(--font-display), var(--font-sans), sans-serif", fontWeight: 640, letterSpacing: "-0.012em", lineHeight: 1.18, fontSize: "clamp(1.02rem, 1.1vw, 1.2rem)" },
        body1: { fontSize: "0.98rem", lineHeight: 1.66 },
        body2: { fontSize: "0.9rem", lineHeight: 1.58 },
        caption: { fontSize: "0.76rem", lineHeight: 1.5, letterSpacing: "0.02em" },
        button: { fontWeight: 620, textTransform: "none", letterSpacing: "0.01em" },
        overline: { fontWeight: 700, letterSpacing: "0.08em", fontSize: "0.7rem" },
      },
      components: {
        MuiCssBaseline: {
          styleOverrides: {
            ":root": {
              colorScheme: mode,
            },
            body: {
              backgroundColor: bg,
              color: isLight ? "#0b1220" : "#e2ebff",
              backgroundImage: isLight
                ? "radial-gradient(950px 420px at -15% -10%, rgba(56,189,248,0.18) 0%, transparent 65%), radial-gradient(900px 420px at 115% -5%, rgba(45,212,191,0.14) 0%, transparent 70%), linear-gradient(180deg, #f8fbff 0%, #f3f7ff 100%)"
                : "radial-gradient(1000px 460px at -10% -10%, rgba(56,189,248,0.2) 0%, transparent 66%), radial-gradient(760px 360px at 110% -5%, rgba(45,212,191,0.16) 0%, transparent 70%), linear-gradient(180deg, #091225 0%, #060d1a 100%)",
              transition: "background-color 240ms ease, color 240ms ease",
            },
            "*": {
              boxSizing: "border-box",
              WebkitTapHighlightColor: "transparent",
            },
            "*::selection": {
              backgroundColor: isLight ? "rgba(14,165,233,0.24)" : "rgba(45,212,191,0.3)",
            },
            "::-webkit-scrollbar": {
              width: 10,
              height: 10,
            },
            "::-webkit-scrollbar-track": {
              backgroundColor: isLight ? "rgba(148, 163, 184, 0.22)" : "rgba(15, 23, 42, 0.85)",
            },
            "::-webkit-scrollbar-thumb": {
              backgroundColor: isLight ? "rgba(94, 119, 160, 0.6)" : "rgba(110, 138, 190, 0.72)",
              borderRadius: 999,
            },
          },
        },
        MuiLink: {
          styleOverrides: {
            root: {
              textDecorationColor: alpha(primary, 0.35),
              textUnderlineOffset: 3,
              transition,
              "&:hover": {
                color: lighten(primary, isLight ? 0 : 0.2),
                textDecorationColor: alpha(primary, 0.8),
              },
            },
          },
        },
        MuiAppBar: {
          styleOverrides: {
            root: {
              transition,
              borderBottom: `1px solid ${isLight ? "rgba(12, 26, 51, 0.08)" : "rgba(127, 160, 220, 0.22)"}`,
              backdropFilter: "blur(20px)",
              backgroundImage: isLight
                ? "linear-gradient(135deg, rgba(255,255,255,0.86), rgba(248,252,255,0.76))"
                : "linear-gradient(135deg, rgba(9,17,34,0.86), rgba(7,14,30,0.82))",
            },
          },
        },
        MuiDrawer: {
          styleOverrides: {
            paper: {
              transition,
              backgroundImage: isLight
                ? "linear-gradient(180deg, rgba(251,253,255,0.96), rgba(245,250,255,0.94))"
                : "linear-gradient(180deg, rgba(13,24,46,0.95), rgba(9,17,33,0.95))",
            },
          },
        },
        MuiContainer: {
          styleOverrides: {
            root: {
              paddingLeft: 16,
              paddingRight: 16,
              "@media (min-width: 900px)": {
                paddingLeft: 24,
                paddingRight: 24,
              },
            },
          },
        },
        MuiPaper: {
          styleOverrides: {
            root: {
              borderRadius: 18,
              border: `1px solid ${isLight ? "rgba(12,26,51,0.1)" : "rgba(120,145,190,0.22)"}`,
              backgroundImage: isLight
                ? "linear-gradient(145deg, rgba(255,255,255,0.86), rgba(249,252,255,0.7))"
                : "linear-gradient(145deg, rgba(15,28,54,0.88), rgba(10,20,40,0.82))",
              backdropFilter: "blur(14px)",
              boxShadow: isLight ? "0 16px 42px rgba(12, 26, 51, 0.08)" : "0 20px 44px rgba(2, 8, 18, 0.48)",
              transition,
            },
          },
        },
        MuiCard: {
          styleOverrides: {
            root: {
              borderRadius: 20,
              border: `1px solid ${isLight ? "rgba(12,26,51,0.1)" : "rgba(120,145,190,0.24)"}`,
              backgroundImage: isLight
                ? "linear-gradient(145deg, rgba(255,255,255,0.92), rgba(246,251,255,0.76))"
                : "linear-gradient(145deg, rgba(14,27,53,0.9), rgba(8,17,34,0.84))",
              backdropFilter: "blur(14px)",
              boxShadow: isLight ? "0 18px 44px rgba(12, 26, 51, 0.09)" : "0 20px 48px rgba(2, 8, 18, 0.5)",
              transition,
              "&:hover": {
                boxShadow: isLight ? "0 20px 46px rgba(12, 26, 51, 0.1)" : "0 22px 50px rgba(2, 8, 18, 0.54)",
              },
            },
          },
        },
        MuiCardContent: {
          styleOverrides: {
            root: {
              padding: 18,
              "@media (min-width: 900px)": {
                padding: 22,
              },
              "&:last-child": {
                paddingBottom: 18,
                "@media (min-width: 900px)": {
                  paddingBottom: 22,
                },
              },
            },
          },
        },
        MuiButton: {
          defaultProps: {
            disableElevation: true,
          },
          styleOverrides: {
            root: {
              minHeight: 40,
              borderRadius: 12,
              transition,
            },
            contained: {
              color: isLight ? "#03111f" : "#061322",
              backgroundImage: "none",
              backgroundColor: primary,
              boxShadow: isLight ? "0 6px 14px rgba(14,165,233,0.22)" : "0 8px 18px rgba(45,212,191,0.22)",
              "&:hover": {
                backgroundImage: "none",
                backgroundColor: lighten(primary, 0.02),
              },
            },
            outlined: {
              borderColor: isLight ? "rgba(12,26,51,0.2)" : "rgba(136,164,212,0.38)",
              "&:hover": {
                borderColor: alpha(primary, 0.72),
                backgroundColor: alpha(primary, isLight ? 0.06 : 0.14),
              },
            },
            text: {
              "&:hover": {
                backgroundColor: alpha(primary, isLight ? 0.08 : 0.16),
              },
            },
          },
        },
        MuiIconButton: {
          styleOverrides: {
            root: {
              borderRadius: 12,
              transition,
              "&:hover": {
                backgroundColor: alpha(primary, isLight ? 0.1 : 0.2),
              },
            },
          },
        },
        MuiTextField: {
          defaultProps: {
            variant: "outlined",
            size: "small",
          },
        },
        MuiInputBase: {
          styleOverrides: {
            root: {
              borderRadius: 12,
              transition,
            },
          },
        },
        MuiOutlinedInput: {
          styleOverrides: {
            root: {
              borderRadius: 12,
              backgroundColor: isLight ? "rgba(255,255,255,0.68)" : "rgba(10,20,40,0.56)",
              "& .MuiOutlinedInput-notchedOutline": {
                borderColor: isLight ? "rgba(12,26,51,0.16)" : "rgba(122,146,191,0.35)",
              },
              "&:hover .MuiOutlinedInput-notchedOutline": {
                borderColor: alpha(primary, 0.64),
              },
              "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                borderColor: primary,
                borderWidth: 1.5,
              },
            },
            input: {
              paddingTop: 10,
              paddingBottom: 10,
            },
          },
        },
        MuiChip: {
          styleOverrides: {
            root: {
              borderRadius: 10,
              border: `1px solid ${isLight ? "rgba(12,26,51,0.12)" : "rgba(126,150,191,0.34)"}`,
              backdropFilter: "blur(10px)",
              transition,
            },
          },
        },
        MuiListItemButton: {
          styleOverrides: {
            root: {
              borderRadius: 12,
              transition,
              "&.Mui-selected": {
                backgroundColor: alpha(primary, isLight ? 0.12 : 0.24),
              },
            },
          },
        },
        MuiMenu: {
          styleOverrides: {
            paper: {
              borderRadius: 14,
            },
          },
        },
        MuiMenuItem: {
          styleOverrides: {
            root: {
              borderRadius: 10,
              margin: "2px 4px",
              transition,
            },
          },
        },
        MuiAlert: {
          styleOverrides: {
            root: {
              borderRadius: 12,
              border: `1px solid ${isLight ? "rgba(12,26,51,0.1)" : "rgba(126,150,191,0.28)"}`,
            },
          },
        },
        MuiTableCell: {
          styleOverrides: {
            root: {
              borderBottom: `1px solid ${isLight ? "rgba(12,26,51,0.08)" : "rgba(120,145,190,0.2)"}`,
            },
            head: {
              fontWeight: 700,
            },
          },
        },
        MuiTooltip: {
          styleOverrides: {
            tooltip: {
              borderRadius: 10,
              backgroundColor: isLight ? alpha("#081120", 0.88) : alpha("#030914", 0.9),
            },
          },
        },
      },
    });

    return responsiveFontSizes(base);
  }, [mode]);

  return (
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </ThemeProvider>
    </StyledEngineProvider>
  );
}
