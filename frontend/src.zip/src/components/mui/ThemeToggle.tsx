"use client";

import { useEffect, useState } from "react";
import { Box, IconButton, ToggleButton, ToggleButtonGroup, Tooltip } from "@mui/material";
import LightModeRoundedIcon from "@mui/icons-material/LightModeRounded";
import DarkModeRoundedIcon from "@mui/icons-material/DarkModeRounded";

type ThemeMode = "light" | "dark";

function getSystemMode(): ThemeMode {
  if (typeof window === "undefined") return "light";
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function readMode(): ThemeMode {
  if (typeof window === "undefined") return "light";
  const saved = localStorage.getItem("sabahub-theme");
  if (saved === "dark" || saved === "light") return saved;
  return getSystemMode();
}

function applyMode(mode: ThemeMode) {
  const root = document.documentElement;
  root.classList.remove("light", "dark");
  root.classList.add(mode);
  root.setAttribute("data-theme", mode);
  root.style.colorScheme = mode;
  localStorage.setItem("sabahub-theme", mode);
}

function useSyncedMode() {
  const [mode, setMode] = useState<ThemeMode>("light");

  useEffect(() => {
    const sync = () => setMode(readMode());
    sync();

    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onSystemChange = () => {
      const saved = localStorage.getItem("sabahub-theme");
      if (saved !== "light" && saved !== "dark") sync();
    };
    if (typeof media.addEventListener === "function") {
      media.addEventListener("change", onSystemChange);
    } else {
      media.addListener(onSystemChange);
    }

    const onStorage = (event: StorageEvent) => {
      if (event.key === "sabahub-theme") sync();
    };
    window.addEventListener("storage", onStorage);

    return () => {
      if (typeof media.removeEventListener === "function") {
        media.removeEventListener("change", onSystemChange);
      } else {
        media.removeListener(onSystemChange);
      }
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  return [mode, setMode] as const;
}

export function ThemeIconButton({ className = "" }: { className?: string }) {
  const [mode, setMode] = useSyncedMode();

  const toggle = () => {
    const next = mode === "light" ? "dark" : "light";
    applyMode(next);
    setMode(next);
  };

  return (
    <Tooltip title={mode === "light" ? "Switch to dark mode" : "Switch to light mode"}>
      <IconButton aria-label="toggle theme" onClick={toggle} className={className}>
        {mode === "light" ? <DarkModeRoundedIcon /> : <LightModeRoundedIcon />}
      </IconButton>
    </Tooltip>
  );
}

export function SegmentedThemeToggle({ className = "" }: { className?: string }) {
  const [mode, setMode] = useSyncedMode();

  return (
    <Box className={className}>
      <ToggleButtonGroup
        size="small"
        color="primary"
        exclusive
        value={mode}
        onChange={(_event, value: ThemeMode | null) => {
          if (!value) return;
          applyMode(value);
          setMode(value);
        }}
      >
        <ToggleButton value="light" aria-label="light mode">
          <LightModeRoundedIcon fontSize="small" sx={{ mr: 0.5 }} />
          Light
        </ToggleButton>
        <ToggleButton value="dark" aria-label="dark mode">
          <DarkModeRoundedIcon fontSize="small" sx={{ mr: 0.5 }} />
          Dark
        </ToggleButton>
      </ToggleButtonGroup>
    </Box>
  );
}

export default function ThemeToggle() {
  return <ThemeIconButton />;
}
