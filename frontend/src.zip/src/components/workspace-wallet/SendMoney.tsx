"use client";

import { useState, type FormEvent } from 'react';
import { Send, Wallet, CreditCard, Smartphone, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export function SendMoney() {
  const [method, setMethod] = useState<'sabahub' | 'stripe' | 'chapa'>('sabahub');
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSend = async (e: FormEvent) => {
    e.preventDefault();

    if (!recipient || !amount) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsProcessing(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));

    setIsProcessing(false);
    setShowSuccess(true);
    toast.success('Payment sent successfully!');

    // Reset form after 3 seconds
    setTimeout(() => {
      setShowSuccess(false);
      setRecipient('');
      setAmount('');
      setDescription('');
    }, 3000);
  };

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">Send Money</h1>
        <p className="text-muted-foreground">Transfer funds using your preferred payment method</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Send Form */}
        <div className="lg:col-span-2">
          <div className="bg-card border border-border rounded-2xl p-6">
            {showSuccess ? (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <CheckCircle className="w-12 h-12 text-green-600" />
                </div>
                <h3 className="mb-2">Payment Sent Successfully!</h3>
                <p className="text-muted-foreground mb-6">Your transaction has been processed</p>
                <div className="bg-muted rounded-xl p-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Amount:</span>
                    <span className="font-semibold">${amount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">To:</span>
                    <span className="font-semibold">{recipient}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Method:</span>
                    <span className="font-semibold capitalize">{method}</span>
                  </div>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSend} className="space-y-6">
                {/* Payment Method Selection */}
                <div>
                  <label className="block mb-3">Payment Method</label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <button
                      type="button"
                      onClick={() => setMethod('sabahub')}
                      className={`flex flex-col items-center gap-3 p-4 rounded-xl border-2 transition-all ${
                        method === 'sabahub'
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                        <Wallet className="w-6 h-6 text-blue-600" />
                      </div>
                      <div className="text-center">
                        <div className="font-medium">SABAHUB</div>
                        <div className="text-xs text-muted-foreground">Local wallet</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setMethod('stripe')}
                      className={`flex flex-col items-center gap-3 p-4 rounded-xl border-2 transition-all ${
                        method === 'stripe'
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                        <CreditCard className="w-6 h-6 text-purple-600" />
                      </div>
                      <div className="text-center">
                        <div className="font-medium">Stripe</div>
                        <div className="text-xs text-muted-foreground">Card payment</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setMethod('chapa')}
                      className={`flex flex-col items-center gap-3 p-4 rounded-xl border-2 transition-all ${
                        method === 'chapa'
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
                        <Smartphone className="w-6 h-6 text-green-600" />
                      </div>
                      <div className="text-center">
                        <div className="font-medium">Chapa</div>
                        <div className="text-xs text-muted-foreground">Local payment</div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Recipient */}
                <div>
                  <label className="block mb-2">
                    {method === 'sabahub' ? 'Recipient Wallet ID' : 'Recipient Email'}
                  </label>
                  <input
                    type="text"
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    placeholder={method === 'sabahub' ? 'wallet@sabahub.com' : 'recipient@email.com'}
                    className="w-full px-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                    required
                  />
                </div>

                {/* Amount */}
                <div>
                  <label className="block mb-2">Amount (USD)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00"
                      step="0.01"
                      min="0"
                      className="w-full pl-8 pr-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                  <div className="mt-2 text-sm text-muted-foreground">
                    Available balance: $8,900.00
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block mb-2">Description (Optional)</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="What's this payment for?"
                    rows={3}
                    className="w-full px-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      <span>Send Money</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Summary and Info */}
        <div className="space-y-6">
          {/* Transaction Summary */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="mb-4">Transaction Summary</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-semibold">${amount || '0.00'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fee</span>
                <span className="font-semibold">$0.00</span>
              </div>
              <div className="border-t border-border pt-3 flex justify-between">
                <span className="font-medium">Total</span>
                <span className="font-semibold">${amount || '0.00'}</span>
              </div>
            </div>
          </div>

          {/* Payment Info */}
          <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl p-6 text-white">
            <h3 className="mb-4">Payment Information</h3>
            <div className="space-y-3 text-sm">
              <p className="opacity-90">
                {method === 'sabahub' && 'SABAHUB transfers are instant and free between wallet users.'}
                {method === 'stripe' && 'Stripe payments are processed securely and arrive within 1-3 business days.'}
                {method === 'chapa' && 'Chapa payments are processed locally with competitive rates.'}
              </p>
              <div className="pt-3 border-t border-white/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="opacity-75">Processing Time</span>
                  <span className="font-medium">
                    {method === 'sabahub' ? 'Instant' : '1-3 days'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="opacity-75">Transaction Fee</span>
                  <span className="font-medium">
                    {method === 'sabahub' ? 'Free' : '2.9% + $0.30'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Security Notice */}
          <div className="bg-muted rounded-xl p-4 text-sm">
            <div className="font-medium mb-2">🔒 Secure Transaction</div>
            <p className="text-muted-foreground">
              All transactions are encrypted and secured. Never share your wallet credentials with anyone.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
