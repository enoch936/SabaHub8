"use client";

import { useState } from 'react';
import { ArrowUpRight, ArrowDownLeft, Search, Filter, Download, Calendar } from 'lucide-react';

const allTransactions = [
  { id: 'TXN001', type: 'received', from: 'John Doe', to: null, amount: 250, method: 'SABAHUB', status: 'completed', date: '2026-03-30', time: '10:30 AM', description: 'Payment for services' },
  { id: 'TXN002', type: 'sent', from: null, to: 'Alice Smith', amount: 150, method: 'Stripe', status: 'completed', date: '2026-03-29', time: '03:45 PM', description: 'Product purchase' },
  { id: 'TXN003', type: 'received', from: 'Bob Johnson', to: null, amount: 500, method: 'Chapa', status: 'completed', date: '2026-03-29', time: '11:20 AM', description: 'Invoice payment' },
  { id: 'TXN004', type: 'sent', from: null, to: 'Sarah Williams', amount: 75, method: 'SABAHUB', status: 'completed', date: '2026-03-28', time: '09:15 AM', description: 'Gift' },
  { id: 'TXN005', type: 'received', from: 'Mike Brown', to: null, amount: 1200, method: 'Stripe', status: 'completed', date: '2026-03-27', time: '02:30 PM', description: 'Consulting fee' },
  { id: 'TXN006', type: 'sent', from: null, to: 'Emma Davis', amount: 300, method: 'Chapa', status: 'pending', date: '2026-03-27', time: '01:10 PM', description: 'Subscription' },
  { id: 'TXN007', type: 'received', from: 'Chris Wilson', to: null, amount: 450, method: 'SABAHUB', status: 'completed', date: '2026-03-26', time: '04:20 PM', description: 'Project payment' },
  { id: 'TXN008', type: 'sent', from: null, to: 'Olivia Taylor', amount: 85, method: 'Stripe', status: 'completed', date: '2026-03-26', time: '10:45 AM', description: 'Software license' },
  { id: 'TXN009', type: 'received', from: 'David Martinez', to: null, amount: 650, method: 'Chapa', status: 'completed', date: '2026-03-25', time: '03:15 PM', description: 'Service payment' },
  { id: 'TXN010', type: 'sent', from: null, to: 'Sophia Anderson', amount: 120, method: 'SABAHUB', status: 'failed', date: '2026-03-25', time: '11:30 AM', description: 'Refund' },
];

export function Transactions() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterMethod, setFilterMethod] = useState('all');
  const [sortBy, setSortBy] = useState('date-desc');

  const filteredTransactions = allTransactions
    .filter((t) => {
      const matchesSearch =
        t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.from?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.to?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.description.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesType = filterType === 'all' || t.type === filterType;
      const matchesMethod = filterMethod === 'all' || t.method === filterMethod;

      return matchesSearch && matchesType && matchesMethod;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'date-desc':
          return new Date(b.date + ' ' + b.time).getTime() - new Date(a.date + ' ' + a.time).getTime();
        case 'date-asc':
          return new Date(a.date + ' ' + a.time).getTime() - new Date(b.date + ' ' + b.time).getTime();
        case 'amount-desc':
          return b.amount - a.amount;
        case 'amount-asc':
          return a.amount - b.amount;
        default:
          return 0;
      }
    });

  const totalReceived = allTransactions
    .filter((t) => t.type === 'received' && t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalSent = allTransactions
    .filter((t) => t.type === 'sent' && t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="mb-2">Transactions</h1>
          <p className="text-muted-foreground">View and manage all your transactions</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity">
          <Download className="w-4 h-4" />
          <span>Export</span>
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="text-sm text-muted-foreground mb-2">Total Received</div>
          <div className="text-2xl font-semibold text-green-600">${totalReceived.toLocaleString()}</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="text-sm text-muted-foreground mb-2">Total Sent</div>
          <div className="text-2xl font-semibold text-red-600">${totalSent.toLocaleString()}</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="text-sm text-muted-foreground mb-2">Net Balance</div>
          <div className="text-2xl font-semibold">${(totalReceived - totalSent).toLocaleString()}</div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-card border border-border rounded-2xl p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          {/* Type Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="all">All Types</option>
            <option value="received">Received</option>
            <option value="sent">Sent</option>
          </select>

          {/* Method Filter */}
          <select
            value={filterMethod}
            onChange={(e) => setFilterMethod(e.target.value)}
            className="px-4 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="all">All Methods</option>
            <option value="SABAHUB">SABAHUB</option>
            <option value="Stripe">Stripe</option>
            <option value="Chapa">Chapa</option>
          </select>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-4 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="date-desc">Date (Newest)</option>
            <option value="date-asc">Date (Oldest)</option>
            <option value="amount-desc">Amount (High to Low)</option>
            <option value="amount-asc">Amount (Low to High)</option>
          </select>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted border-b border-border">
              <tr>
                <th className="text-left p-4 font-medium">Transaction ID</th>
                <th className="text-left p-4 font-medium">Type</th>
                <th className="text-left p-4 font-medium">From/To</th>
                <th className="text-left p-4 font-medium">Method</th>
                <th className="text-left p-4 font-medium">Amount</th>
                <th className="text-left p-4 font-medium">Status</th>
                <th className="text-left p-4 font-medium">Date & Time</th>
                <th className="text-left p-4 font-medium">Description</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((transaction) => (
                <tr key={transaction.id} className="border-b border-border hover:bg-accent transition-colors">
                  <td className="p-4">
                    <span className="font-mono text-sm">{transaction.id}</span>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      {transaction.type === 'received' ? (
                        <>
                          <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
                            <ArrowDownLeft className="w-4 h-4 text-green-600" />
                          </div>
                          <span className="text-sm">Received</span>
                        </>
                      ) : (
                        <>
                          <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center">
                            <ArrowUpRight className="w-4 h-4 text-red-600" />
                          </div>
                          <span className="text-sm">Sent</span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="text-sm">{transaction.from || transaction.to}</span>
                  </td>
                  <td className="p-4">
                    <span className="inline-flex items-center px-2 py-1 rounded-md bg-muted text-sm">
                      {transaction.method}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`font-semibold ${
                      transaction.type === 'received' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {transaction.type === 'received' ? '+' : '-'}${transaction.amount}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs ${
                      transaction.status === 'completed'
                        ? 'bg-green-100 text-green-700'
                        : transaction.status === 'pending'
                        ? 'bg-yellow-100 text-yellow-700'
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {transaction.status}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="text-sm">
                      <div>{transaction.date}</div>
                      <div className="text-muted-foreground">{transaction.time}</div>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="text-sm text-muted-foreground">{transaction.description}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredTransactions.length === 0 && (
          <div className="p-12 text-center text-muted-foreground">
            No transactions found matching your filters
          </div>
        )}
      </div>
    </div>
  );
}
