"use client";

import { ArrowUpRight, ArrowDownLeft, DollarSign, TrendingUp, Wallet, CreditCard, Smartphone } from 'lucide-react';
import { AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const balanceData = [
  { month: 'Jan', balance: 4500 },
  { month: 'Feb', balance: 5200 },
  { month: 'Mar', balance: 4800 },
  { month: 'Apr', balance: 6100 },
  { month: 'May', balance: 7300 },
  { month: 'Jun', balance: 8900 },
];

const transactionData = [
  { month: 'Jan', received: 3200, sent: 2100 },
  { month: 'Feb', received: 4100, sent: 2800 },
  { month: 'Mar', received: 3800, sent: 3200 },
  { month: 'Apr', received: 5200, sent: 2900 },
  { month: 'May', received: 6100, sent: 3400 },
  { month: 'Jun', received: 7200, sent: 3800 },
];

const paymentMethodData = [
  { name: 'SABAHUB', value: 45, color: '#3b82f6' },
  { name: 'Stripe', value: 30, color: '#8b5cf6' },
  { name: 'Chapa', value: 25, color: '#10b981' },
];

const recentTransactions = [
  { id: '1', type: 'received', from: 'John Doe', amount: 250, method: 'SABAHUB', date: '2026-03-30', time: '10:30 AM' },
  { id: '2', type: 'sent', to: 'Alice Smith', amount: 150, method: 'Stripe', date: '2026-03-29', time: '03:45 PM' },
  { id: '3', type: 'received', from: 'Bob Johnson', amount: 500, method: 'Chapa', date: '2026-03-29', time: '11:20 AM' },
  { id: '4', type: 'sent', to: 'Sarah Williams', amount: 75, method: 'SABAHUB', date: '2026-03-28', time: '09:15 AM' },
];

export function Dashboard() {
  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's your wallet overview.</p>
      </div>

      {/* Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
              <Wallet className="w-6 h-6" />
            </div>
            <span className="text-sm opacity-90">Total Balance</span>
          </div>
          <div>
            <div className="text-3xl font-semibold mb-1">$8,900.00</div>
            <div className="flex items-center gap-1 text-sm opacity-90">
              <TrendingUp className="w-4 h-4" />
              <span>+12.5% from last month</span>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
              <ArrowDownLeft className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-sm text-muted-foreground">Received</span>
          </div>
          <div>
            <div className="text-3xl font-semibold mb-1">$7,200</div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <span>This month</span>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center">
              <ArrowUpRight className="w-6 h-6 text-red-600" />
            </div>
            <span className="text-sm text-muted-foreground">Sent</span>
          </div>
          <div>
            <div className="text-3xl font-semibold mb-1">$3,800</div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <span>This month</span>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-sm text-muted-foreground">Withdrawn</span>
          </div>
          <div>
            <div className="text-3xl font-semibold mb-1">$1,450</div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <span>This month</span>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Balance Trend */}
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="mb-6">
            <h3 className="mb-1">Balance Trend</h3>
            <p className="text-sm text-muted-foreground">Your wallet balance over time</p>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={balanceData}>
              <defs>
                <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#fff',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px'
                }}
              />
              <Area type="monotone" dataKey="balance" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorBalance)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Transaction Volume */}
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="mb-6">
            <h3 className="mb-1">Transaction Volume</h3>
            <p className="text-sm text-muted-foreground">Money received vs sent</p>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={transactionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#fff',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="received" fill="#10b981" radius={[8, 8, 0, 0]} />
              <Bar dataKey="sent" fill="#f59e0b" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Payment Methods and Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Payment Methods Distribution */}
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="mb-6">
            <h3 className="mb-1">Payment Methods</h3>
            <p className="text-sm text-muted-foreground">Usage distribution</p>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={paymentMethodData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {paymentMethodData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {paymentMethodData.map((method) => (
              <div key={method.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: method.color }} />
                  <span className="text-sm">{method.name}</span>
                </div>
                <span className="text-sm font-medium">{method.value}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="bg-card border border-border rounded-2xl p-6 lg:col-span-2">
          <div className="mb-6">
            <h3 className="mb-1">Recent Transactions</h3>
            <p className="text-sm text-muted-foreground">Your latest activity</p>
          </div>
          <div className="space-y-3">
            {recentTransactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-4 rounded-xl border border-border hover:bg-accent transition-colors">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    transaction.type === 'received' ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    {transaction.type === 'received' ? (
                      <ArrowDownLeft className="w-5 h-5 text-green-600" />
                    ) : (
                      <ArrowUpRight className="w-5 h-5 text-red-600" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium">
                      {transaction.type === 'received' ? `From ${transaction.from}` : `To ${transaction.to}`}
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <span>{transaction.method}</span>
                      <span>•</span>
                      <span>{transaction.date} {transaction.time}</span>
                    </div>
                  </div>
                </div>
                <div className={`font-semibold ${
                  transaction.type === 'received' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {transaction.type === 'received' ? '+' : '-'}${transaction.amount}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-card border border-border rounded-2xl p-6">
        <h3 className="mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center gap-4 p-4 rounded-xl border-2 border-dashed border-border hover:border-primary hover:bg-accent transition-all">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
              <Wallet className="w-6 h-6 text-blue-600" />
            </div>
            <div className="text-left">
              <div className="font-medium">SABAHUB Transfer</div>
              <div className="text-sm text-muted-foreground">Send to wallet</div>
            </div>
          </button>

          <button className="flex items-center gap-4 p-4 rounded-xl border-2 border-dashed border-border hover:border-primary hover:bg-accent transition-all">
            <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-purple-600" />
            </div>
            <div className="text-left">
              <div className="font-medium">Stripe Payment</div>
              <div className="text-sm text-muted-foreground">Pay with card</div>
            </div>
          </button>

          <button className="flex items-center gap-4 p-4 rounded-xl border-2 border-dashed border-border hover:border-primary hover:bg-accent transition-all">
            <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
              <Smartphone className="w-6 h-6 text-green-600" />
            </div>
            <div className="text-left">
              <div className="font-medium">Chapa Payment</div>
              <div className="text-sm text-muted-foreground">Local payment</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
