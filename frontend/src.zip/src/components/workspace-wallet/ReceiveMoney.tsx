"use client";

import { useState } from 'react';
import { Copy, QrCode, Mail, Share2, Check, Download } from 'lucide-react';
import { toast } from 'sonner';
import { QRCodeSVG } from 'qrcode.react';

export function ReceiveMoney() {
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [copied, setCopied] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);

  const walletId = 'sabahub@wallet-id-12345';
  const paymentLink = `https://sabahub.wallet/pay/${walletId}`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const generatePaymentLink = () => {
    if (!amount) {
      toast.error('Please enter an amount');
      return;
    }

    const link = `${paymentLink}?amount=${amount}${description ? `&desc=${encodeURIComponent(description)}` : ''}`;
    handleCopy(link);
    toast.success('Payment link copied!');
  };

  const downloadQRCode = () => {
    const svg = document.getElementById('qr-code-svg');
    if (!svg) return;

    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx?.drawImage(img, 0, 0);
      const pngFile = canvas.toDataURL('image/png');

      const downloadLink = document.createElement('a');
      downloadLink.download = 'sabahub-qr-code.png';
      downloadLink.href = pngFile;
      downloadLink.click();
      toast.success('QR Code downloaded!');
    };

    img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
  };

  const qrValue = amount
    ? `${paymentLink}?amount=${amount}${description ? `&desc=${encodeURIComponent(description)}` : ''}`
    : paymentLink;

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">Receive Money</h1>
        <p className="text-muted-foreground">Share your wallet details to receive payments</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Wallet ID Card */}
          <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              <div className="flex-1">
                <div className="text-sm opacity-75 mb-2">Your Wallet ID</div>
                <div className="text-2xl font-mono font-semibold mb-4 break-all">
                  {walletId}
                </div>
                <button
                  onClick={() => handleCopy(walletId)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/20 hover:bg-white/30 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Wallet ID</span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex-shrink-0">
                <div
                  className="w-32 h-32 bg-white rounded-xl p-2 flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
                  onClick={() => setShowQRModal(true)}
                >
                  <QRCodeSVG
                    value={qrValue}
                    size={112}
                    level="H"
                    includeMargin={false}
                  />
                </div>
                <button
                  onClick={() => setShowQRModal(true)}
                  className="w-full text-center mt-2 text-sm opacity-75 hover:opacity-100 transition-opacity"
                >
                  Tap to enlarge
                </button>
              </div>
            </div>
          </div>

          {/* Payment Request Form */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="mb-4">Create Payment Request</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Generate a custom payment link with a specific amount
            </p>

            <div className="space-y-4">
              <div>
                <label className="block mb-2">Amount (USD)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    step="0.01"
                    min="0"
                    className="w-full pl-8 pr-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>

              <div>
                <label className="block mb-2">Description (Optional)</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="What's this payment for?"
                  className="w-full px-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <button
                onClick={generatePaymentLink}
                className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
              >
                <Share2 className="w-5 h-5" />
                <span>Generate Payment Link</span>
              </button>
            </div>
          </div>

          {/* Recent Received Transactions */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="mb-4">Recent Received Payments</h3>
            <div className="space-y-3">
              {[
                { from: 'John Doe', amount: 250, method: 'SABAHUB', date: 'Today, 10:30 AM' },
                { from: 'Bob Johnson', amount: 500, method: 'Chapa', date: 'Yesterday, 11:20 AM' },
                { from: 'Mike Brown', amount: 1200, method: 'Stripe', date: 'Mar 27, 02:30 PM' },
                { from: 'Chris Wilson', amount: 450, method: 'SABAHUB', date: 'Mar 26, 04:20 PM' },
              ].map((transaction, index) => (
                <div key={index} className="flex items-center justify-between p-4 rounded-xl border border-border hover:bg-accent transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                      <span className="text-green-600 font-semibold">{transaction.from[0]}</span>
                    </div>
                    <div>
                      <div className="font-medium">{transaction.from}</div>
                      <div className="text-sm text-muted-foreground">{transaction.method} • {transaction.date}</div>
                    </div>
                  </div>
                  <div className="text-green-600 font-semibold">+${transaction.amount}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Quick Stats */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="mb-4">This Month</h3>
            <div className="space-y-4">
              <div>
                <div className="text-sm text-muted-foreground mb-1">Total Received</div>
                <div className="text-2xl font-semibold text-green-600">$7,200</div>
              </div>
              <div className="pt-4 border-t border-border">
                <div className="text-sm text-muted-foreground mb-1">Transactions</div>
                <div className="text-2xl font-semibold">24</div>
              </div>
            </div>
          </div>

          {/* Share Options */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="mb-4">Share Your Wallet</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-accent transition-colors">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-blue-600" />
                </div>
                <span>Share via Email</span>
              </button>

              <button className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-accent transition-colors">
                <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                  <Share2 className="w-5 h-5 text-green-600" />
                </div>
                <span>Share Link</span>
              </button>

              <button
                onClick={() => setShowQRModal(true)}
                className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-accent transition-colors"
              >
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <QrCode className="w-5 h-5 text-purple-600" />
                </div>
                <span>View QR Code</span>
              </button>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="bg-muted rounded-xl p-4 text-sm">
            <div className="font-medium mb-3">Accepted Payment Methods</div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-blue-600" />
                <span>SABAHUB Wallet</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-purple-600" />
                <span>Stripe (Cards)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-600" />
                <span>Chapa (Local)</span>
              </div>
            </div>
          </div>

          {/* Tips */}
          <div className="bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl p-6 text-white">
            <h3 className="mb-3">💡 Pro Tip</h3>
            <p className="text-sm opacity-90">
              Share your QR code for instant payments at events or in person. No need to type wallet IDs!
            </p>
          </div>
        </div>
      </div>

      {/* QR Code Modal */}
      {showQRModal && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setShowQRModal(false)}
        >
          <div
            className="bg-card border border-border rounded-3xl p-8 max-w-md w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-center mb-6">
              <h2 className="mb-2">Scan to Pay</h2>
              <p className="text-sm text-muted-foreground">
                {amount
                  ? `Request for $${amount}`
                  : 'Scan this QR code to send payment'}
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl mb-6 flex items-center justify-center">
              <QRCodeSVG
                id="qr-code-svg"
                value={qrValue}
                size={280}
                level="H"
                includeMargin={true}
              />
            </div>

            <div className="space-y-3">
              <button
                onClick={downloadQRCode}
                className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
              >
                <Download className="w-5 h-5" />
                <span>Download QR Code</span>
              </button>

              <button
                onClick={() => handleCopy(qrValue)}
                className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg border border-border hover:bg-muted transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-5 h-5" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-5 h-5" />
                    <span>Copy Payment Link</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setShowQRModal(false)}
                className="w-full px-6 py-3 rounded-lg text-muted-foreground hover:text-foreground transition-colors"
              >
                Close
              </button>
            </div>

            {amount && description && (
              <div className="mt-6 p-4 bg-muted rounded-xl text-sm">
                <div className="text-muted-foreground mb-1">Payment Details:</div>
                <div className="font-medium">{description}</div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
