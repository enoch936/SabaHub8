"use client";

import { useState, type FormEvent } from 'react';
import { Building2, CreditCard, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export function Withdraw() {
  const [method, setMethod] = useState<'bank' | 'card'>('bank');
  const [amount, setAmount] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [bankName, setBankName] = useState('');
  const [accountName, setAccountName] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleWithdraw = async (e: FormEvent) => {
    e.preventDefault();

    if (!amount || !accountNumber) {
      toast.error('Please fill in all required fields');
      return;
    }

    const withdrawAmount = parseFloat(amount);
    const availableBalance = 8900;

    if (withdrawAmount > availableBalance) {
      toast.error('Insufficient balance');
      return;
    }

    setIsProcessing(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));

    setIsProcessing(false);
    setShowSuccess(true);
    toast.success('Withdrawal request submitted!');

    // Reset form after 3 seconds
    setTimeout(() => {
      setShowSuccess(false);
      setAmount('');
      setAccountNumber('');
      setBankName('');
      setAccountName('');
    }, 3000);
  };

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">Withdraw Funds</h1>
        <p className="text-muted-foreground">Transfer money from your wallet to your bank account or card</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Withdraw Form */}
        <div className="lg:col-span-2">
          <div className="bg-card border border-border rounded-2xl p-6">
            {showSuccess ? (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <CheckCircle className="w-12 h-12 text-green-600" />
                </div>
                <h3 className="mb-2">Withdrawal Request Submitted!</h3>
                <p className="text-muted-foreground mb-6 text-center">
                  Your funds will be processed within 1-3 business days
                </p>
                <div className="bg-muted rounded-xl p-4 space-y-2 w-full max-w-md">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Amount:</span>
                    <span className="font-semibold">${amount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Method:</span>
                    <span className="font-semibold capitalize">{method} Transfer</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Account:</span>
                    <span className="font-semibold">****{accountNumber.slice(-4)}</span>
                  </div>
                </div>
              </div>
            ) : (
              <form onSubmit={handleWithdraw} className="space-y-6">
                {/* Withdrawal Method Selection */}
                <div>
                  <label className="block mb-3">Withdrawal Method</label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setMethod('bank')}
                      className={`flex items-center gap-4 p-4 rounded-xl border-2 transition-all ${
                        method === 'bank'
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                        <Building2 className="w-6 h-6 text-blue-600" />
                      </div>
                      <div className="text-left">
                        <div className="font-medium">Bank Transfer</div>
                        <div className="text-xs text-muted-foreground">1-3 business days</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setMethod('card')}
                      className={`flex items-center gap-4 p-4 rounded-xl border-2 transition-all ${
                        method === 'card'
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                        <CreditCard className="w-6 h-6 text-purple-600" />
                      </div>
                      <div className="text-left">
                        <div className="font-medium">Card Transfer</div>
                        <div className="text-xs text-muted-foreground">Instant transfer</div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Amount */}
                <div>
                  <label className="block mb-2">Withdrawal Amount (USD)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00"
                      step="0.01"
                      min="0"
                      max="8900"
                      className="w-full pl-8 pr-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                  <div className="mt-2 flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Available balance: $8,900.00</span>
                    <button
                      type="button"
                      onClick={() => setAmount('8900')}
                      className="text-primary hover:underline"
                    >
                      Withdraw all
                    </button>
                  </div>
                </div>

                {/* Bank/Card Details */}
                {method === 'bank' ? (
                  <>
                    <div>
                      <label className="block mb-2">Bank Name</label>
                      <input
                        type="text"
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        placeholder="Select or enter bank name"
                        className="w-full px-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                        required
                      />
                    </div>

                    <div>
                      <label className="block mb-2">Account Number</label>
                      <input
                        type="text"
                        value={accountNumber}
                        onChange={(e) => setAccountNumber(e.target.value)}
                        placeholder="Enter account number"
                        className="w-full px-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                        required
                      />
                    </div>

                    <div>
                      <label className="block mb-2">Account Holder Name</label>
                      <input
                        type="text"
                        value={accountName}
                        onChange={(e) => setAccountName(e.target.value)}
                        placeholder="Enter account holder name"
                        className="w-full px-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                        required
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <label className="block mb-2">Card Number</label>
                      <input
                        type="text"
                        value={accountNumber}
                        onChange={(e) => setAccountNumber(e.target.value)}
                        placeholder="1234 5678 9012 3456"
                        maxLength={19}
                        className="w-full px-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block mb-2">Expiry Date</label>
                        <input
                          type="text"
                          placeholder="MM/YY"
                          className="w-full px-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                          required
                        />
                      </div>
                      <div>
                        <label className="block mb-2">CVV</label>
                        <input
                          type="text"
                          placeholder="123"
                          maxLength={3}
                          className="w-full px-4 py-3 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                          required
                        />
                      </div>
                    </div>
                  </>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <span>Withdraw Funds</span>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Withdrawal Summary */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="mb-4">Withdrawal Summary</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-semibold">${amount || '0.00'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Processing Fee</span>
                <span className="font-semibold">
                  {method === 'bank' ? '$0.00' : '$2.50'}
                </span>
              </div>
              <div className="border-t border-border pt-3 flex justify-between">
                <span className="font-medium">You'll Receive</span>
                <span className="font-semibold text-green-600">
                  ${amount ? (parseFloat(amount) - (method === 'card' ? 2.50 : 0)).toFixed(2) : '0.00'}
                </span>
              </div>
            </div>
          </div>

          {/* Processing Info */}
          <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl p-6 text-white">
            <h3 className="mb-4">Processing Information</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-white mt-2" />
                <p className="opacity-90 flex-1">
                  {method === 'bank'
                    ? 'Bank transfers typically arrive within 1-3 business days'
                    : 'Card transfers are processed instantly but may take up to 30 minutes to appear'
                  }
                </p>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-white mt-2" />
                <p className="opacity-90 flex-1">
                  Withdrawals are processed 24/7
                </p>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-white mt-2" />
                <p className="opacity-90 flex-1">
                  You'll receive a confirmation email once processed
                </p>
              </div>
            </div>
          </div>

          {/* Recent Withdrawals */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="mb-4">Recent Withdrawals</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <div>
                  <div className="font-medium">Bank Transfer</div>
                  <div className="text-muted-foreground">Mar 20, 2026</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">$1,200</div>
                  <div className="text-green-600 text-xs">Completed</div>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div>
                  <div className="font-medium">Card Transfer</div>
                  <div className="text-muted-foreground">Mar 15, 2026</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">$250</div>
                  <div className="text-green-600 text-xs">Completed</div>
                </div>
              </div>
            </div>
          </div>

          {/* Security Notice */}
          <div className="bg-muted rounded-xl p-4 text-sm">
            <div className="font-medium mb-2">🔒 Security Notice</div>
            <p className="text-muted-foreground">
              For your security, withdrawals to new accounts may be subject to a 24-hour hold period.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
