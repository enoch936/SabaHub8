import type { AppUser, Job, MarketplaceFreelancer } from "@/lib/api";
import type { PremiumFreelancer, PremiumJob } from "../types";

function humanize(value?: string | null) {
  if (!value) return "";
  return value
    .toLowerCase()
    .split(/[_\s-]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function pluralize(count: number, singular: string, plural = `${singular}s`) {
  return `${count} ${count === 1 ? singular : plural}`;
}

function formatRelativeTime(value?: string | null) {
  if (!value) return "Recently active";
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp)) return "Recently active";

  const diffSeconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  if (diffSeconds < 3600) {
    const minutes = Math.max(1, Math.floor(diffSeconds / 60));
    return `Active ${pluralize(minutes, "min")} ago`;
  }
  if (diffSeconds < 86400) {
    const hours = Math.floor(diffSeconds / 3600);
    return `Active ${pluralize(hours, "hour")} ago`;
  }
  const days = Math.floor(diffSeconds / 86400);
  return `Active ${pluralize(days, "day")} ago`;
}

function hashLabel(value: string) {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) {
    hash = (hash << 5) - hash + value.charCodeAt(index);
    hash |= 0;
  }
  return Math.abs(hash);
}

function createSvgPlaceholder(title: string, subtitle: string, square = false) {
  const palettes = [
    ["#0f766e", "#2563eb"],
    ["#0f172a", "#9333ea"],
    ["#1d4ed8", "#0f766e"],
    ["#be123c", "#7c3aed"],
    ["#0891b2", "#1d4ed8"],
  ];
  const palette = palettes[hashLabel(title || subtitle || "sabahub") % palettes.length];
  const initials = (title || subtitle || "S")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join("");

  const width = square ? 320 : 1200;
  const height = square ? 320 : 720;
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
      <defs>
        <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${palette[0]}" />
          <stop offset="100%" stop-color="${palette[1]}" />
        </linearGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#g)" rx="${square ? 48 : 32}" />
      <circle cx="${square ? 160 : 120}" cy="${square ? 160 : 140}" r="${square ? 72 : 84}" fill="rgba(255,255,255,0.14)" />
      <text x="${square ? 160 : 120}" y="${square ? 184 : 164}" fill="#ffffff" text-anchor="middle" font-family="Arial, sans-serif" font-size="${square ? 72 : 76}" font-weight="700">${initials || "S"}</text>
      ${
        square
          ? ""
          : `<text x="72" y="620" fill="#ffffff" font-family="Arial, sans-serif" font-size="52" font-weight="700">${escapeXml(
              title || "SabaHub Opportunity",
            )}</text>
             <text x="72" y="676" fill="rgba(255,255,255,0.85)" font-family="Arial, sans-serif" font-size="30">${escapeXml(
               subtitle || "Live marketplace data",
             )}</text>`
      }
    </svg>
  `;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function escapeXml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&apos;");
}

function resolveBudget(job: Job) {
  if (typeof job.budgetMax === "number" && Number.isFinite(job.budgetMax)) return job.budgetMax;
  if (typeof job.budgetMin === "number" && Number.isFinite(job.budgetMin)) return job.budgetMin;
  const hourly = job.rateBreakdown?.hourly ?? job.rateBreakdown?.hourlyRate;
  if (typeof hourly === "number" && Number.isFinite(hourly)) return hourly;
  return 0;
}

function resolveBudgetType(job: Job): "fixed" | "hourly" {
  return job.pricingModel === "HOURLY" ? "hourly" : "fixed";
}

function resolveDuration(job: Job) {
  if (typeof job.slaDeliveryDays === "number" && job.slaDeliveryDays > 0) {
    return pluralize(job.slaDeliveryDays, "day");
  }
  if (typeof job.contractTermMonths === "number" && job.contractTermMonths > 0) {
    return pluralize(job.contractTermMonths, "month");
  }
  if (typeof job.minimumMonthlyCommitment === "number" && job.minimumMonthlyCommitment > 0) {
    return `${job.minimumMonthlyCommitment} hrs/month`;
  }
  return humanize(job.engagementType) || "Flexible";
}

function resolveExperienceLevel(job: Job): "entry" | "intermediate" | "expert" {
  if (typeof job.minYearsExperience === "number") {
    if (job.minYearsExperience >= 5) return "expert";
    if (job.minYearsExperience >= 2) return "intermediate";
    return "entry";
  }

  const hints = [...(job.preferredExperience ?? []), ...(job.requiredQualifications ?? [])]
    .join(" ")
    .toLowerCase();
  if (hints.includes("senior") || hints.includes("expert") || hints.includes("lead")) return "expert";
  if (hints.includes("mid") || hints.includes("intermediate")) return "intermediate";
  return "entry";
}

function resolveCategory(job: Job) {
  return humanize(job.categoryId) || humanize(job.deliverableType) || humanize(job.engagementType) || "General";
}

function resolvePostedBy(job: Job, usersById?: Map<string, AppUser>) {
  if (job.companyName && job.companyName.trim()) return job.companyName.trim();
  if (job.employerId && usersById?.has(job.employerId)) {
    const user = usersById.get(job.employerId);
    if (user?.fullName?.trim()) return user.fullName.trim();
    if (user?.username?.trim()) return `@${user.username.trim()}`;
  }
  return "Marketplace Client";
}

export function toPremiumJob(job: Job, usersById?: Map<string, AppUser>): PremiumJob {
  const category = resolveCategory(job);
  const title = job.title?.trim() || "Untitled opportunity";
  const subtitle = resolvePostedBy(job, usersById);
  const image = job.sampleImageUrls?.[0] || createSvgPlaceholder(title, subtitle);

  return {
    id: job.id,
    employerId: job.employerId,
    title,
    description: job.description?.trim() || job.overviewText?.trim() || "No project description provided yet.",
    category,
    budget: resolveBudget(job),
    budgetType: resolveBudgetType(job),
    currency: job.currency || "USD",
    duration: resolveDuration(job),
    skillsRequired: (job.requiredSkills?.length ? job.requiredSkills : job.skills ?? []).filter(Boolean),
    image,
    postedBy: subtitle,
    postedDate: job.createdAt || job.updatedAt || new Date().toISOString(),
    rating: 0,
    reviewCount: 0,
    reviews: [],
    experienceLevel: resolveExperienceLevel(job),
    location: job.workLocation?.trim() || "Remote",
    employerRating: 0,
    applicants: undefined,
    trending: false,
  };
}

function resolveAvailability(raw?: string | null): "available" | "busy" | "offline" {
  const normalized = (raw || "").trim().toUpperCase();
  if (normalized === "NOT_AVAILABLE" || normalized === "OFFLINE") return "offline";
  if (normalized === "PART_TIME" || normalized === "CONTRACT" || normalized === "BUSY") return "busy";
  return "available";
}

export function toPremiumFreelancer(freelancer: MarketplaceFreelancer): PremiumFreelancer {
  const title = freelancer.title?.trim() || "Freelancer";
  const name = freelancer.name?.trim() || "Verified Freelancer";
  return {
    id: freelancer.id,
    userId: freelancer.userId || undefined,
    name,
    title,
    bio: freelancer.bio?.trim() || "Profile details will appear here as this freelancer builds out their marketplace presence.",
    profileImage:
      freelancer.profileImageUrl?.trim() || createSvgPlaceholder(name, title, true),
    skills: Array.isArray(freelancer.skills) ? freelancer.skills.filter(Boolean) : [],
    hourlyRate: typeof freelancer.hourlyRate === "number" ? freelancer.hourlyRate : 0,
    rating: typeof freelancer.rating === "number" ? freelancer.rating : 0,
    reviewCount: typeof freelancer.reviewCount === "number" ? freelancer.reviewCount : 0,
    completedJobs: typeof freelancer.completedProjects === "number" ? freelancer.completedProjects : 0,
    availability: resolveAvailability(freelancer.availability),
    location: freelancer.location?.trim() || "Remote",
    languages: Array.isArray(freelancer.languages) ? freelancer.languages.filter(Boolean) : [],
    certifications: Array.isArray(freelancer.certifications) ? freelancer.certifications.filter(Boolean) : [],
    lastActiveLabel: formatRelativeTime(freelancer.lastActive),
    verified: Boolean(freelancer.verified),
  };
}

export function buildSearchSuggestions(jobs: PremiumJob[], freelancers: PremiumFreelancer[]) {
  const suggestions = new Set<string>();

  for (const job of jobs.slice(0, 4)) {
    if (job.title) suggestions.add(job.title);
  }

  for (const skill of freelancers.flatMap((freelancer) => freelancer.skills).slice(0, 4)) {
    if (skill) suggestions.add(skill);
  }

  for (const category of jobs.map((job) => job.category).slice(0, 3)) {
    if (category) suggestions.add(category);
  }

  return [...suggestions].slice(0, 8);
}

export function buildCategoryOptions(jobs: PremiumJob[], freelancers: PremiumFreelancer[]) {
  const frequency = new Map<string, number>();

  for (const category of jobs.map((job) => job.category)) {
    if (!category) continue;
    frequency.set(category, (frequency.get(category) ?? 0) + 2);
  }

  for (const skill of freelancers.flatMap((freelancer) => freelancer.skills)) {
    if (!skill) continue;
    frequency.set(skill, (frequency.get(skill) ?? 0) + 1);
  }

  return [...frequency.entries()]
    .sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0]))
    .map(([value]) => value)
    .slice(0, 12);
}
