import type { PremiumJob } from '../types';
import { Star, MapPin, Clock, DollarSign, Bookmark, TrendingUp, Users, Sparkles, Share2, MessageCircle, CheckCircle2 } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter, CardHeader } from './ui/card';
import { Progress } from './ui/progress';
import { getTimeAgo } from '../utils/helpers';
import { motion } from 'framer-motion';
import { cn } from './ui/utils';

interface SmartJobCardProps {
  job: PremiumJob;
  isBookmarked: boolean;
  onBookmarkToggle: (jobId: string) => void;
  onViewDetails: (job: PremiumJob) => void;
  aiMatchScore?: number;
}

export function SmartJobCard({ job, isBookmarked, onBookmarkToggle, onViewDetails, aiMatchScore = 85 }: SmartJobCardProps) {
  return (
    <motion.div
      transition={{ duration: 0.3 }}
    >
      <Card className={cn(
        "overflow-hidden group cursor-pointer relative"
      )}>
        {/* AI Match Score Badge */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute top-16 left-3 z-10"
        >
          <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg">
            <Sparkles className="size-3 mr-1" />
            {aiMatchScore}% Match
          </Badge>
        </motion.div>

        <div className="relative h-48 overflow-hidden">
          <img 
            src={job.image} 
            alt={job.title}
            className="w-full h-full object-cover"
          />
          
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          
          <div className="absolute top-3 right-3 flex gap-2">
            {job.trending && (
              <motion.div
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
              >
                <Badge className="bg-red-500 text-white shadow-sm">
                  <TrendingUp className="size-3 mr-1" />
                  Trending
                </Badge>
              </motion.div>
            )}
            <motion.div whileTap={{ scale: 0.9 }}>
              <Button
                variant={isBookmarked ? "default" : "secondary"}
                size="icon"
                className={cn(
                  "rounded-full shadow-lg transition-all",
                  isBookmarked && "bg-gradient-to-r from-blue-500 to-purple-600"
                )}
                onClick={(e) => {
                  e.stopPropagation();
                  onBookmarkToggle(job.id);
                }}
              >
                <motion.div
                  animate={{ scale: isBookmarked ? [1, 1.3, 1] : 1 }}
                  transition={{ duration: 0.3 }}
                >
                  <Bookmark className={`size-4 ${isBookmarked ? 'fill-current' : ''}`} />
                </motion.div>
              </Button>
            </motion.div>
          </div>
          
          <div className="absolute bottom-3 left-3 flex gap-2">
            <Badge variant="secondary" className="bg-white text-slate-900 border border-slate-200 shadow-sm">
              {job.category}
            </Badge>
            <Badge variant="secondary" className="bg-white text-slate-900 border border-slate-200 shadow-sm capitalize">
              {job.experienceLevel}
            </Badge>
            {job.postedBy && (
              <Badge variant="secondary" className="bg-green-500 text-white shadow-sm">
                <CheckCircle2 className="size-3 mr-1" />
                Client
              </Badge>
            )}
          </div>
        </div>
        
        <CardHeader onClick={() => onViewDetails(job)} className="relative">
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-lg line-clamp-2">
              {job.title}
            </h3>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2 mt-2">
            {job.description}
          </p>
        </CardHeader>

        <CardContent onClick={() => onViewDetails(job)} className="space-y-3">
          {/* Employer Info */}
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <motion.div 
                className="size-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs"
              >
                {job.postedBy[0]}
              </motion.div>
              <div>
                <p className="text-sm truncate">{job.postedBy}</p>
                {job.employerRating > 0 ? (
                  <div className="flex items-center gap-1">
                    <Star className="size-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-xs text-muted-foreground">
                      {job.employerRating.toFixed(1)}
                    </span>
                  </div>
                ) : (
                  <span className="text-xs text-muted-foreground">New client</span>
                )}
              </div>
            </div>
            <div className="text-xs text-muted-foreground text-right">
              <Clock className="size-3 inline mr-1" />
              {getTimeAgo(job.postedDate)}
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {job.skillsRequired.slice(0, 3).map((skill) => (
              <Badge 
                key={skill} 
                variant="outline" 
                className="text-xs"
              >
                {skill}
              </Badge>
            ))}
            {job.skillsRequired.length === 0 && (
              <Badge variant="outline" className="text-xs">
                Skills on request
              </Badge>
            )}
            {job.skillsRequired.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{job.skillsRequired.length - 3}
              </Badge>
            )}
          </div>

          {/* Progress Indicator */}
          {job.applicants && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground flex items-center gap-1">
                  <Users className="size-3" />
                  {job.applicants} applicants
                </span>
                <span className="text-muted-foreground">Target: 50</span>
              </div>
              <Progress value={(job.applicants / 50) * 100} className="h-1.5" />
            </div>
          )}

          {/* Stats */}
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <MapPin className="size-3" />
              <span>{job.location}</span>
            </div>
            <div className="flex items-center gap-1">
              <CheckCircle2 className="size-3" />
              <span>{job.budget > 0 ? "Budget published" : "Budget on request"}</span>
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex items-center justify-between border-t pt-4">
          <div className="flex items-center gap-2">
            <DollarSign className="size-4 text-green-600" />
            <div>
              <p className="text-lg">
                {job.budget > 0 ? `$${job.budget.toLocaleString()}` : 'Budget TBD'}
                <span className="text-xs text-muted-foreground">
                  {job.budgetType === 'hourly' ? '/hr' : ''}
                </span>
              </p>
              <p className="text-xs text-muted-foreground">{job.duration}</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="hidden gap-1">
            <motion.div whileTap={{ scale: 0.9 }}>
              <Button 
                size="sm"
                variant="outline"
                onClick={(e) => {
                  e.stopPropagation();
                }}
              >
                <MessageCircle className="size-3 mr-1" />
                Message
              </Button>
            </motion.div>
            <motion.div whileTap={{ scale: 0.9 }}>
              <Button 
                size="sm"
                variant="outline"
                onClick={(e) => {
                  e.stopPropagation();
                }}
              >
                <Share2 className="size-3" />
              </Button>
            </motion.div>
          </div>

          <Button 
            size="sm"
            className="bg-gradient-to-r from-blue-500 to-purple-600"
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(job);
            }}
          >
            Apply Now
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
