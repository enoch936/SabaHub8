"use client";

import { useDeferredValue, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { LeftSidebar } from './LeftSidebar';
import { TopNavbar } from './TopNavbar';
import { RightSidebar } from './RightSidebar';
import { MessagingPanel } from './MessagingPanel';
import { SmartJobCard } from './SmartJobCard';
import { SmartFreelancerCard } from './SmartFreelancerCard';
import { JobDetailsModal } from './JobDetailsModal';
import { FilterSidebar, type FilterState } from './FilterSidebar';
import { Sparkles, Filter, Bookmark, Plus, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { Toaster } from './ui/sonner';
import {
  aiMatchFreelancers,
  aiRecommendJobs,
  bootstrapMarketplaceCatalog,
  bootstrapWorkspaceDemoData,
  createThread,
  getEmployerAnalytics,
  getFreelancerWorkspaceAnalytics,
  getUserSettings,
  listAllUsers,
  listMarketplaceFreelancers,
  listOpenJobsPage,
  listTrendingJobs,
  me,
  type AppUser,
  type EmployerAnalytics,
  type FreelancerWorkspaceAnalytics,
  type UserProfile,
} from '@/lib/api';
import { isTokenUsable } from '@/lib/auth';
import { useChatInbox } from '@/lib/chatInbox';
import { getNotificationMessage, getNotificationTitle } from '@/lib/notificationPresentation';
import { useNotifications } from '@/lib/notifications';
import { bootstrapSession, useSession } from '@/lib/session';
import { workspaceRoutes } from '@/lib/workspace-routes';
import { buildCategoryOptions, buildSearchSuggestions, toPremiumFreelancer, toPremiumJob } from '../utils/adapters';
import type { PremiumFreelancer, PremiumJob } from '../types';

type UserRole = 'employer' | 'freelancer';

const DEFAULT_FILTERS: FilterState = {
  categories: [],
  experienceLevels: [],
  budgetRange: [0, 10000],
  budgetType: [],
  minRating: 0,
};

export function PremiumFreelancePlatform() {
  const router = useRouter();
  const sessionToken = useSession((state) => state.token);
  const sessionEmail = useSession((state) => state.email);
  const sessionProfilePictureUrl = useSession((state) => state.profilePictureUrl);
  const sessionRole = useSession((state) => state.role);
  const workspaceRoles = useSession((state) => state.workspaceRoles);
  const setSessionRole = useSession((state) => state.setRole);

  const unreadMessages = useChatInbox((state) => state.unreadMessages);
  const connectInbox = useChatInbox((state) => state.connect);
  const notifications = useNotifications((state) => state.items);
  const unreadNotifications = useNotifications((state) => state.unread);
  const connectNotifications = useNotifications((state) => state.connect);

  const [activeSection, setActiveSection] = useState('home');
  const [userRole, setUserRole] = useState<UserRole>('freelancer');
  const [darkMode, setDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSidebar, setShowSidebar] = useState(true);
  const [showFilters, setShowFilters] = useState(true);
  const [showRightSidebar, setShowRightSidebar] = useState(true);
  const [bookmarkedJobs, setBookmarkedJobs] = useState<string[]>([]);
  const [favoritedFreelancers, setFavoritedFreelancers] = useState<string[]>([]);
  const [selectedJob, setSelectedJob] = useState<PremiumJob | null>(null);
  const [viewMode, setViewMode] = useState<'all' | 'bookmarked'>('all');
  const [activeTab, setActiveTab] = useState<'jobs' | 'freelancers'>('jobs');
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [loading, setLoading] = useState(true);
  const [dataError, setDataError] = useState<string | null>(null);

  const [jobs, setJobs] = useState<PremiumJob[]>([]);
  const [freelancers, setFreelancers] = useState<PremiumFreelancer[]>([]);
  const [recommendedJobs, setRecommendedJobs] = useState<PremiumJob[]>([]);
  const [recommendedFreelancers, setRecommendedFreelancers] = useState<PremiumFreelancer[]>([]);
  const [viewerSettings, setViewerSettings] = useState<UserProfile | null>(null);
  const [viewerName, setViewerName] = useState('SabaHub Member');
  const [viewerImageUrl, setViewerImageUrl] = useState<string | undefined>(undefined);
  const [freelancerAnalytics, setFreelancerAnalytics] = useState<FreelancerWorkspaceAnalytics | null>(null);
  const [employerAnalytics, setEmployerAnalytics] = useState<EmployerAnalytics | null>(null);
  const [workspaceSyncVersion, setWorkspaceSyncVersion] = useState(0);

  const deferredSearchQuery = useDeferredValue(searchQuery);
  const itemsPerPage = 9;

  useEffect(() => {
    bootstrapSession();
  }, []);

  useEffect(() => {
    if (sessionRole === 'EMPLOYER' || sessionRole === 'FREELANCER') {
      setUserRole(sessionRole.toLowerCase() as UserRole);
    }
  }, [sessionRole]);

  useEffect(() => {
    const savedJobs = localStorage.getItem('bookmarkedJobs');
    const savedFreelancers = localStorage.getItem('favoritedFreelancers');
    if (savedJobs) setBookmarkedJobs(JSON.parse(savedJobs));
    if (savedFreelancers) setFavoritedFreelancers(JSON.parse(savedFreelancers));
  }, []);

  useEffect(() => {
    localStorage.setItem('bookmarkedJobs', JSON.stringify(bookmarkedJobs));
  }, [bookmarkedJobs]);

  useEffect(() => {
    localStorage.setItem('favoritedFreelancers', JSON.stringify(favoritedFreelancers));
  }, [favoritedFreelancers]);

  useEffect(() => {
    const savedDarkMode = localStorage.getItem('premiumDarkMode');
    if (savedDarkMode !== null) {
      setDarkMode(savedDarkMode === 'true');
    }
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('premiumDarkMode', String(darkMode));
  }, [darkMode]);

  useEffect(() => {
    const token = readUsableToken(sessionToken);
    if (!token) {
      return;
    }
    void connectNotifications();
    void connectInbox();
  }, [connectInbox, connectNotifications, sessionToken]);

  useEffect(() => {
    let active = true;
    const token = readUsableToken(sessionToken);

    setLoading(true);
    setDataError(null);

    void (async () => {
      const loadMarketplaceSnapshot = () =>
        Promise.allSettled([
          listOpenJobsPage({ page: 0, size: 60 }),
          listTrendingJobs(6),
          listMarketplaceFreelancers({ page: 0, size: 60 }),
          listAllUsers(200),
          token ? aiRecommendJobs(6) : Promise.resolve([]),
          token ? me() : Promise.resolve(null),
          token ? getUserSettings() : Promise.resolve(null),
        ]);

      const applyMarketplaceSnapshot = (
        [
          jobsResult,
          trendingResult,
          freelancersResult,
          usersResult,
          recommendationsResult,
          meResult,
          settingsResult,
        ]: Awaited<ReturnType<typeof loadMarketplaceSnapshot>>
      ) => {
        const directoryUsers = usersResult.status === 'fulfilled' ? usersResult.value.users ?? [] : [];
        const nextUsersById = new Map(directoryUsers.map((user) => [user.id, user]));

        const liveJobs = jobsResult.status === 'fulfilled'
          ? jobsResult.value.items.map((job) => toPremiumJob(job, nextUsersById))
          : [];
        const liveTrending = trendingResult.status === 'fulfilled'
          ? trendingResult.value.map((job) => ({ ...toPremiumJob(job, nextUsersById), trending: true }))
          : [];
        const liveFreelancers = freelancersResult.status === 'fulfilled'
          ? freelancersResult.value.items.map(toPremiumFreelancer)
          : [];

        const jobsById = new Map(liveJobs.map((job) => [job.id, job]));
        const aiRecommendedJobs = recommendationsResult.status === 'fulfilled'
          ? recommendationsResult.value
              .map((item) => jobsById.get(item.jobId))
              .filter((job): job is PremiumJob => Boolean(job))
              .map((job) => ({ ...job, trending: true }))
          : [];

        setJobs(liveJobs);
        setFreelancers(liveFreelancers);
        setRecommendedJobs(
          aiRecommendedJobs.length > 0
            ? aiRecommendedJobs
            : (liveTrending.length > 0 ? liveTrending : liveJobs.slice(0, 6).map((job) => ({ ...job, trending: true })))
        );

        const settingsValue = settingsResult.status === 'fulfilled' && settingsResult.value && typeof settingsResult.value === 'object'
          ? (settingsResult.value as UserProfile)
          : null;
        setViewerSettings(settingsValue);

        const meValue = meResult.status === 'fulfilled' && meResult.value && typeof meResult.value === 'object'
          ? meResult.value
          : null;

        setViewerName(resolveViewerName(meValue?.fullName, sessionEmail));
        setViewerImageUrl(settingsValue?.profilePictureUrl || sessionProfilePictureUrl || undefined);

        return {
          liveJobsCount: liveJobs.length,
          liveFreelancersCount: liveFreelancers.length,
          hasPartialLoadFailure: jobsResult.status === 'rejected' || freelancersResult.status === 'rejected',
        };
      };

      let snapshot = await loadMarketplaceSnapshot();
      if (!active) return;

      let marketState = applyMarketplaceSnapshot(snapshot);
      let shouldReloadSnapshot = false;

      if (
        marketState.liveJobsCount === 0 &&
        marketState.liveFreelancersCount === 0 &&
        shouldAutoBootstrapMarketplace()
      ) {
        const bootstrapResult = await bootstrapMarketplaceCatalog().catch(() => null);

        if (bootstrapResult?.createdAny) {
          shouldReloadSnapshot = true;
        }
      }

      if (token && shouldAutoBootstrapMarketplace()) {
        const workspaceBootstrap = await bootstrapWorkspaceDemoData().catch(() => null);
        if (!active) return;

        if (workspaceBootstrap?.createdAny) {
          shouldReloadSnapshot = true;
          setWorkspaceSyncVersion((previous) => previous + 1);
        }
      }

      if (shouldReloadSnapshot) {
        snapshot = await loadMarketplaceSnapshot();
        if (!active) return;
        marketState = applyMarketplaceSnapshot(snapshot);
      }

      if (!active) return;

      if (marketState.liveJobsCount === 0 && marketState.liveFreelancersCount === 0) {
        setDataError('No live marketplace data is available from the backend yet.');
      } else if (marketState.hasPartialLoadFailure) {
        setDataError('Some marketplace widgets could not load live backend data.');
      } else {
        setDataError(null);
      }

      setLoading(false);
    })();

    return () => {
      active = false;
    };
  }, [sessionEmail, sessionProfilePictureUrl, sessionToken, userRole]);

  useEffect(() => {
    const token = readUsableToken(sessionToken);
    let active = true;

    if (!token) {
      setFreelancerAnalytics(null);
      setEmployerAnalytics(null);
      return;
    }

    void (async () => {
      if (userRole === 'freelancer') {
        const analytics = await getFreelancerWorkspaceAnalytics().catch(() => null);
        if (!active) return;
        setFreelancerAnalytics(analytics);
        setEmployerAnalytics(null);
      } else {
        const analytics = await getEmployerAnalytics().catch(() => null);
        if (!active) return;
        setEmployerAnalytics(analytics);
        setFreelancerAnalytics(null);
      }
    })();

    return () => {
      active = false;
    };
  }, [sessionToken, userRole, workspaceSyncVersion]);

  useEffect(() => {
    let active = true;

    const fallback = [...freelancers]
      .sort((left, right) => {
        const leftScore = left.rating * 100 + left.reviewCount;
        const rightScore = right.rating * 100 + right.reviewCount;
        return rightScore - leftScore;
      })
      .slice(0, 6);

    if (fallback.length === 0) {
      setRecommendedFreelancers([]);
      return;
    }

    if (userRole !== 'employer' || !readUsableToken(sessionToken) || jobs.length === 0) {
      setRecommendedFreelancers(fallback);
      return;
    }

    void (async () => {
      const matches = await aiMatchFreelancers(jobs[0].id, 6).catch(() => []);
      if (!active) return;
      const freelancersById = new Map(freelancers.map((freelancer) => [freelancer.id, freelancer]));
      const matchedProfiles = matches
        .map((match) => freelancersById.get(match.freelancerId))
        .filter((freelancer): freelancer is PremiumFreelancer => Boolean(freelancer));

      setRecommendedFreelancers(matchedProfiles.length > 0 ? matchedProfiles : fallback);
    })();

    return () => {
      active = false;
    };
  }, [freelancers, jobs, sessionToken, userRole]);

  useEffect(() => {
    if (activeSection === 'jobs') {
      setActiveTab('jobs');
      return;
    }
    if (activeSection === 'talent') {
      setActiveTab('freelancers');
    }
  }, [activeSection]);

  useEffect(() => {
    setCurrentPage(1);
  }, [activeTab, deferredSearchQuery, filters, viewMode]);

  const toggleBookmark = (jobId: string) => {
    setBookmarkedJobs((previous) => {
      const isBookmarked = previous.includes(jobId);
      if (isBookmarked) {
        return previous.filter((id) => id !== jobId);
      }
      toast.success('Job saved to your workspace');
      return [...previous, jobId];
    });
  };

  const toggleFavorite = (freelancerId: string) => {
    setFavoritedFreelancers((previous) => {
      const isFavorited = previous.includes(freelancerId);
      if (isFavorited) {
        return previous.filter((id) => id !== freelancerId);
      }
      toast.success('Talent added to your shortlist');
      return [...previous, freelancerId];
    });
  };

  const clearFilters = () => {
    setFilters(DEFAULT_FILTERS);
    toast.info('Filters cleared');
  };

  const filteredJobs = useMemo(() => {
    let items = jobs;
    const query = deferredSearchQuery.trim().toLowerCase();

    if (viewMode === 'bookmarked') {
      items = items.filter((job) => bookmarkedJobs.includes(job.id));
    }

    if (query) {
      items = items.filter((job) =>
        job.title.toLowerCase().includes(query) ||
        job.description.toLowerCase().includes(query) ||
        job.category.toLowerCase().includes(query) ||
        job.postedBy.toLowerCase().includes(query) ||
        job.skillsRequired.some((skill) => skill.toLowerCase().includes(query))
      );
    }

    if (filters.categories.length > 0) {
      items = items.filter((job) => filters.categories.includes(job.category));
    }

    if (filters.experienceLevels.length > 0) {
      items = items.filter((job) => filters.experienceLevels.includes(job.experienceLevel));
    }

    if (filters.budgetType.length > 0) {
      items = items.filter((job) => filters.budgetType.includes(job.budgetType));
    }

    items = items.filter((job) =>
      job.budget >= filters.budgetRange[0] &&
      job.budget <= filters.budgetRange[1]
    );

    if (filters.minRating > 0) {
      items = items.filter((job) => job.rating >= filters.minRating);
    }

    return items;
  }, [bookmarkedJobs, deferredSearchQuery, filters, jobs, viewMode]);

  const filteredFreelancers = useMemo(() => {
    let items = freelancers;
    const query = deferredSearchQuery.trim().toLowerCase();

    if (viewMode === 'bookmarked') {
      items = items.filter((freelancer) => favoritedFreelancers.includes(freelancer.id));
    }

    if (query) {
      items = items.filter((freelancer) =>
        freelancer.name.toLowerCase().includes(query) ||
        freelancer.title.toLowerCase().includes(query) ||
        freelancer.bio.toLowerCase().includes(query) ||
        freelancer.location.toLowerCase().includes(query) ||
        freelancer.skills.some((skill) => skill.toLowerCase().includes(query))
      );
    }

    if (filters.categories.length > 0) {
      items = items.filter((freelancer) =>
        freelancer.skills.some((skill) =>
          filters.categories.some((category) =>
            skill.toLowerCase().includes(category.toLowerCase()) ||
            category.toLowerCase().includes(skill.toLowerCase())
          )
        )
      );
    }

    const hourlyMin = Math.max(0, filters.budgetRange[0] / 50);
    const hourlyMax = filters.budgetRange[1] >= 10000 ? Number.POSITIVE_INFINITY : filters.budgetRange[1] / 50;
    items = items.filter((freelancer) =>
      freelancer.hourlyRate >= hourlyMin &&
      freelancer.hourlyRate <= hourlyMax
    );

    if (filters.minRating > 0) {
      items = items.filter((freelancer) => freelancer.rating >= filters.minRating);
    }

    return items;
  }, [deferredSearchQuery, favoritedFreelancers, filters, freelancers, viewMode]);

  const currentItems = activeTab === 'jobs' ? filteredJobs : filteredFreelancers;
  const totalPages = Math.ceil(currentItems.length / itemsPerPage);
  const paginatedItems = currentItems.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const categoryOptions = useMemo(
    () => buildCategoryOptions(jobs, freelancers),
    [freelancers, jobs],
  );
  const searchSuggestions = useMemo(
    () => buildSearchSuggestions(recommendedJobs.length > 0 ? recommendedJobs : jobs, freelancers),
    [freelancers, jobs, recommendedJobs],
  );
  const notificationPreviews = useMemo(
    () =>
      notifications.slice(0, 5).map((notification) => ({
        id: notification.id,
        title: getNotificationTitle(notification),
        message: getNotificationMessage(notification),
        createdAt: notification.createdAt,
        read: notification.read,
      })),
    [notifications],
  );

  const activityMetrics = useMemo(() => {
    if (userRole === 'employer') {
      return [
        {
          label: 'Projects Posted',
          value: String(employerAnalytics?.totalProjectsPosted ?? jobs.length),
          progress: clampProgress((employerAnalytics?.totalProjectsPosted ?? jobs.length) * 10),
          accent: 'blue' as const,
        },
        {
          label: 'Active Projects',
          value: String(employerAnalytics?.activeProjects ?? 0),
          progress: clampProgress((employerAnalytics?.activeProjects ?? 0) * 20),
          accent: 'green' as const,
        },
        {
          label: 'Repeat Hire Rate',
          value: formatPercent(employerAnalytics?.repeatHireRate ?? 0),
          progress: clampProgress(employerAnalytics?.repeatHireRate ?? 0),
          accent: 'amber' as const,
        },
      ];
    }

    const profileViews = viewerSettings?.profileViewsCount ?? 0;
    const proposalsSent = freelancerAnalytics?.totalProposals ?? viewerSettings?.proposalsSentCount ?? 0;
    const successRate = freelancerAnalytics?.successRate ?? viewerSettings?.successRate ?? 0;

    return [
      {
        label: 'Profile Views',
        value: profileViews.toLocaleString(),
        progress: clampProgress((profileViews / 500) * 100),
        accent: 'green' as const,
      },
      {
        label: 'Proposals Sent',
        value: proposalsSent.toLocaleString(),
        progress: clampProgress((proposalsSent / 25) * 100),
        accent: 'blue' as const,
      },
      {
        label: 'Success Rate',
        value: formatPercent(successRate),
        progress: clampProgress(successRate),
        accent: 'green' as const,
      },
    ];
  }, [employerAnalytics, freelancerAnalytics, jobs.length, userRole, viewerSettings]);

  const summaryStats = useMemo(() => {
    if (userRole === 'employer') {
      return [
        { label: 'Total Spend', value: formatMoney(employerAnalytics?.totalSpent ?? 0) },
        { label: 'Talent Hired', value: String(employerAnalytics?.totalHired ?? 0) },
        {
          label: 'Average Rating',
          value: employerAnalytics?.averageRating
            ? employerAnalytics.averageRating.toFixed(1)
            : 'New',
        },
      ];
    }

    return [
      { label: 'Available Balance', value: formatMoney(freelancerAnalytics?.currentBalance ?? 0) },
      {
        label: 'Completed Projects',
        value: String(freelancerAnalytics?.completedProjects ?? viewerSettings?.contractsCompletedCount ?? 0),
      },
      { label: 'Pending Balance', value: formatMoney(freelancerAnalytics?.pendingBalance ?? 0) },
    ];
  }, [employerAnalytics, freelancerAnalytics, userRole, viewerSettings]);

  const handleRoleChange = (role: UserRole) => {
    setUserRole(role);
    const nextRole = role.toUpperCase() as 'EMPLOYER' | 'FREELANCER';
    if (workspaceRoles.includes(nextRole)) {
      setSessionRole(nextRole);
    }
  };

  const handleSectionChange = (section: string) => {
    setActiveSection(section);
    const routes: Record<string, string | undefined> = {
      messages: '/chat',
      wallet: workspaceRoutes.wallet,
      analytics: workspaceRoutes.analytics,
      proposals: workspaceRoutes.proposals,
      contracts: workspaceRoutes.contracts,
      'ai-assistant': workspaceRoutes.assistant,
      settings: workspaceRoutes.settings,
      help: workspaceRoutes.help,
    };

    if (routes[section]) {
      router.push(routes[section] as string);
    }
  };

  const handleCreatePrimary = () => {
    router.push(userRole === 'employer' ? workspaceRoutes.createJob : workspaceRoutes.manageJobs);
  };

  const handleOpenConversation = async (participantId: string | undefined, label: string) => {
    const token = readUsableToken(sessionToken);
    if (!token) {
      router.push('/login');
      return;
    }
    if (!participantId) {
      toast.error('Direct messaging is not available for this profile yet.');
      return;
    }

    try {
      await createThread({ participantIds: [participantId] });
      toast.success(`Conversation opened with ${label}`);
      router.push('/chat');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Unable to open conversation right now.');
    }
  };

  const renderEmptyState = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center h-64 text-center"
    >
      <div className="text-6xl mb-4">👀</div>
      <h3 className="text-xl mb-2">No {activeTab} found</h3>
      <p className="text-muted-foreground max-w-md mb-4">
        {viewMode === 'bookmarked'
          ? `You haven't saved any ${activeTab} yet. Start exploring and save your favorites.`
          : "Try adjusting your filters or search query to match the live backend data."}
      </p>
      {viewMode === 'all' && (
        <Button onClick={clearFilters} variant="outline">
          Clear Filters
        </Button>
      )}
    </motion.div>
  );

  return (
    <div className={darkMode ? "flex h-screen bg-slate-950 text-slate-100" : "zip-white-static flex h-screen bg-white text-slate-900"}>
      <Toaster />

      <AnimatePresence>
        {showSidebar && (
          <motion.div
            initial={{ x: -280, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -280, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="h-full"
          >
            <LeftSidebar 
              activeSection={activeSection}
              onSectionChange={handleSectionChange}
              messageBadge={unreadMessages}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNavbar
          userRole={userRole}
          onRoleChange={handleRoleChange}
          darkMode={darkMode}
          onDarkModeToggle={() => setDarkMode((previous) => !previous)}
          onMenuToggle={() => setShowSidebar((previous) => !previous)}
          searchQuery={searchQuery}
          onSearchQueryChange={setSearchQuery}
          searchSuggestions={searchSuggestions}
          notificationCount={unreadNotifications}
          notifications={notificationPreviews}
          profileName={viewerName}
          profileSubtitle={resolveViewerSubtitle(userRole, viewerSettings)}
          profileImageUrl={viewerImageUrl}
        />

        <div className="flex flex-1 overflow-hidden">
          <AnimatePresence>
            {showFilters && (
              <motion.div
                initial={{ x: -300, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -300, opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <FilterSidebar 
                  filters={filters}
                  onFiltersChange={setFilters}
                  onClearFilters={clearFilters}
                  categoryOptions={categoryOptions}
                />
              </motion.div>
            )}
          </AnimatePresence>

          <main className="flex-1 overflow-y-auto">
            <div className="p-6 max-w-7xl mx-auto">
              {dataError && (
                <div className="mb-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
                  {dataError}
                </div>
              )}

              <div className="flex items-center justify-between mb-6 gap-3 flex-wrap">
                <div className="flex items-center gap-3 flex-wrap">
                  <Button
                    variant={showFilters ? "default" : "outline"}
                    onClick={() => setShowFilters(!showFilters)}
                    className="gap-2"
                  >
                    <Filter className="size-4" />
                    Filters
                  </Button>

                  <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'jobs' | 'freelancers')}>
                    <TabsList>
                      <TabsTrigger value="jobs" className="gap-2">
                        Jobs
                        <Badge variant="secondary">{filteredJobs.length}</Badge>
                      </TabsTrigger>
                      <TabsTrigger value="freelancers" className="gap-2">
                        Talent
                        <Badge variant="secondary">{filteredFreelancers.length}</Badge>
                      </TabsTrigger>
                    </TabsList>
                  </Tabs>

                  <Button
                    variant={viewMode === 'bookmarked' ? 'default' : 'outline'}
                    onClick={() => setViewMode(viewMode === 'all' ? 'bookmarked' : 'all')}
                    className="gap-2"
                  >
                    <Bookmark className="size-4" />
                    Saved
                    <Badge variant={viewMode === 'bookmarked' ? 'secondary' : 'outline'}>
                      {activeTab === 'jobs' ? bookmarkedJobs.length : favoritedFreelancers.length}
                    </Badge>
                  </Button>
                </div>

                <Button
                  className="gap-2 bg-gradient-to-r from-blue-500 to-purple-600"
                  onClick={handleCreatePrimary}
                >
                  <Plus className="size-4" />
                  {userRole === 'employer' ? 'Post Job' : 'Manage Gigs'}
                </Button>
              </div>

              {viewMode === 'all' && currentPage === 1 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-8"
                >
                  <div className="flex items-center gap-2 mb-4">
                    <Sparkles className="size-5 text-purple-500" />
                    <h2 className="text-xl">
                      {activeTab === 'jobs' ? 'AI Recommended for You' : 'Top Rated Talent'}
                    </h2>
                    <Badge className="bg-gradient-to-r from-blue-500 to-purple-600">AI</Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {activeTab === 'jobs'
                      ? (recommendedJobs.length > 0 ? recommendedJobs : jobs.slice(0, 6)).slice(0, 3).map((job, index) => (
                          <SmartJobCard
                            key={job.id}
                            job={job}
                            isBookmarked={bookmarkedJobs.includes(job.id)}
                            onBookmarkToggle={toggleBookmark}
                            onViewDetails={setSelectedJob}
                            aiMatchScore={95 - index * 5}
                          />
                        ))
                      : (recommendedFreelancers.length > 0 ? recommendedFreelancers : freelancers.slice(0, 6)).slice(0, 3).map((freelancer) => (
                          <SmartFreelancerCard
                            key={freelancer.id}
                            freelancer={freelancer}
                            isFavorited={favoritedFreelancers.includes(freelancer.id)}
                            onFavoriteToggle={toggleFavorite}
                            onViewProfile={(profile) => void handleOpenConversation(profile.userId, profile.name)}
                          />
                        ))
                    }
                  </div>
                </motion.div>
              )}

              <div className="mb-4">
                <h2 className="text-xl">
                  {viewMode === 'bookmarked'
                    ? `Saved ${activeTab === 'jobs' ? 'Jobs' : 'Talent'}`
                    : `All ${activeTab === 'jobs' ? 'Jobs' : 'Freelancers'}`
                  }
                </h2>
              </div>

              {loading ? (
                <div className="rounded-2xl border border-dashed border-slate-300 bg-white/80 px-6 py-12 text-center text-slate-600">
                  Loading live marketplace data from the backend...
                </div>
              ) : currentItems.length === 0 ? (
                renderEmptyState()
              ) : (
                <>
                  <motion.div 
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8"
                    layout
                  >
                    <AnimatePresence>
                      {activeTab === 'jobs'
                        ? (paginatedItems as PremiumJob[]).map((job, index) => (
                            <motion.div
                              key={job.id}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, scale: 0.9 }}
                              transition={{ delay: index * 0.05 }}
                            >
                              <SmartJobCard
                                job={job}
                                isBookmarked={bookmarkedJobs.includes(job.id)}
                                onBookmarkToggle={toggleBookmark}
                                onViewDetails={setSelectedJob}
                                aiMatchScore={85 + ((index * 3) % 15)}
                              />
                            </motion.div>
                          ))
                        : (paginatedItems as PremiumFreelancer[]).map((freelancer, index) => (
                            <motion.div
                              key={freelancer.id}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, scale: 0.9 }}
                              transition={{ delay: index * 0.05 }}
                            >
                              <SmartFreelancerCard
                                freelancer={freelancer}
                                isFavorited={favoritedFreelancers.includes(freelancer.id)}
                                onFavoriteToggle={toggleFavorite}
                                onViewProfile={(profile) => void handleOpenConversation(profile.userId, profile.name)}
                              />
                            </motion.div>
                          ))
                      }
                    </AnimatePresence>
                  </motion.div>

                  {totalPages > 1 && (
                    <div className="flex items-center justify-center gap-2">
                      <Button
                        variant="outline"
                        onClick={() => setCurrentPage((page) => Math.max(1, page - 1))}
                        disabled={currentPage === 1}
                      >
                        Previous
                      </Button>
                      
                      <div className="flex gap-1">
                        {[...Array(Math.min(totalPages, 5))].map((_, index) => {
                          const pageNumber = index + 1;
                          return (
                            <Button
                              key={pageNumber}
                              variant={currentPage === pageNumber ? 'default' : 'outline'}
                              size="icon"
                              onClick={() => setCurrentPage(pageNumber)}
                            >
                              {pageNumber}
                            </Button>
                          );
                        })}
                      </div>

                      <Button
                        variant="outline"
                        onClick={() => setCurrentPage((page) => Math.min(totalPages, page + 1))}
                        disabled={currentPage === totalPages}
                      >
                        Next
                      </Button>
                    </div>
                  )}
                </>
              )}
            </div>
          </main>

          <div className="relative h-full min-h-0">
            <Button
              type="button"
              size="icon"
              variant="outline"
              onClick={() => setShowRightSidebar((previous) => !previous)}
              className="absolute -left-4 top-6 z-20 h-8 w-8 rounded-full bg-white"
              aria-label={showRightSidebar ? 'Hide right sidebar' : 'Show right sidebar'}
            >
              {showRightSidebar ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
            </Button>

            <AnimatePresence>
              {showRightSidebar && (
                <motion.div
                  initial={{ x: 280, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: 280, opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  className="h-full min-h-0"
                >
                  <RightSidebar
                    activityTitle={userRole === 'employer' ? 'Hiring Activity' : 'Your Activity'}
                    activityMetrics={activityMetrics}
                    trendingJobs={(recommendedJobs.length > 0 ? recommendedJobs : jobs).slice(0, 3)}
                    topFreelancers={(recommendedFreelancers.length > 0 ? recommendedFreelancers : freelancers).slice(0, 3)}
                    summaryTitle={userRole === 'employer' ? 'Hiring Snapshot' : 'Workspace Snapshot'}
                    summaryStats={summaryStats}
                    onJobSelect={setSelectedJob}
                    onFreelancerSelect={(freelancer) => void handleOpenConversation(freelancer.userId, freelancer.name)}
                    loading={loading}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      <MessagingPanel />

      <JobDetailsModal
        job={selectedJob}
        isOpen={!!selectedJob}
        onClose={() => setSelectedJob(null)}
        isBookmarked={selectedJob ? bookmarkedJobs.includes(selectedJob.id) : false}
        onBookmarkToggle={toggleBookmark}
      />
    </div>
  );
}

function readUsableToken(sessionToken?: string | null) {
  const token =
    typeof sessionToken === 'string'
      ? sessionToken
      : (typeof window !== 'undefined' ? window.localStorage.getItem('auth_token') : null);
  return isTokenUsable(token) ? token : null;
}

function shouldAutoBootstrapMarketplace() {
  if (typeof window === 'undefined') {
    return false;
  }

  const hostname = window.location.hostname.trim().toLowerCase();
  return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '0.0.0.0' || hostname === '::1';
}

function resolveViewerName(fullName: string | undefined, email: string | undefined) {
  if (fullName && fullName.trim()) {
    return fullName.trim();
  }
  if (email && email.includes('@')) {
    return email.slice(0, email.indexOf('@'));
  }
  return 'SabaHub Member';
}

function resolveViewerSubtitle(userRole: UserRole, settings: UserProfile | null) {
  if (userRole === 'employer') {
    return 'Employer workspace';
  }
  if (settings?.expertise?.trim()) {
    return settings.expertise.trim();
  }
  return 'Freelancer workspace';
}

function formatMoney(value: number | null | undefined) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(typeof value === 'number' ? value : 0);
}

function formatPercent(value: number | null | undefined) {
  const safeValue = typeof value === 'number' ? value : 0;
  return `${Math.round(safeValue)}%`;
}

function clampProgress(value: number | null | undefined) {
  const safeValue = typeof value === 'number' && Number.isFinite(value) ? value : 0;
  return Math.max(0, Math.min(100, safeValue));
}
