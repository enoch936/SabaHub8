import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Slider } from './ui/slider';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { X } from 'lucide-react';

export interface FilterState {
  categories: string[];
  experienceLevels: string[];
  budgetRange: [number, number];
  budgetType: string[];
  minRating: number;
}

interface FilterSidebarProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  onClearFilters: () => void;
  categoryOptions?: string[];
}

const experienceLevels = ['entry', 'intermediate', 'expert'];

export function FilterSidebar({
  filters,
  onFiltersChange,
  onClearFilters,
  categoryOptions,
}: FilterSidebarProps) {
  const categories = categoryOptions?.length
    ? categoryOptions
    : [
        'Web Development',
        'Graphic Design',
        'Digital Marketing',
        'Video Production',
        'Content Writing',
        'UI/UX Design',
        'Social Media',
        'Photography',
        'Data Science',
      ];

  const toggleCategory = (category: string) => {
    const newCategories = filters.categories.includes(category)
      ? filters.categories.filter(c => c !== category)
      : [...filters.categories, category];
    onFiltersChange({ ...filters, categories: newCategories });
  };

  const toggleExperienceLevel = (level: string) => {
    const newLevels = filters.experienceLevels.includes(level)
      ? filters.experienceLevels.filter(l => l !== level)
      : [...filters.experienceLevels, level];
    onFiltersChange({ ...filters, experienceLevels: newLevels });
  };

  const toggleBudgetType = (type: string) => {
    const newTypes = filters.budgetType.includes(type)
      ? filters.budgetType.filter(t => t !== type)
      : [...filters.budgetType, type];
    onFiltersChange({ ...filters, budgetType: newTypes });
  };

  const hasActiveFilters = 
    filters.categories.length > 0 ||
    filters.experienceLevels.length > 0 ||
    filters.budgetType.length > 0 ||
    filters.minRating > 0 ||
    filters.budgetRange[0] > 0 ||
    filters.budgetRange[1] < 10000;

  return (
    <div className="w-80 border-r bg-white dark:bg-slate-900 dark:border-slate-700 p-6 space-y-6 overflow-y-auto">
      <div className="flex items-center justify-between">
        <h2 className="text-xl">Filters</h2>
        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={onClearFilters}>
            Clear All
          </Button>
        )}
      </div>

      {/* Categories */}
      <div className="space-y-3">
        <Label>Categories</Label>
        <div className="space-y-2">
          {categories.map((category) => (
            <div key={category} className="flex items-center space-x-2">
              <Checkbox
                id={`category-${category}`}
                checked={filters.categories.includes(category)}
                onCheckedChange={() => toggleCategory(category)}
              />
              <label
                htmlFor={`category-${category}`}
                className="text-sm cursor-pointer flex-1"
              >
                {category}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Experience Level */}
      <div className="space-y-3">
        <Label>Experience Level</Label>
        <div className="space-y-2">
          {experienceLevels.map((level) => (
            <div key={level} className="flex items-center space-x-2">
              <Checkbox
                id={`level-${level}`}
                checked={filters.experienceLevels.includes(level)}
                onCheckedChange={() => toggleExperienceLevel(level)}
              />
              <label
                htmlFor={`level-${level}`}
                className="text-sm cursor-pointer capitalize flex-1"
              >
                {level}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Budget Type */}
      <div className="space-y-3">
        <Label>Budget Type</Label>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="budget-fixed"
              checked={filters.budgetType.includes('fixed')}
              onCheckedChange={() => toggleBudgetType('fixed')}
            />
            <label htmlFor="budget-fixed" className="text-sm cursor-pointer flex-1">
              Fixed Price
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="budget-hourly"
              checked={filters.budgetType.includes('hourly')}
              onCheckedChange={() => toggleBudgetType('hourly')}
            />
            <label htmlFor="budget-hourly" className="text-sm cursor-pointer flex-1">
              Hourly Rate
            </label>
          </div>
        </div>
      </div>

      {/* Budget Range */}
      <div className="space-y-3">
        <Label>Budget Range</Label>
        <div className="pt-2">
          <Slider
            value={filters.budgetRange}
            onValueChange={(value) => 
              onFiltersChange({ ...filters, budgetRange: value as [number, number] })
            }
            min={0}
            max={10000}
            step={100}
            className="mb-3"
          />
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>${filters.budgetRange[0].toLocaleString()}</span>
            <span>${filters.budgetRange[1].toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Minimum Rating */}
      <div className="space-y-3">
        <Label>Minimum Rating</Label>
        <div className="flex flex-wrap gap-2">
          {[0, 3, 4, 4.5].map((rating) => (
            <Badge
              key={rating}
              variant={filters.minRating === rating ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => onFiltersChange({ ...filters, minRating: rating })}
            >
              {rating === 0 ? 'Any' : `${rating}+`}
            </Badge>
          ))}
        </div>
      </div>

      {/* Active Filters Summary */}
      {hasActiveFilters && (
        <div className="space-y-2 pt-4 border-t">
          <Label>Active Filters</Label>
          <div className="flex flex-wrap gap-2">
            {filters.categories.map(cat => (
              <Badge key={cat} variant="secondary" className="gap-1">
                {cat}
                <X 
                  className="size-3 cursor-pointer" 
                  onClick={() => toggleCategory(cat)}
                />
              </Badge>
            ))}
            {filters.experienceLevels.map(level => (
              <Badge key={level} variant="secondary" className="gap-1 capitalize">
                {level}
                <X 
                  className="size-3 cursor-pointer" 
                  onClick={() => toggleExperienceLevel(level)}
                />
              </Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
