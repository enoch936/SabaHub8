import { TrendingUp, Star, DollarSign, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import type { PremiumFreelancer, PremiumJob } from '../types';

type ActivityMetric = {
  label: string;
  value: string;
  progress: number;
  accent?: 'green' | 'blue' | 'amber';
};

type SummaryStat = {
  label: string;
  value: string;
};

interface RightSidebarProps {
  activityTitle: string;
  activityMetrics: ActivityMetric[];
  trendingJobs: PremiumJob[];
  topFreelancers: PremiumFreelancer[];
  summaryTitle: string;
  summaryStats: SummaryStat[];
  onJobSelect: (job: PremiumJob) => void;
  onFreelancerSelect: (freelancer: PremiumFreelancer) => void;
  loading?: boolean;
}

const accentText: Record<NonNullable<ActivityMetric['accent']>, string> = {
  green: 'text-green-600',
  blue: 'text-blue-600',
  amber: 'text-amber-600',
};

export function RightSidebar({
  activityTitle,
  activityMetrics,
  trendingJobs,
  topFreelancers,
  summaryTitle,
  summaryStats,
  onJobSelect,
  onFreelancerSelect,
  loading,
}: RightSidebarProps) {
  return (
    <aside className="w-80 h-full min-h-0 border-l bg-white dark:bg-slate-900 dark:border-slate-700 overflow-y-auto p-4 space-y-4">
      <Card className="bg-white border-slate-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Zap className="size-4 text-blue-600" />
            {activityTitle}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {activityMetrics.map((metric) => (
            <div key={metric.label} className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{metric.label}</span>
                <span className={metric.accent ? accentText[metric.accent] : ''}>{metric.value}</span>
              </div>
              <Progress value={metric.progress} className="h-1.5" />
            </div>
          ))}
          {loading && activityMetrics.length === 0 && (
            <p className="text-sm text-muted-foreground">Loading live workspace metrics...</p>
          )}
        </CardContent>
      </Card>

      <Card className="bg-white border-slate-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="size-4 text-red-500" />
            Trending Jobs
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {trendingJobs.map((job) => (
            <button
              key={job.id}
              type="button"
              className="w-full text-left p-3 rounded-lg border bg-card"
              onClick={() => onJobSelect(job)}
            >
              <div className="flex items-start gap-2 mb-2">
                <img 
                  src={job.image} 
                  alt={job.title}
                  className="size-10 rounded object-cover"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm line-clamp-1">
                    {job.title}
                  </h4>
                  <p className="text-xs text-muted-foreground">{job.postedBy}</p>
                </div>
              </div>
              <div className="flex items-center justify-between text-xs">
                <Badge variant="secondary" className="text-xs">
                  {job.category}
                </Badge>
                <span className="text-green-600 font-medium">
                  {job.budget > 0 ? `$${job.budget.toLocaleString()}` : 'Budget TBD'}
                </span>
              </div>
            </button>
          ))}
          {!loading && trendingJobs.length === 0 && (
            <p className="text-sm text-muted-foreground">No live jobs available yet.</p>
          )}
        </CardContent>
      </Card>

      <Card className="bg-white border-slate-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Star className="size-4 text-yellow-500 fill-yellow-500" />
            Top Talent
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {topFreelancers.map((freelancer) => (
            <div 
              key={freelancer.id}
              className="p-3 rounded-lg border bg-card"
            >
              <div className="flex items-start gap-3 mb-2">
                <img 
                  src={freelancer.profileImage} 
                  alt={freelancer.name}
                  className="size-10 rounded-full object-cover ring-2 ring-background"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm truncate">
                    {freelancer.name}
                  </h4>
                  <p className="text-xs text-muted-foreground truncate">
                    {freelancer.title}
                  </p>
                  <div className="flex items-center gap-1 mt-1">
                    <Star className="size-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-xs">
                      {freelancer.reviewCount > 0 ? freelancer.rating.toFixed(1) : 'New'}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {freelancer.hourlyRate > 0 ? `$${freelancer.hourlyRate}/hr` : 'Rate on request'}
                </span>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-6 text-xs"
                  onClick={() => onFreelancerSelect(freelancer)}
                >
                  Message
                </Button>
              </div>
            </div>
          ))}
          {!loading && topFreelancers.length === 0 && (
            <p className="text-sm text-muted-foreground">No live talent profiles available yet.</p>
          )}
        </CardContent>
      </Card>

      <Card className="bg-white border-slate-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <DollarSign className="size-4 text-green-600" />
            {summaryTitle}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {summaryStats.map((stat) => (
              <div key={stat.label} className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{stat.label}</span>
                <span className="text-sm text-slate-900">{stat.value}</span>
              </div>
            ))}
            {loading && summaryStats.length === 0 && (
              <p className="text-sm text-muted-foreground">Loading live summary...</p>
            )}
          </div>
        </CardContent>
      </Card>
    </aside>
  );
}
