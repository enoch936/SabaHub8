import { useMemo } from 'react';
import { BarChart3, Briefcase, ClipboardCheck, CreditCard, DollarSign, FileText, ShieldCheck, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

const teamMembers = [
  { id: 'm1', name: 'Sarah Chen', role: 'Admin', status: 'online' },
  { id: 'm2', name: 'Marcus Lee', role: 'Recruiter', status: 'online' },
  { id: 'm3', name: 'Nina Patel', role: 'Viewer', status: 'offline' },
];

const kanban = {
  backlog: ['Data platform migration', 'Mobile onboarding redesign'],
  inProgress: ['Senior React hiring sprint', 'Marketing automation setup'],
  review: ['Brand video production'],
  done: ['Q1 hiring dashboard'],
};

const performanceBars = [72, 84, 67, 91, 78, 88, 94];

export function EnterpriseWorkspace() {
  const avgPerformance = useMemo(() => {
    const total = performanceBars.reduce((sum, value) => sum + value, 0);
    return Math.round(total / performanceBars.length);
  }, []);

  return (
    <div className="space-y-6">
      <Card className="border-slate-200 bg-white">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Users className="size-4 text-blue-600" />
            Team Accounts & Permissions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {teamMembers.map((member) => (
            <div key={member.id} className="flex items-center justify-between rounded-xl border p-3">
              <div>
                <p className="text-sm">{member.name}</p>
                <p className="text-xs text-muted-foreground">{member.role}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="gap-1">
                  <ShieldCheck className="size-3" />
                  {member.role}
                </Badge>
                <span className={member.status === 'online' ? 'text-xs text-green-600' : 'text-xs text-slate-500'}>
                  {member.status}
                </span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-slate-200 bg-white">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Briefcase className="size-4 text-purple-600" />
            Project Tracking (Kanban)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-4">
            <div className="rounded-xl border bg-slate-50 p-3">
              <p className="text-xs text-muted-foreground mb-2">Backlog</p>
              <div className="space-y-2">
                {kanban.backlog.map((task) => (
                  <div key={task} className="rounded-lg bg-white border p-2 text-xs">{task}</div>
                ))}
              </div>
            </div>
            <div className="rounded-xl border bg-blue-50 p-3">
              <p className="text-xs text-blue-700 mb-2">In Progress</p>
              <div className="space-y-2">
                {kanban.inProgress.map((task) => (
                  <div key={task} className="rounded-lg bg-white border p-2 text-xs">{task}</div>
                ))}
              </div>
            </div>
            <div className="rounded-xl border bg-amber-50 p-3">
              <p className="text-xs text-amber-700 mb-2">Review</p>
              <div className="space-y-2">
                {kanban.review.map((task) => (
                  <div key={task} className="rounded-lg bg-white border p-2 text-xs">{task}</div>
                ))}
              </div>
            </div>
            <div className="rounded-xl border bg-emerald-50 p-3">
              <p className="text-xs text-emerald-700 mb-2">Done</p>
              <div className="space-y-2">
                {kanban.done.map((task) => (
                  <div key={task} className="rounded-lg bg-white border p-2 text-xs">{task}</div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-slate-200 bg-white">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="size-4 text-indigo-600" />
              Analytics Dashboard
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border p-3">
                <p className="text-xs text-muted-foreground">Hiring Success</p>
                <p className="text-xl text-green-600">84%</p>
              </div>
              <div className="rounded-lg border p-3">
                <p className="text-xs text-muted-foreground">Avg Freelancer Score</p>
                <p className="text-xl text-blue-600">{avgPerformance}%</p>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground">Earnings Graph (Last 7 Days)</p>
              <div className="flex items-end gap-2 h-24 rounded-lg border p-3">
                {performanceBars.map((bar, index) => (
                  <div
                    key={index}
                    className="flex-1 rounded-t bg-gradient-to-t from-blue-500 to-cyan-400"
                    style={{ height: `${bar}%` }}
                  />
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200 bg-white">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <DollarSign className="size-4 text-green-600" />
              Finance & Contracts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-xl border p-3">
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                <CreditCard className="size-3" />
                Invoice & Payment UI
              </p>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Pending Invoice</span>
                  <span className="text-amber-600">$2,100</span>
                </div>
                <Progress value={62} className="h-1.5" />
              </div>
            </div>
            <div className="rounded-xl border p-3">
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                <FileText className="size-3" />
                Contract Management
              </p>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span>Active Contracts</span>
                  <Badge>6</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Awaiting Signature</span>
                  <Badge variant="outline">2</Badge>
                </div>
              </div>
            </div>
            <Button className="w-full gap-2 bg-gradient-to-r from-blue-500 to-purple-600">
              <ClipboardCheck className="size-4" />
              Open Enterprise Console
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
