"use client";

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { MessageCircle, X, Send, Search, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from './ui/utils';
import { isTokenUsable } from '@/lib/auth';
import { useChatInbox } from '@/lib/chatInbox';
import {
  listAllUsers,
  listMessages,
  me,
  sendMessage,
  type AppUser,
  type ChatMessage,
  type ChatThread,
} from '@/lib/api';
import { connectWs, subscribeThread } from '@/lib/ws';

type ThreadView = {
  id: string;
  name: string;
  avatar?: string;
  lastMessage: string;
  timestamp?: string;
  unread: number;
  online: boolean;
  thread: ChatThread;
};

export function MessagingPanel() {
  const router = useRouter();
  const threads = useChatInbox((state) => state.threads);
  const unreadMessages = useChatInbox((state) => state.unreadMessages);
  const connectInbox = useChatInbox((state) => state.connect);
  const refreshInbox = useChatInbox((state) => state.refresh);

  const [isOpen, setIsOpen] = useState(false);
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [usersById, setUsersById] = useState<Record<string, AppUser>>({});
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [loadingConversation, setLoadingConversation] = useState(false);
  const [sending, setSending] = useState(false);

  const hasToken =
    typeof window !== 'undefined' &&
    isTokenUsable(window.localStorage.getItem('auth_token'));

  useEffect(() => {
    if (!isOpen || !hasToken) {
      return;
    }

    void connectInbox();

    let active = true;
    void (async () => {
      const [usersResult, meResult] = await Promise.allSettled([listAllUsers(200), me()]);
      if (!active) return;

      if (usersResult.status === 'fulfilled') {
        const directory = usersResult.value?.users ?? [];
        const nextUsersById = directory.reduce<Record<string, AppUser>>((acc, user) => {
          if (user?.id) {
            acc[user.id] = user;
          }
          return acc;
        }, {});
        setUsersById(nextUsersById);
      }

      if (meResult.status === 'fulfilled' && meResult.value?.id) {
        setCurrentUserId(meResult.value.id);
      }
    })();

    return () => {
      active = false;
    };
  }, [connectInbox, hasToken, isOpen]);

  useEffect(() => {
    if (!isOpen || !hasToken || !selectedThreadId) {
      if (!selectedThreadId) {
        setMessages([]);
      }
      return;
    }

    let active = true;
    let subscription: { unsubscribe: () => void } | null = null;
    setLoadingConversation(true);

    void (async () => {
      await connectWs();
      const history = await listMessages(selectedThreadId).catch(() => []);
      if (!active) return;
      setMessages(normalizeMessages(history));
      setLoadingConversation(false);
      void refreshInbox();

      subscription = subscribeThread(selectedThreadId, (body) => {
        if (!active) return;
        setMessages((prev) => mergeMessages(prev, normalizeMessages([body as ChatMessage])));
        void refreshInbox();
      });
    })();

    return () => {
      active = false;
      subscription?.unsubscribe();
    };
  }, [hasToken, isOpen, refreshInbox, selectedThreadId]);

  const threadViews = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return threads
      .map((thread) => toThreadView(thread, usersById, currentUserId))
      .filter((thread) => {
        if (!query) return true;
        return (
          thread.name.toLowerCase().includes(query) ||
          thread.lastMessage.toLowerCase().includes(query)
        );
      });
  }, [currentUserId, searchQuery, threads, usersById]);

  const selectedThread = threadViews.find((thread) => thread.id === selectedThreadId) ?? null;

  const handleSendMessage = async () => {
    if (!selectedThreadId || !messageInput.trim() || sending) {
      return;
    }

    setSending(true);
    try {
      const created = await sendMessage(selectedThreadId, { type: 'TEXT', text: messageInput.trim() });
      setMessages((prev) => mergeMessages(prev, normalizeMessages([created])));
      setMessageInput('');
      void refreshInbox();
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        whileTap={{ scale: 0.95 }}
      >
        <Button
          size="icon"
          className="size-14 rounded-full shadow-lg bg-gradient-to-br from-blue-500 to-purple-600 relative"
          onClick={() => setIsOpen(!isOpen)}
        >
          <MessageCircle className="size-6" />
          {unreadMessages > 0 && (
            <Badge className="absolute -top-1 -right-1 min-w-6 h-6 flex items-center justify-center p-0 text-xs">
              {unreadMessages > 9 ? '9+' : unreadMessages}
            </Badge>
          )}
        </Button>
      </motion.div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-24 right-6 z-50 w-96 h-[600px] bg-white border rounded-lg shadow-2xl flex flex-col overflow-hidden"
          >
            <div className="p-4 border-b bg-white">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg flex items-center gap-2">
                  <MessageCircle className="size-5" />
                  Messages
                </h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                >
                  <X className="size-4" />
                </Button>
              </div>

              {!selectedThreadId && hasToken && (
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    placeholder="Search messages..."
                    value={searchQuery}
                    onChange={(event) => setSearchQuery(event.target.value)}
                    className="pl-9 h-9"
                  />
                </div>
              )}
            </div>

            {!hasToken ? (
              <div className="flex-1 flex items-center justify-center p-6 text-center">
                <div className="space-y-3">
                  <p className="text-sm text-slate-600">
                    Sign in to access live chat threads and message clients in real time.
                  </p>
                  <Button onClick={() => router.push('/login')}>Go to Login</Button>
                </div>
              </div>
            ) : !selectedThreadId ? (
              <ScrollArea className="flex-1">
                <div className="p-2">
                  {threadViews.map((thread) => (
                    <motion.button
                      key={thread.id}
                      whileTap={{ scale: 0.98 }}
                      type="button"
                      className="w-full text-left p-3 rounded-lg cursor-pointer mb-1"
                      onClick={() => setSelectedThreadId(thread.id)}
                    >
                      <div className="flex items-start gap-3">
                        <div className="relative">
                          <Avatar className="size-12">
                            <AvatarImage src={thread.avatar} />
                            <AvatarFallback>{thread.name[0]}</AvatarFallback>
                          </Avatar>
                          {thread.online && (
                            <div className="absolute bottom-0 right-0 size-3 bg-green-500 rounded-full border-2 border-background" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1 gap-2">
                            <p className="font-medium truncate">{thread.name}</p>
                            <span className="text-xs text-muted-foreground whitespace-nowrap">{thread.timestamp}</span>
                          </div>
                          <p className="text-sm text-muted-foreground truncate">{thread.lastMessage}</p>
                        </div>
                        {thread.unread > 0 && (
                          <Badge className="size-5 flex items-center justify-center p-0 text-xs">
                            {thread.unread > 9 ? '9+' : thread.unread}
                          </Badge>
                        )}
                      </div>
                    </motion.button>
                  ))}
                  {threadViews.length === 0 && (
                    <div className="p-6 text-center text-sm text-muted-foreground">
                      No conversations yet.
                    </div>
                  )}
                </div>
              </ScrollArea>
            ) : (
              <>
                <div className="p-3 border-b flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setSelectedThreadId(null)}
                      className="size-8"
                    >
                      <X className="size-4" />
                    </Button>
                    <Avatar className="size-10">
                      <AvatarImage src={selectedThread?.avatar} />
                      <AvatarFallback>{selectedThread?.name?.[0] ?? 'C'}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm">{selectedThread?.name ?? 'Conversation'}</p>
                      <p className="text-xs text-muted-foreground">
                        {selectedThread?.online ? 'Online' : 'Offline'}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => router.push('/chat')} className="gap-1">
                    <ExternalLink className="size-4" />
                    Inbox
                  </Button>
                </div>

                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-4">
                    {loadingConversation && (
                      <p className="text-sm text-muted-foreground">Loading conversation...</p>
                    )}
                    {!loadingConversation && messages.length === 0 && (
                      <p className="text-sm text-muted-foreground">No messages in this thread yet.</p>
                    )}
                    {messages.map((message) => {
                      const isMine = message.senderId === currentUserId;
                      const sender = usersById[message.senderId];
                      const senderLabel =
                        sender?.fullName ||
                        sender?.username ||
                        message.senderId ||
                        'Participant';

                      return (
                        <motion.div
                          key={message.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className={cn(
                            "flex",
                            isMine ? "justify-end" : "justify-start"
                          )}
                        >
                          <div className={cn(
                            "max-w-[80%] rounded-2xl px-4 py-2",
                            isMine
                              ? "bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-br-sm"
                              : "bg-muted rounded-bl-sm"
                          )}>
                            {!isMine && (
                              <p className="text-xs font-medium mb-1">{senderLabel}</p>
                            )}
                            <p className="text-sm">{message.text || '[Attachment]'}</p>
                            <p className={cn(
                              "text-xs mt-1",
                              isMine ? "text-blue-100" : "text-muted-foreground"
                            )}>
                              {message.createdAt ? new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Now'}
                            </p>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </ScrollArea>

                <div className="p-3 border-t">
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Type a message..."
                      value={messageInput}
                      onChange={(event) => setMessageInput(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === 'Enter' && !event.shiftKey) {
                          event.preventDefault();
                          void handleSendMessage();
                        }
                      }}
                      className="flex-1"
                    />
                    <Button 
                      size="icon" 
                      className="size-9 bg-gradient-to-br from-blue-500 to-purple-600"
                      onClick={() => void handleSendMessage()}
                      disabled={!messageInput.trim() || sending}
                    >
                      <Send className="size-4" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

function toThreadView(
  thread: ChatThread,
  usersById: Record<string, AppUser>,
  currentUserId: string | null,
): ThreadView {
  const participantIds = Array.isArray(thread.participantIds) ? thread.participantIds : [];
  const otherParticipantId = participantIds.find((participantId) => participantId !== currentUserId) || participantIds[0];
  const otherParticipant = otherParticipantId ? usersById[otherParticipantId] : undefined;

  const name =
    thread.groupName ||
    otherParticipant?.fullName ||
    otherParticipant?.username ||
    (thread.threadType === 'CHANNEL' ? 'Channel' : 'Conversation');

  return {
    id: thread.id,
    name,
    avatar: undefined,
    lastMessage: thread.lastMessage || 'No messages yet',
    timestamp: thread.lastMessageAt
      ? new Date(thread.lastMessageAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : '',
    unread: Math.max(0, Number(thread.unreadCount || 0)),
    online: Boolean(otherParticipant?.online),
    thread,
  };
}

function normalizeMessages(messages: ChatMessage[]) {
  return [...messages].sort((left, right) => {
    const leftTime = left.createdAt ? Date.parse(left.createdAt) : 0;
    const rightTime = right.createdAt ? Date.parse(right.createdAt) : 0;
    return leftTime - rightTime;
  });
}

function mergeMessages(existing: ChatMessage[], incoming: ChatMessage[]) {
  const merged = new Map<string, ChatMessage>();
  for (const message of existing) {
    merged.set(message.id, message);
  }
  for (const message of incoming) {
    merged.set(message.id, message);
  }
  return normalizeMessages([...merged.values()]);
}
