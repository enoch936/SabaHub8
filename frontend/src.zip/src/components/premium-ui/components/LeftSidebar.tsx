import { useEffect, useState } from 'react';
import { 
  Home, Briefcase, Users, MessageCircle, BarChart3, Settings,
  HelpCircle, ChevronLeft, ChevronRight, Sparkles, Wallet, FileText, FileSignature
} from 'lucide-react';
import { Button } from './ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { cn } from './ui/utils';

interface LeftSidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
  messageBadge?: number;
}

const menuItems = [
  { id: 'home', icon: Home, label: 'Home' },
  { id: 'jobs', icon: Briefcase, label: 'Jobs' },
  { id: 'talent', icon: Users, label: 'Talent' },
  { id: 'messages', icon: MessageCircle, label: 'Messages' },
  { id: 'wallet', icon: Wallet, label: 'Wallet' },
  { id: 'analytics', icon: BarChart3, label: 'Analysis' },
  { id: 'proposals', icon: FileText, label: 'Proposals' },
  { id: 'contracts', icon: FileSignature, label: 'Contracts' },
  { id: 'ai-assistant', icon: Sparkles, label: 'AI Assistant', highlight: true },
];

const bottomItems = [
  { id: 'settings', icon: Settings, label: 'Settings' },
  { id: 'help', icon: HelpCircle, label: 'Help' },
];

export function LeftSidebar({ activeSection, onSectionChange, messageBadge = 0 }: LeftSidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.localStorage.getItem('left_sidebar_collapsed');
    if (stored !== null) {
      setCollapsed(stored === 'true');
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem('left_sidebar_collapsed', String(collapsed));
  }, [collapsed]);

  return (
    <TooltipProvider>
      <aside 
        className={cn(
          "border-r bg-white dark:bg-slate-900 dark:border-slate-700 transition-all duration-300 flex flex-col relative",
          collapsed ? "w-16" : "w-64"
        )}
      >
        {/* Logo */}
        <div className="p-4 border-b flex items-center justify-between">
          {!collapsed && (
            <div className="flex items-center gap-2">
              <div className="size-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <Sparkles className="size-4 text-white" />
              </div>
              <span className="text-xl">SabaHub</span>
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(!collapsed)}
            className={cn(collapsed && "mx-auto")}
          >
            {collapsed ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
          </Button>
        </div>

        {/* Main Menu */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            const badge = item.id === 'messages' ? messageBadge : undefined;
            
            const button = (
              <Button
                key={item.id}
                variant={isActive ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start relative border",
                  collapsed && "justify-center px-2",
                  isActive ? "border-primary/40 ring-2 ring-primary/25 shadow-sm" : "border-transparent",
                  item.highlight && !isActive && "bg-gradient-to-r from-blue-500/10 to-purple-500/10"
                )}
                onClick={() => onSectionChange(item.id)}
              >
                <Icon className={cn("size-5", !collapsed && "mr-3")} />
                {!collapsed && <span>{item.label}</span>}
                {badge ? !collapsed && (
                  <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-0.5">
                    {badge}
                  </span>
                ) : null}
                {badge ? collapsed && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full size-5 flex items-center justify-center">
                    {badge}
                  </span>
                ) : null}
              </Button>
            );

            if (collapsed) {
              return (
                <Tooltip key={item.id}>
                  <TooltipTrigger asChild>
                    {button}
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    {item.label}
                    {badge ? ` (${badge})` : ""}
                  </TooltipContent>
                </Tooltip>
              );
            }

            return button;
          })}
        </nav>

        {/* Bottom Menu */}
        <div className="p-3 border-t space-y-1">
          {bottomItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            const button = (
              <Button
                key={item.id}
                variant={isActive ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start border",
                  isActive ? "border-primary/40 ring-2 ring-primary/25 shadow-sm" : "border-transparent",
                  collapsed && "justify-center px-2"
                )}
                onClick={() => onSectionChange(item.id)}
              >
                <Icon className={cn("size-5", !collapsed && "mr-3")} />
                {!collapsed && <span>{item.label}</span>}
              </Button>
            );

            if (collapsed) {
              return (
                <Tooltip key={item.id}>
                  <TooltipTrigger asChild>
                    {button}
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    {item.label}
                  </TooltipContent>
                </Tooltip>
              );
            }

            return button;
          })}
        </div>
      </aside>
    </TooltipProvider>
  );
}
