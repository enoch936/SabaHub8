import type { PremiumFreelancer } from '../types';
import { Star, MapPin, Briefcase, Clock, MessageCircle, Heart, Circle, CheckCircle2, Share2 } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter, CardHeader } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { motion } from 'framer-motion';
import { cn } from './ui/utils';

interface SmartFreelancerCardProps {
  freelancer: PremiumFreelancer;
  isFavorited: boolean;
  onFavoriteToggle: (freelancerId: string) => void;
  onViewProfile: (freelancer: PremiumFreelancer) => void;
}

const availabilityColors = {
  available: 'text-green-500',
  busy: 'text-yellow-500',
  offline: 'text-gray-400'
};

export function SmartFreelancerCard({ freelancer, isFavorited, onFavoriteToggle, onViewProfile }: SmartFreelancerCardProps) {
  return (
    <motion.div
      transition={{ duration: 0.3 }}
    >
      <Card className={cn(
        "overflow-hidden group cursor-pointer relative"
      )}>
        <CardHeader className="pb-3 relative" onClick={() => onViewProfile(freelancer)}>
          <div className="flex items-start gap-4">
            <div className="relative">
              <motion.div
                transition={{ duration: 0.3 }}
              >
                <Avatar className="size-16 ring-2 ring-background">
                  <AvatarImage src={freelancer.profileImage} alt={freelancer.name} />
                  <AvatarFallback>{freelancer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
              </motion.div>
              <motion.div
                animate={{}}
                transition={{ duration: 0 }}
              >
                <Circle 
                  className={cn(
                    "absolute -bottom-1 -right-1 size-4 fill-current",
                    availabilityColors[freelancer.availability]
                  )}
                />
              </motion.div>
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg truncate">
                      {freelancer.name}
                    </h3>
                    {freelancer.verified && <CheckCircle2 className="size-4 text-blue-500 shrink-0" />}
                  </div>
                  <p className="text-sm text-muted-foreground truncate">{freelancer.title}</p>
                </div>
                <motion.div whileTap={{ scale: 0.9 }}>
                  <Button
                    variant={isFavorited ? "default" : "ghost"}
                    size="icon"
                    className={cn(
                      "size-8 shrink-0",
                      isFavorited && "bg-gradient-to-r from-pink-500 to-rose-600"
                    )}
                    onClick={(e) => {
                      e.stopPropagation();
                      onFavoriteToggle(freelancer.id);
                    }}
                  >
                    <motion.div
                      animate={{ scale: isFavorited ? [1, 1.3, 1] : 1 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Heart className={`size-4 ${isFavorited ? 'fill-current' : ''}`} />
                    </motion.div>
                  </Button>
                </motion.div>
              </div>
              
              <div className="flex items-center gap-3 mt-2 text-sm">
                <div className="flex items-center gap-1">
                  <Star className="size-4 fill-yellow-400 text-yellow-400" />
                  {freelancer.reviewCount > 0 ? (
                    <>
                      <span>{freelancer.rating.toFixed(1)}</span>
                      <span className="text-muted-foreground">({freelancer.reviewCount})</span>
                    </>
                  ) : (
                    <span className="text-muted-foreground">New</span>
                  )}
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Briefcase className="size-4" />
                  <span>{freelancer.completedJobs} jobs</span>
                </div>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent onClick={() => onViewProfile(freelancer)} className="space-y-3">
          <p className="text-sm text-muted-foreground line-clamp-2">
            {freelancer.bio}
          </p>

          {/* Gradient Skill Tags */}
          <div className="flex flex-wrap gap-1.5">
            {freelancer.skills.slice(0, 4).map((skill, index) => (
              <Badge 
                key={skill} 
                className={cn(
                  "text-xs",
                  index === 0 && "bg-gradient-to-r from-blue-500 to-cyan-500",
                  index === 1 && "bg-gradient-to-r from-purple-500 to-pink-500",
                  index === 2 && "bg-gradient-to-r from-orange-500 to-red-500",
                  index === 3 && "bg-gradient-to-r from-green-500 to-emerald-500"
                )}
              >
                {skill}
              </Badge>
            ))}
            {freelancer.skills.length > 4 && (
              <Badge variant="secondary" className="text-xs">
                +{freelancer.skills.length - 4}
              </Badge>
            )}
          </div>

          <div className="flex items-center justify-between text-sm pt-2">
            <div className="flex items-center gap-1 text-muted-foreground">
              <MapPin className="size-4" />
              <span className="truncate">{freelancer.location}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="size-4 text-green-600" />
              <span className="text-green-600">{freelancer.lastActiveLabel}</span>
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex items-center justify-between border-t pt-4">
          <div>
            <p className="text-xs text-muted-foreground">Starting at</p>
            <p className="text-lg">
              ${freelancer.hourlyRate}
              <span className="text-sm text-muted-foreground">/hr</span>
            </p>
          </div>
          
          <div className="hidden gap-1">
            <motion.div whileTap={{ scale: 0.9 }}>
              <Button 
                variant="outline" 
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                }}
              >
                <MessageCircle className="size-3 mr-1" />
                Chat
              </Button>
            </motion.div>
            <motion.div whileTap={{ scale: 0.9 }}>
              <Button 
                variant="outline" 
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                }}
              >
                <Share2 className="size-3" />
              </Button>
            </motion.div>
          </div>

          <Button 
            size="sm"
            className="bg-gradient-to-r from-purple-500 to-pink-600"
            onClick={(event) => {
              event.stopPropagation();
              onViewProfile(freelancer);
            }}
          >
            Message
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
