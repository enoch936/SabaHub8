import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Search, Bell, User, Moon, Sun, ChevronDown, LogOut, Settings, CreditCard, Sparkles, Menu } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { motion } from 'framer-motion';
import { cn } from './ui/utils';
import { useSession } from '@/lib/session';
import { workspaceRoutes } from '@/lib/workspace-routes';
import { getTimeAgo } from '../utils/helpers';

type NotificationPreview = {
  id: string;
  title: string;
  message?: string;
  createdAt?: string;
  read?: boolean;
};

interface TopNavbarProps {
  userRole: 'employer' | 'freelancer';
  onRoleChange: (role: 'employer' | 'freelancer') => void;
  darkMode: boolean;
  onDarkModeToggle: () => void;
  onMenuToggle: () => void;
  searchQuery: string;
  onSearchQueryChange: (value: string) => void;
  searchSuggestions: string[];
  notificationCount: number;
  notifications: NotificationPreview[];
  profileName: string;
  profileSubtitle: string;
  profileImageUrl?: string;
}

export function TopNavbar({
  userRole,
  onRoleChange,
  darkMode,
  onDarkModeToggle,
  onMenuToggle,
  searchQuery,
  onSearchQueryChange,
  searchSuggestions,
  notificationCount,
  notifications,
  profileName,
  profileSubtitle,
  profileImageUrl,
}: TopNavbarProps) {
  const router = useRouter();
  const clearSession = useSession((state) => state.clear);
  const [searchFocused, setSearchFocused] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const handleLogout = () => {
    clearSession();
    router.push('/login');
  };

  const profileFallback = profileName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join('') || 'SH';

  return (
    <header className="h-16 border-b bg-white dark:bg-slate-900 dark:border-slate-700 sticky top-0 z-50">
      <div className="h-full px-6 flex items-center justify-between gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={onMenuToggle}
          aria-label="Toggle sidebar"
        >
          <Menu className="size-4" />
        </Button>

        <div className="flex-1 max-w-2xl relative">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              placeholder="Search live jobs, talent, and skills"
              value={searchQuery}
              onChange={(event) => onSearchQueryChange(event.target.value)}
              onFocus={() => {
                setSearchFocused(true);
                setShowSuggestions(true);
              }}
              onBlur={() => {
                setSearchFocused(false);
                setTimeout(() => setShowSuggestions(false), 200);
              }}
              className={cn(
                "pl-10 pr-12 h-10 transition-all",
                searchFocused && "ring-2 ring-blue-500/50"
              )}
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
              <Sparkles className="size-4 text-purple-500" />
              <Badge variant="secondary" className="text-xs">Live</Badge>
            </div>
          </div>

          {showSuggestions && searchSuggestions.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute top-full mt-2 w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg p-3 space-y-2 z-50"
            >
              <p className="text-xs text-slate-600 dark:text-slate-300 px-1 flex items-center gap-1">
                <Sparkles className="size-3 text-purple-500" />
                Search Suggestions
              </p>
              {searchSuggestions.map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start text-sm h-8 text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800"
                  onMouseDown={(event) => event.preventDefault()}
                  onClick={() => {
                    onSearchQueryChange(suggestion);
                    setShowSuggestions(false);
                  }}
                >
                  <Search className="size-3 mr-2 text-slate-500 dark:text-slate-300" />
                  {suggestion}
                </Button>
              ))}
            </motion.div>
          )}
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-3 px-4 py-2 bg-muted/50 rounded-lg">
            <motion.button
              onClick={() => onRoleChange('freelancer')}
              className={cn(
                "px-3 py-1.5 rounded-md text-sm transition-colors relative",
                userRole === 'freelancer' && "bg-background shadow-sm"
              )}
              whileTap={{ scale: 0.95 }}
            >
              Freelancer
              {userRole === 'freelancer' && (
                <motion.div
                  layoutId="roleIndicator"
                  className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-md"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
            </motion.button>

            <div className="relative">
              <motion.div
                animate={{ x: userRole === 'employer' ? 0 : -24 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="w-8 h-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full"
              />
            </div>

            <motion.button
              onClick={() => onRoleChange('employer')}
              className={cn(
                "px-3 py-1.5 rounded-md text-sm transition-colors relative",
                userRole === 'employer' && "bg-background shadow-sm"
              )}
              whileTap={{ scale: 0.95 }}
            >
              Employer
              {userRole === 'employer' && (
                <motion.div
                  layoutId="roleIndicator"
                  className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-md"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
            </motion.button>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={onDarkModeToggle}
            className="relative overflow-hidden"
          >
            <motion.div
              animate={{ rotate: darkMode ? 180 : 0 }}
              transition={{ duration: 0.3 }}
            >
              {darkMode ? <Moon className="size-4" /> : <Sun className="size-4" />}
            </motion.div>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" className="relative">
                <Bell className="size-4" />
                {notificationCount > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1 -right-1 min-w-5 h-5 px-1 bg-red-500 text-white text-xs rounded-full flex items-center justify-center"
                  >
                    {notificationCount > 9 ? '9+' : notificationCount}
                  </motion.div>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="space-y-2 p-2">
                {notifications.length > 0 ? (
                  notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={cn(
                        "p-3 rounded-lg border",
                        notification.read
                          ? "bg-slate-50 border-slate-200"
                          : "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800"
                      )}
                    >
                      <p className="text-sm font-medium">{notification.title}</p>
                      {notification.message && (
                        <p className="text-xs text-muted-foreground mt-1">{notification.message}</p>
                      )}
                      {notification.createdAt && (
                        <p className="text-xs text-muted-foreground mt-2">{getTimeAgo(notification.createdAt)}</p>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="rounded-lg border border-dashed border-slate-200 p-4 text-sm text-slate-500">
                    No notifications yet.
                  </div>
                )}
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="gap-2 pl-2">
                <Avatar className="size-8">
                  <AvatarImage src={profileImageUrl} />
                  <AvatarFallback>{profileFallback}</AvatarFallback>
                </Avatar>
                <div className="text-left hidden md:block">
                  <p className="text-sm">{profileName}</p>
                  <p className="text-xs text-muted-foreground">{profileSubtitle}</p>
                </div>
                <ChevronDown className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => router.push(workspaceRoutes.settings)}>
                <User className="size-4 mr-2" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push(workspaceRoutes.wallet)}>
                <CreditCard className="size-4 mr-2" />
                Billing
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push(workspaceRoutes.settings)}>
                <Settings className="size-4 mr-2" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600" onClick={handleLogout}>
                <LogOut className="size-4 mr-2" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
