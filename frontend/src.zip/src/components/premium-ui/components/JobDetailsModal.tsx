"use client";

import { useRouter } from 'next/navigation';
import { Star, MapPin, Clock, DollarSign, User, Bookmark } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Separator } from './ui/separator';
import { Avatar, AvatarFallback } from './ui/avatar';
import { toast } from 'sonner';
import { createThread } from '@/lib/api';
import { isTokenUsable } from '@/lib/auth';
import { workspaceRoutes } from '@/lib/workspace-routes';
import type { PremiumJob } from '../types';

interface JobDetailsModalProps {
  job: PremiumJob | null;
  isOpen: boolean;
  onClose: () => void;
  isBookmarked: boolean;
  onBookmarkToggle: (jobId: string) => void;
}

export function JobDetailsModal({ job, isOpen, onClose, isBookmarked, onBookmarkToggle }: JobDetailsModalProps) {
  const router = useRouter();

  if (!job) return null;

  const handleApplyNow = () => {
    router.push(workspaceRoutes.manageJobDetail(job.id));
    onClose();
  };

  const handleContactClient = async () => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null;
    if (!isTokenUsable(token)) {
      router.push('/login');
      return;
    }

    if (!job.employerId) {
      toast.error('This client has not enabled direct messaging yet.');
      return;
    }

    try {
      await createThread({ participantIds: [job.employerId] });
      toast.success(`Conversation opened with ${job.postedBy}`);
      router.push('/chat');
      onClose();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Unable to open chat right now.');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-white text-slate-900 border border-slate-200 p-7 md:p-8">
        <DialogHeader>
          <div className="flex items-start justify-between gap-4">
            <DialogTitle className="text-2xl md:text-3xl font-semibold leading-tight pr-8">{job.title}</DialogTitle>
            <Button
              variant={isBookmarked ? "default" : "outline"}
              size="icon"
              onClick={() => onBookmarkToggle(job.id)}
            >
              <Bookmark className={`size-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-8">
          <div className="relative h-64 rounded-lg overflow-hidden">
            <img 
              src={job.image} 
              alt={job.title}
              className="w-full h-full object-cover"
            />
            <Badge className="absolute top-3 left-3 bg-white text-slate-900 border border-slate-200 shadow-sm">
              {job.category}
            </Badge>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
              <DollarSign className="size-5 text-green-600" />
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Budget</p>
                <p className="text-slate-900 font-medium">
                  {job.budget > 0 ? `$${job.budget.toLocaleString()}` : 'Budget TBD'}
                  <span className="text-xs text-slate-500">
                    {job.budgetType === 'hourly' ? '/hr' : ''}
                  </span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
              <Clock className="size-5 text-blue-600" />
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Duration</p>
                <p className="text-slate-900 font-medium">{job.duration}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
              <MapPin className="size-5 text-red-600" />
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Location</p>
                <p className="text-slate-900 font-medium">{job.location}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
              <Star className="size-5 text-yellow-500 fill-yellow-500" />
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Rating</p>
                <p className="text-slate-900 font-medium">
                  {job.reviewCount > 0 ? `${job.rating.toFixed(1)} (${job.reviewCount})` : 'No reviews yet'}
                </p>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="mb-2 text-lg font-semibold text-slate-900">Project Description</h3>
            <p className="text-slate-700 text-base leading-7">{job.description}</p>
          </div>

          <div>
            <h3 className="mb-3 text-lg font-semibold text-slate-900">Skills Required</h3>
            <div className="flex flex-wrap gap-2">
              {job.skillsRequired.map((skill) => (
                <Badge key={skill} variant="secondary" className="bg-slate-100 text-slate-800 border border-slate-200">
                  {skill}
                </Badge>
              ))}
              {job.skillsRequired.length === 0 && (
                <Badge variant="secondary" className="bg-slate-100 text-slate-800 border border-slate-200">
                  Scope discussion required
                </Badge>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 bg-white border border-slate-200 rounded-lg">
            <User className="size-5" />
            <div>
              <p className="text-sm text-slate-500">Posted by</p>
              <p className="text-slate-900 font-medium">{job.postedBy}</p>
            </div>
            <div className="ml-auto">
              <p className="text-sm text-slate-500">Posted</p>
              <p className="text-sm text-slate-900 font-medium">{new Date(job.postedDate).toLocaleDateString()}</p>
            </div>
          </div>

          <div>
            <h3 className="mb-2 text-lg font-semibold text-slate-900">Experience Level</h3>
            <Badge variant="outline" className="capitalize text-slate-800 border-slate-300">
              {job.experienceLevel}
            </Badge>
          </div>

          <Separator />

          <div>
            <h3 className="mb-4 text-lg font-semibold text-slate-900">Client Reviews</h3>
            {job.reviews.length > 0 ? (
              <div className="space-y-4">
                {job.reviews.map((review) => (
                  <div key={review.id} className="flex gap-3 p-4 bg-white border border-slate-200 rounded-lg">
                    <Avatar>
                      <AvatarFallback>{review.author[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-slate-900">{review.author}</p>
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, index) => (
                            <Star 
                              key={index}
                              className={`size-3 ${
                                index < review.rating 
                                  ? 'fill-yellow-400 text-yellow-400' 
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-xs text-muted-foreground ml-auto">
                          {new Date(review.date).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-sm leading-6 text-slate-700">{review.comment}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 px-4 py-6 text-sm text-slate-600">
                No published client reviews are attached to this opportunity yet.
              </div>
            )}
          </div>

          <div className="flex gap-3 pt-4 sticky bottom-0 bg-white border-t border-slate-200">
            <Button className="flex-1" size="lg" onClick={handleApplyNow}>
              Apply Now
            </Button>
            <Button variant="outline" size="lg" onClick={handleContactClient}>
              Contact Client
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
