import { useState } from 'react';
import { ChevronDown, MessageSquareQuote, ShieldCheck, Smile, Star } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { mockJobs } from '../data/mockJobs';

const sentimentMap = {
  positive: { label: 'Positive', color: 'text-emerald-600', value: 82 },
  neutral: { label: 'Neutral', color: 'text-amber-600', value: 13 },
  negative: { label: 'Negative', color: 'text-rose-600', value: 5 },
};

export function ReviewsReputationPanel() {
  const reviews = mockJobs.flatMap((job) =>
    job.reviews.map((review) => ({
      ...review,
      jobTitle: job.title,
      sentiment: review.rating >= 4.5 ? 'positive' : review.rating >= 3.5 ? 'neutral' : 'negative',
    })),
  );

  const [expandedReviewIds, setExpandedReviewIds] = useState<string[]>([]);

  const toggleReview = (id: string) => {
    setExpandedReviewIds((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
  };

  return (
    <div className="space-y-6">
      <Card className="border-slate-200 bg-white">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Star className="size-4 text-yellow-500 fill-yellow-500" />
            Reviews & Reputation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-lg border p-3">
              <p className="text-xs text-muted-foreground">Average Rating</p>
              <p className="text-2xl text-slate-900">4.8</p>
            </div>
            <div className="rounded-lg border p-3">
              <p className="text-xs text-muted-foreground">Verified Reviews</p>
              <p className="text-2xl text-blue-600">96%</p>
            </div>
            <div className="rounded-lg border p-3">
              <p className="text-xs text-muted-foreground">Response Satisfaction</p>
              <p className="text-2xl text-emerald-600">91%</p>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-sm flex items-center gap-2">
              <Smile className="size-4 text-blue-600" />
              Sentiment Indicator
            </p>
            {Object.entries(sentimentMap).map(([key, value]) => (
              <div key={key} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className={value.color}>{value.label}</span>
                  <span>{value.value}%</span>
                </div>
                <Progress value={value.value} className="h-1.5" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-200 bg-white">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <MessageSquareQuote className="size-4 text-purple-600" />
            Review Feed
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {reviews.slice(0, 6).map((review) => {
            const isExpanded = expandedReviewIds.includes(review.id);
            return (
              <div key={review.id} className="rounded-xl border p-3">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm">{review.author}</p>
                    <Badge variant="outline" className="gap-1">
                      <ShieldCheck className="size-3" />
                      Verified
                    </Badge>
                  </div>
                  <div className="flex items-center gap-1 text-yellow-500">
                    <Star className="size-3 fill-current" />
                    <span className="text-xs text-slate-700">{review.rating.toFixed(1)}</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mb-2">{review.jobTitle}</p>
                <p className="text-sm text-slate-700">
                  {isExpanded ? review.comment : `${review.comment.slice(0, 80)}${review.comment.length > 80 ? '...' : ''}`}
                </p>
                <div className="mt-2 flex items-center justify-between">
                  <Badge variant="secondary">{sentimentMap[review.sentiment as keyof typeof sentimentMap].label}</Badge>
                  <Button variant="ghost" size="sm" className="h-7 gap-1" onClick={() => toggleReview(review.id)}>
                    {isExpanded ? 'Less' : 'More'}
                    <ChevronDown className={`size-3 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                  </Button>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
