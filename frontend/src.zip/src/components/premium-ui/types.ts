export interface PremiumJobReview {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
  avatar?: string;
}

export interface PremiumJob {
  id: string;
  employerId?: string;
  title: string;
  description: string;
  category: string;
  budget: number;
  budgetType: "fixed" | "hourly";
  currency?: string;
  duration: string;
  skillsRequired: string[];
  image: string;
  postedBy: string;
  postedDate: string;
  rating: number;
  reviewCount: number;
  reviews: PremiumJobReview[];
  experienceLevel: "entry" | "intermediate" | "expert";
  location: string;
  employerRating: number;
  applicants?: number;
  trending?: boolean;
}

export interface PremiumFreelancer {
  id: string;
  userId?: string;
  name: string;
  title: string;
  bio: string;
  profileImage: string;
  skills: string[];
  hourlyRate: number;
  rating: number;
  reviewCount: number;
  completedJobs: number;
  availability: "available" | "busy" | "offline";
  location: string;
  languages: string[];
  certifications: string[];
  lastActiveLabel: string;
  verified?: boolean;
}
