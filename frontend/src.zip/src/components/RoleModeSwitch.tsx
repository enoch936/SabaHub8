"use client";

import type { ReactNode } from "react";
import { useMemo } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Box, ButtonBase, Stack, Typography } from "@mui/material";
import { alpha, useTheme } from "@mui/material/styles";
import BusinessCenterRoundedIcon from "@mui/icons-material/BusinessCenterRounded";
import TrackChangesRoundedIcon from "@mui/icons-material/TrackChangesRounded";
import { useSession } from "@/lib/session";
import {
  getRoleFallbackRoute,
  getWorkspaceRoles,
  isRoleAllowedOnPath,
  type WorkspaceRole,
} from "@/lib/role-mode";

const ROLE_META: Record<WorkspaceRole, { label: string; icon: ReactNode }> = {
  EMPLOYER: { label: "Employer", icon: <BusinessCenterRoundedIcon fontSize="small" /> },
  FREELANCER: { label: "Freelancer", icon: <TrackChangesRoundedIcon fontSize="small" /> },
};

export default function RoleModeSwitch({ variant = "pill" }: { variant?: "pill" | "button" }) {
  const router = useRouter();
  const pathname = usePathname();
  const theme = useTheme();
  const role = useSession((state) => state.role);
  const roles = useSession((state) => state.roles);
  const setRole = useSession((state) => state.setRole);

  const availableRoles = useMemo(
    () => getWorkspaceRoles((roles as Array<"ADMIN" | WorkspaceRole> | undefined) ?? []),
    [roles]
  );

  if (!availableRoles.length || role === "ADMIN") {
    return null;
  }

  const activeRole = role === "EMPLOYER" || role === "FREELANCER" ? role : availableRoles[0];

  const switchToRole = (nextRole: WorkspaceRole) => {
    if (!availableRoles.includes(nextRole) || nextRole === activeRole) return;
    setRole(nextRole);
    const nextRoute = getRoleFallbackRoute(nextRole);
    if (!isRoleAllowedOnPath(pathname, nextRole) || pathname !== nextRoute) {
      router.push(nextRoute);
    }
  };

  if (variant === "button") {
    const nextRole = activeRole === "EMPLOYER" ? "FREELANCER" : "EMPLOYER";

    return (
      <ButtonBase
        onClick={() => switchToRole(nextRole)}
        sx={{
          px: 2,
          py: 1,
          borderRadius: 2,
          border: "1px solid transparent",
          bgcolor: theme.palette.mode === "light" ? "#eef2ff" : alpha(theme.palette.secondary.main, 0.35),
          color: "text.primary",
          transition: "background-color 180ms ease",
          "&:hover": {
            bgcolor: theme.palette.mode === "light" ? "#e4e9ff" : alpha(theme.palette.secondary.main, 0.5),
          },
        }}
      >
        <Stack direction="row" spacing={0.85} alignItems="center">
          <Typography variant="caption" fontWeight={700} sx={{ letterSpacing: "0.01em" }}>
            Switch to {nextRole === "EMPLOYER" ? "Employer" : "Freelancer"}
          </Typography>
        </Stack>
      </ButtonBase>
    );
  }

  return (
    <Box
      sx={{
        display: "inline-flex",
        alignItems: "center",
        gap: 0.5,
        p: 0.5,
        borderRadius: 999,
        border: `1px solid ${alpha(theme.palette.divider, 0.9)}`,
        bgcolor: alpha(theme.palette.background.paper, theme.palette.mode === "light" ? 0.74 : 0.52),
        transition: "all 220ms cubic-bezier(0.22, 1, 0.36, 1)",
      }}
    >
      {(["EMPLOYER", "FREELANCER"] as WorkspaceRole[]).map((item) => {
        const enabled = availableRoles.includes(item);
        const active = activeRole === item;
        const meta = ROLE_META[item];

        return (
          <ButtonBase
            key={item}
            disabled={!enabled}
            onClick={() => switchToRole(item)}
            sx={{
              px: 1.15,
              py: 0.8,
              borderRadius: 999,
              minWidth: { xs: 116, sm: 132 },
              color: active ? "primary.main" : "text.secondary",
              bgcolor: active ? alpha(theme.palette.primary.main, theme.palette.mode === "light" ? 0.12 : 0.24) : "transparent",
              border: active ? `1px solid ${alpha(theme.palette.primary.main, 0.34)}` : "1px solid transparent",
              transform: active ? "translateY(-1px)" : "none",
              transition: "all 220ms cubic-bezier(0.22, 1, 0.36, 1)",
              opacity: enabled ? 1 : 0.45,
              "&:hover": {
                bgcolor: active
                  ? alpha(theme.palette.primary.main, theme.palette.mode === "light" ? 0.16 : 0.3)
                  : alpha(theme.palette.primary.main, theme.palette.mode === "light" ? 0.06 : 0.12),
              },
            }}
          >
            <Stack direction="row" spacing={0.75} alignItems="center" justifyContent="center">
              {meta.icon}
              <Typography variant="caption" fontWeight={800} sx={{ letterSpacing: "0.02em" }}>
                {meta.label}
              </Typography>
            </Stack>
          </ButtonBase>
        );
      })}
    </Box>
  );
}
