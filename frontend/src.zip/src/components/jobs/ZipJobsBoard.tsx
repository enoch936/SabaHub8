"use client";

import { useMemo, useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Chip,
  Collapse,
  FormControl,
  Grid,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import BookmarkBorderRoundedIcon from "@mui/icons-material/BookmarkBorderRounded";
import BookmarkRoundedIcon from "@mui/icons-material/BookmarkRounded";
import WorkOutlineRoundedIcon from "@mui/icons-material/WorkOutlineRounded";
import ChatBubbleOutlineRoundedIcon from "@mui/icons-material/ChatBubbleOutlineRounded";
import ExpandLessRoundedIcon from "@mui/icons-material/ExpandLessRounded";
import ExpandMoreRoundedIcon from "@mui/icons-material/ExpandMoreRounded";
import PlaceOutlinedIcon from "@mui/icons-material/PlaceOutlined";
import ScheduleRoundedIcon from "@mui/icons-material/ScheduleRounded";
import StarRoundedIcon from "@mui/icons-material/StarRounded";
import TuneRoundedIcon from "@mui/icons-material/TuneRounded";

export type ZipJobItem = {
  id: string;
  title: string;
  budget: string;
  duration: string;
  description: string;
  skills: string[];
  postedTime: string;
  location: string;
  category: string;
  experienceLevel: string;
  employerName: string;
  employerRating: number;
  employerAvatar: string;
  coverImage: string;
};

type ZipJobsBoardProps = {
  title: string;
  subtitle: string;
  jobs: ZipJobItem[];
  loading?: boolean;
  onApply?: (job: ZipJobItem) => void;
  onContact?: (job: ZipJobItem) => void;
  onLoadMore?: () => void;
  showPostButton?: boolean;
  onPostJob?: () => void;
  primaryActionLabel?: string;
  secondaryActionLabel?: string;
  loadMoreLabel?: string;
};

const locationOptions = ["Remote", "On-site", "Hybrid"];

export default function ZipJobsBoard({
  title,
  subtitle,
  jobs,
  loading = false,
  onApply,
  onContact,
  onLoadMore,
  showPostButton = false,
  onPostJob,
  primaryActionLabel = "Apply Now",
  secondaryActionLabel = "Contact",
  loadMoreLabel = "Load More Jobs",
}: ZipJobsBoardProps) {
  const [savedJobs, setSavedJobs] = useState<string[]>([]);
  const [filtersExpanded, setFiltersExpanded] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [experience, setExperience] = useState("");
  const [location, setLocation] = useState("");
  const [budgetMin, setBudgetMin] = useState("");
  const [budgetMax, setBudgetMax] = useState("");

  const categories = useMemo(() => Array.from(new Set(jobs.map((job) => job.category))).sort(), [jobs]);
  const experienceLevels = useMemo(() => Array.from(new Set(jobs.map((job) => job.experienceLevel))).sort(), [jobs]);

  const filteredJobs = useMemo(() => {
    const q = search.trim().toLowerCase();

    return jobs.filter((job) => {
      if (category && job.category !== category) return false;
      if (experience && job.experienceLevel !== experience) return false;
      if (location && job.location !== location) return false;

      if (q) {
        const haystack = `${job.title} ${job.description} ${job.skills.join(" ")}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }

      const budgetNums = job.budget.match(/\d+[\d,]*/g)?.map((value) => Number(value.replace(/,/g, ""))) ?? [];
      const minBudget = budgetNums[0] ?? 0;
      const maxBudget = budgetNums[1] ?? minBudget;

      if (budgetMin && minBudget < Number(budgetMin)) return false;
      if (budgetMax && maxBudget > Number(budgetMax)) return false;

      return true;
    });
  }, [budgetMax, budgetMin, category, experience, jobs, location, search]);

  const toggleSave = (id: string) => {
    setSavedJobs((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
  };

  const resetFilters = () => {
    setSearch("");
    setCategory("");
    setExperience("");
    setLocation("");
    setBudgetMin("");
    setBudgetMax("");
  };

  return (
    <Box sx={{ display: "grid", gap: 2, pb: 2 }}>
      <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" spacing={1}>
        <Box>
          <Typography variant="h4" fontWeight={800}>
            {title}
          </Typography>
          <Typography color="text.secondary">{subtitle}</Typography>
        </Box>
        {showPostButton ? (
          <Button
            variant="contained"
            onClick={onPostJob}
            sx={{
              alignSelf: { xs: "stretch", md: "center" },
              transition: "transform 180ms ease, box-shadow 180ms ease",
              "&:hover": {
                transform: "translateY(-1px)",
                boxShadow: "0 10px 20px rgba(37, 99, 235, 0.25)",
              },
            }}
          >
            Post Job
          </Button>
        ) : null}
      </Stack>

      <Box
        sx={{
          border: "1px solid",
          borderColor: "divider",
          borderRadius: 3,
          overflow: "hidden",
          bgcolor: "background.paper",
          transition: "box-shadow 180ms ease, border-color 180ms ease",
          "&:hover": {
            borderColor: "primary.light",
            boxShadow: "0 8px 18px rgba(15, 23, 42, 0.08)",
          },
        }}
      >
        <Button
          onClick={() => setFiltersExpanded((prev) => !prev)}
          fullWidth
          sx={{
            justifyContent: "space-between",
            px: 2,
            py: 1.5,
            textTransform: "none",
            borderRadius: 0,
            transition: "background-color 160ms ease",
            "&:hover": { bgcolor: "action.hover" },
          }}
        >
          <Stack direction="row" spacing={1} alignItems="center">
            <TuneRoundedIcon fontSize="small" />
            <Typography fontWeight={700}>Filters</Typography>
          </Stack>
          {filtersExpanded ? <ExpandLessRoundedIcon /> : <ExpandMoreRoundedIcon />}
        </Button>

        <Collapse in={filtersExpanded}>
          <Box sx={{ p: 2, borderTop: "1px solid", borderColor: "divider" }}>
            <Grid container spacing={1.5}>
              <Grid size={{ xs: 12, md: 6, lg: 3 }}>
                <TextField label="Search" value={search} onChange={(e) => setSearch(e.target.value)} fullWidth size="small" />
              </Grid>
              <Grid size={{ xs: 12, md: 6, lg: 3 }}>
                <FormControl fullWidth size="small">
                  <InputLabel>Category</InputLabel>
                  <Select label="Category" value={category} onChange={(e) => setCategory(String(e.target.value))}>
                    <MenuItem value="">All Categories</MenuItem>
                    {categories.map((value) => (
                      <MenuItem key={value} value={value}>
                        {value}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid size={{ xs: 12, md: 6, lg: 2 }}>
                <FormControl fullWidth size="small">
                  <InputLabel>Experience</InputLabel>
                  <Select label="Experience" value={experience} onChange={(e) => setExperience(String(e.target.value))}>
                    <MenuItem value="">All Levels</MenuItem>
                    {experienceLevels.map((value) => (
                      <MenuItem key={value} value={value}>
                        {value}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid size={{ xs: 12, md: 6, lg: 2 }}>
                <FormControl fullWidth size="small">
                  <InputLabel>Location</InputLabel>
                  <Select label="Location" value={location} onChange={(e) => setLocation(String(e.target.value))}>
                    <MenuItem value="">All</MenuItem>
                    {locationOptions.map((value) => (
                      <MenuItem key={value} value={value}>
                        {value}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid size={{ xs: 6, md: 3, lg: 1 }}>
                <TextField label="Min" value={budgetMin} onChange={(e) => setBudgetMin(e.target.value)} fullWidth size="small" />
              </Grid>
              <Grid size={{ xs: 6, md: 3, lg: 1 }}>
                <TextField label="Max" value={budgetMax} onChange={(e) => setBudgetMax(e.target.value)} fullWidth size="small" />
              </Grid>
            </Grid>

            <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
              <Button variant="outlined" onClick={resetFilters}>
                Reset Filters
              </Button>
              <Button variant="contained">Apply Filters</Button>
            </Stack>
          </Box>
        </Collapse>
      </Box>

      <Stack direction="row" spacing={1} alignItems="center" color="text.secondary">
        <WorkOutlineRoundedIcon fontSize="small" />
        <Typography variant="body2">{loading ? "Loading jobs..." : `${filteredJobs.length} jobs available`}</Typography>
      </Stack>

      <Stack spacing={1.5}>
        {filteredJobs.map((job) => {
          const saved = savedJobs.includes(job.id);
          return (
            <Box
              key={job.id}
              sx={{
                border: "1px solid",
                borderColor: "divider",
                borderRadius: 3,
                p: 1.5,
                bgcolor: "background.paper",
                transition: "transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease",
                "&:hover": {
                  transform: "translateY(-2px)",
                  borderColor: "primary.light",
                  boxShadow: "0 16px 28px rgba(15, 23, 42, 0.12)",
                },
                "&:hover .zip-job-cover": {
                  transform: "scale(1.03)",
                },
              }}
            >
              <Grid container spacing={1.5}>
                <Grid size={{ xs: 12, md: 4 }}>
                  <Box
                    component="img"
                    src={job.coverImage}
                    alt={job.title}
                    className="zip-job-cover"
                    sx={{
                      width: "100%",
                      height: { xs: 180, md: "100%" },
                      minHeight: 180,
                      objectFit: "cover",
                      borderRadius: 2,
                      transition: "transform 220ms ease",
                    }}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 8 }}>
                  <Stack spacing={1.1}>
                    <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={1}>
                      <Stack direction="row" spacing={1} sx={{ minWidth: 0 }}>
                        <Avatar src={job.employerAvatar} alt={job.employerName} />
                        <Box sx={{ minWidth: 0 }}>
                          <Typography variant="h6" fontWeight={800} sx={{ lineHeight: 1.15 }}>
                            {job.title}
                          </Typography>
                          <Stack direction="row" spacing={1} alignItems="center" color="text.secondary">
                            <Typography variant="body2" fontWeight={600}>
                              {job.employerName}
                            </Typography>
                            <Stack direction="row" spacing={0.35} alignItems="center">
                              <StarRoundedIcon sx={{ fontSize: 17, color: "#f59e0b" }} />
                              <Typography variant="body2">{job.employerRating.toFixed(1)}</Typography>
                            </Stack>
                          </Stack>
                        </Box>
                      </Stack>
                      <IconButton
                        onClick={() => toggleSave(job.id)}
                        color={saved ? "primary" : "default"}
                        sx={{
                          transition: "transform 140ms ease, background-color 140ms ease",
                          "&:hover": { transform: "scale(1.06)", bgcolor: "action.hover" },
                        }}
                      >
                        {saved ? <BookmarkRoundedIcon /> : <BookmarkBorderRoundedIcon />}
                      </IconButton>
                    </Stack>

                    <Typography color="text.secondary" sx={{ display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                      {job.description}
                    </Typography>

                    <Stack direction="row" spacing={1.2} flexWrap="wrap" useFlexGap color="text.secondary">
                      <Typography variant="body2" fontWeight={700}>
                        {job.budget}
                      </Typography>
                      <Stack direction="row" spacing={0.5} alignItems="center">
                        <ScheduleRoundedIcon sx={{ fontSize: 16 }} />
                        <Typography variant="body2">{job.duration}</Typography>
                      </Stack>
                      <Stack direction="row" spacing={0.5} alignItems="center">
                        <PlaceOutlinedIcon sx={{ fontSize: 16 }} />
                        <Typography variant="body2">{job.location}</Typography>
                      </Stack>
                    </Stack>

                    <Stack direction="row" spacing={0.75} flexWrap="wrap" useFlexGap>
                      {job.skills.map((skill) => (
                        <Chip key={`${job.id}-${skill}`} size="small" label={skill} color="info" variant="outlined" />
                      ))}
                    </Stack>

                    <Stack direction={{ xs: "column", sm: "row" }} justifyContent="space-between" spacing={1} sx={{ borderTop: "1px solid", borderColor: "divider", pt: 1 }}>
                      <Typography variant="caption" color="text.secondary">
                        Posted {job.postedTime}
                      </Typography>
                      <Stack direction="row" spacing={1}>
                        <Button
                          size="small"
                          variant="outlined"
                          startIcon={<ChatBubbleOutlineRoundedIcon />}
                          onClick={() => onContact?.(job)}
                          sx={{
                            transition: "transform 140ms ease",
                            "&:hover": { transform: "translateY(-1px)" },
                          }}
                        >
                          {secondaryActionLabel}
                        </Button>
                        <Button
                          size="small"
                          variant="contained"
                          onClick={() => onApply?.(job)}
                          sx={{
                            transition: "transform 140ms ease, box-shadow 140ms ease",
                            "&:hover": {
                              transform: "translateY(-1px)",
                              boxShadow: "0 8px 16px rgba(37, 99, 235, 0.28)",
                            },
                          }}
                        >
                          {primaryActionLabel}
                        </Button>
                      </Stack>
                    </Stack>
                  </Stack>
                </Grid>
              </Grid>
            </Box>
          );
        })}
      </Stack>

      {onLoadMore ? (
        <Box sx={{ display: "grid", placeItems: "center", pt: 1 }}>
          <Button
            variant="outlined"
            onClick={onLoadMore}
            sx={{
              transition: "transform 140ms ease, background-color 140ms ease",
              "&:hover": { transform: "translateY(-1px)", bgcolor: "action.hover" },
            }}
          >
            {loadMoreLabel}
          </Button>
        </Box>
      ) : null}
    </Box>
  );
}
