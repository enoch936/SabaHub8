import { type ZipJobItem } from "@/components/jobs/ZipJobsBoard";

export type RawJobCardSource = {
  id: string;
  title?: string;
  description?: string;
  deliverableType?: string;
  budgetMin?: number;
  budgetMax?: number;
  currency?: string;
  slaDeliveryDays?: number;
  minYearsExperience?: number;
  requiredSkills?: string[];
  createdAt?: string;
  sampleImageUrls?: string[];
};

type MapOptions = {
  fallbackCover: string;
  fallbackAvatar: string;
  employerName?: string;
  employerRating?: number;
  location?: string;
  category?: string;
};

export function formatPosted(createdAt?: string) {
  if (!createdAt) return "recently";
  const t = new Date(createdAt).getTime();
  if (Number.isNaN(t)) return "recently";
  const hours = Math.floor((Date.now() - t) / 3_600_000);
  if (hours < 1) return "just now";
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export function mapToZipJobCard(job: RawJobCardSource, options: MapOptions): ZipJobItem {
  return {
    id: job.id,
    title: job.title || "Untitled job",
    budget:
      typeof job.budgetMin === "number" || typeof job.budgetMax === "number"
        ? `$${(job.budgetMin || 0).toLocaleString()} - $${(job.budgetMax || 0).toLocaleString()} ${job.currency || "USD"}`
        : "Budget not specified",
    duration: job.slaDeliveryDays ? `${job.slaDeliveryDays} days` : "Flexible",
    description: job.description || "No description provided.",
    skills: job.requiredSkills || [],
    postedTime: formatPosted(job.createdAt),
    location: options.location || "Remote",
    category: options.category || job.deliverableType || "General",
    experienceLevel: `${job.minYearsExperience || 0}+ years`,
    employerName: options.employerName || "Marketplace Employer",
    employerRating: options.employerRating ?? 4.8,
    employerAvatar: options.fallbackAvatar,
    coverImage: job.sampleImageUrls?.[0] || options.fallbackCover,
  };
}
