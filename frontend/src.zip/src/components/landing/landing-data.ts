import type { LucideIcon } from "lucide-react";
import {
  Award,
  BadgeCheck,
  BriefcaseBusiness,
  Building2,
  DollarSign,
  FolderKanban,
  Globe,
  MessageSquareText,
  SearchCheck,
  Search,
  Shield,
  Target,
  TrendingUp,
  Users,
  WalletCards,
  Zap,
} from "lucide-react";

export type LandingIconItem = {
  icon: LucideIcon;
  title: string;
  description: string;
  gradientFrom: string;
  gradientTo: string;
};

export const NAV_ITEMS = [
  { href: "#categories", label: "Find Talent" },
  { href: "#marketplace", label: "Marketplace" },
  { href: "#paths", label: "How It Works" },
  { href: "#enterprise", label: "Enterprise" },
  { href: "#stories", label: "Success Stories" },
] as const;

export const HERO_STATS = [
  { label: "Active Freelancers", value: "500K+" },
  { label: "Jobs Posted", value: "2M+" },
  { label: "Paid to Freelancers", value: "$5B+" },
] as const;

export const HERO_AUDIENCES = {
  employer: {
    label: "Employer",
    icon: BriefcaseBusiness,
    description:
      "Post jobs, review serious applicants, and manage contracts and payments from one polished hiring flow.",
    primaryLabel: "Post a Job",
    primaryHref: "/register",
    secondaryLabel: "See Hiring Flow",
    secondaryHref: "#paths",
    highlights: ["Verified profiles", "Fast proposals", "Milestone payouts"],
    floatingLabel: "Top match ready",
    floatingValue: "Senior Frontend Engineer",
    floatingMeta: "14 proposals in the first hour",
    image:
      "https://images.unsplash.com/photo-1759884247160-27b8465544b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGFydHVwJTIwdGVhbSUyMGJyYWluc3Rvcm1pbmd8ZW58MXx8fHwxNzc0NzYwOTQ5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    imageAlt: "Hiring team reviewing freelancer candidates",
  },
  freelancer: {
    label: "Freelancer",
    icon: Target,
    description:
      "Find real jobs, showcase your gigs, and grow your career with stronger visibility, trust, and payout protection.",
    primaryLabel: "Find Work",
    primaryHref: "/jobs",
    secondaryLabel: "Create My Profile",
    secondaryHref: "/register",
    highlights: ["Portfolio first", "Trusted clients", "Protected earnings"],
    floatingLabel: "New job matched",
    floatingValue: "Mobile App Designer",
    floatingMeta: "$4,500 budget • 2 days old",
    image:
      "https://images.unsplash.com/photo-1743796055672-438d6aa0b05e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVlbGFuY2VyJTIwd29ya2luZyUyMGxhcHRvcCUyMGNvZmZlZXxlbnwxfHx8fDE3NzQ4MDg4ODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    imageAlt: "Freelancer working remotely with a laptop",
  },
} as const;

export const TRUST_POINTS = [
  {
    icon: SearchCheck,
    title: "Clear discovery",
    description: "Users instantly understand where to hire, where to work, and what happens next.",
  },
  {
    icon: MessageSquareText,
    title: "Faster decisions",
    description: "Applications, messaging, contracts, and payouts feel connected instead of fragmented.",
  },
  {
    icon: WalletCards,
    title: "Safer outcomes",
    description: "Protected payments and verified workflows help both sides trust the platform sooner.",
  },
] as const;

export const USER_PATHS = [
  {
    audience: "Employer" as const,
    icon: BriefcaseBusiness,
    title: "For employers who need talent fast",
    description:
      "Move from role definition to contract without bouncing between multiple tools or unclear freelancer profiles.",
    ctaLabel: "Start Hiring",
    ctaHref: "/register",
    steps: [
      { icon: FolderKanban, title: "Post a job", detail: "Share the budget, timeline, and skill needs in a few focused fields." },
      { icon: SearchCheck, title: "Review proposals", detail: "Compare freelancers by fit, proof of work, and response quality." },
      { icon: BadgeCheck, title: "Hire with confidence", detail: "Create contracts and release milestone payments in one flow." },
    ],
  },
  {
    audience: "Freelancer" as const,
    icon: Target,
    title: "For freelancers building steady work",
    description:
      "Discover serious clients, present your strengths clearly, and keep your gigs, applications, and earnings organized.",
    ctaLabel: "Browse Jobs",
    ctaHref: "/jobs",
    steps: [
      { icon: BadgeCheck, title: "Build your profile", detail: "Showcase your talent, portfolio, pricing, and category expertise." },
      { icon: MessageSquareText, title: "Apply with clarity", detail: "Respond to jobs with structured applications and stronger signal." },
      { icon: WalletCards, title: "Get paid securely", detail: "Track work, contracts, and payouts through protected project workflows." },
    ],
  },
] as const;

export const MARKETPLACE_JOBS = [
  {
    title: "Senior Frontend Engineer for Creator Platform",
    company: "Northstar Labs",
    budget: "$5,800 - $8,400",
    timeline: "2 to 4 weeks",
    tags: ["React", "Design systems", "Remote"],
  },
  {
    title: "Brand Designer for SaaS Product Refresh",
    company: "BrightNest",
    budget: "$3,200 - $5,900",
    timeline: "1 to 3 weeks",
    tags: ["Branding", "Figma", "Fast turnaround"],
  },
  {
    title: "Growth Marketer for PLG Funnel Optimization",
    company: "LaunchGrid",
    budget: "$2,900 - $4,300",
    timeline: "Ongoing",
    tags: ["SEO", "Content", "Analytics"],
  },
] as const;

export const MARKETPLACE_TALENT = [
  {
    name: "Maya Solomon",
    role: "Product Designer",
    rate: "$55/hr",
    success: "98% success",
    skills: ["UI systems", "Mobile UX", "Prototyping"],
  },
  {
    name: "Daniel Kimani",
    role: "Full-Stack Developer",
    rate: "$72/hr",
    success: "97% success",
    skills: ["Next.js", "Spring Boot", "API design"],
  },
  {
    name: "Ruth Bekele",
    role: "Content Strategist",
    rate: "$38/hr",
    success: "95% success",
    skills: ["B2B copy", "SEO", "Content operations"],
  },
] as const;

export const FEATURES: LandingIconItem[] = [
  {
    icon: Search,
    title: "Smart Matching",
    description:
      "AI-powered matching connects businesses with the right freelancers by skill, timeline, and budget fit.",
    gradientFrom: "#60a5fa",
    gradientTo: "#06b6d4",
  },
  {
    icon: Shield,
    title: "Secure Payments",
    description:
      "Escrow-backed milestones, protected releases, and fraud checks create trust for both sides of the marketplace.",
    gradientFrom: "#4ade80",
    gradientTo: "#10b981",
  },
  {
    icon: Globe,
    title: "Global Talent Pool",
    description:
      "Source specialists from more than 180 countries across design, engineering, growth, AI, and operations.",
    gradientFrom: "#c084fc",
    gradientTo: "#ec4899",
  },
  {
    icon: Award,
    title: "Verified Professionals",
    description:
      "Profiles, portfolios, ratings, and structured delivery signals help teams hire with more confidence.",
    gradientFrom: "#fbbf24",
    gradientTo: "#f97316",
  },
  {
    icon: DollarSign,
    title: "Flexible Pricing",
    description:
      "Support hourly, fixed-price, and milestone-based work with transparent budgets and clean payout visibility.",
    gradientFrom: "#fb7185",
    gradientTo: "#f43f5e",
  },
  {
    icon: Users,
    title: "Team Collaboration",
    description:
      "Messages, contracts, applications, and shared project workflows live together in one operating layer.",
    gradientFrom: "#818cf8",
    gradientTo: "#a855f7",
  },
  {
    icon: TrendingUp,
    title: "Analytics Dashboard",
    description:
      "Track hiring velocity, budget burn, completion progress, and freelancer performance from one dashboard.",
    gradientFrom: "#f472b6",
    gradientTo: "#ef4444",
  },
  {
    icon: Zap,
    title: "Instant Hiring",
    description:
      "Post jobs, review applications quickly, and move strong candidates into contracts without tool switching.",
    gradientFrom: "#22d3ee",
    gradientTo: "#3b82f6",
  },
] as const;

export const VIDEO_STORIES = [
  {
    title: "Enterprise Solutions",
    description: "Scale projects with dedicated support, priority talent matching, and clearer operating control.",
    thumbnail:
      "https://images.unsplash.com/photo-1758519290832-c7f1a5fb5c45?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB2aWRlbyUyMGNhbGwlMjBtZWV0aW5nfGVufDF8fHx8MTc3NDgwODg4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "2:34",
    videoSrc: "/footage/video/6193409-hd_1920_1080_30fps.mp4",
  },
  {
    title: "How It Works",
    description: "See the flow from posting a role to reviewing proposals, hiring, and completing work.",
    thumbnail:
      "https://images.unsplash.com/photo-1728281144091-b743062a9bf0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGRlc2lnbmVyJTIwd29ya3NwYWNlfGVufDF8fHx8MTc3NDczNTc1MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "3:12",
    videoSrc: "/footage/video/4974882-hd_1080_1920_25fps.mp4",
  },
  {
    title: "Success Stories",
    description: "Hear how teams and freelancers use SabaHub to grow revenue, flexibility, and delivery speed.",
    thumbnail:
      "https://images.unsplash.com/photo-1745847768380-2caeadbb3b71?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGhhbmRzaGFrZSUyMHBhcnRuZXJzaGlwfGVufDF8fHx8MTc3NDc1MTA1M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "4:45",
    videoSrc: "/footage/video/6517587-hd_1920_1080_30fps.mp4",
  },
  {
    title: "Platform Security",
    description: "Explore payment protection, contract tracking, and the trust systems behind the platform.",
    thumbnail:
      "https://images.unsplash.com/photo-1608306448197-e83633f1261c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXZlbG9wZXIlMjBjb2RpbmclMjBzY3JlZW58ZW58MXx8fHwxNzc0NzY2NTAzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "1:58",
    videoSrc: "/footage/video/6192984-hd_1920_1080_30fps.mp4",
  },
  {
    title: "Global Reach",
    description: "Connect with talent and clients across borders without losing delivery clarity or control.",
    thumbnail:
      "https://images.unsplash.com/photo-1759752394757-323a0adc0d62?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZW1vdGUlMjB0ZWFtJTIwY29sbGFib3JhdGlvbnxlbnwxfHx8fDE3NzQ4MDg4ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "2:20",
    videoSrc: "/footage/video/3018533-hd_1920_1080_24fps.mp4",
  },
] as const;

export const TALENT_CATEGORIES = [
  {
    name: "Development & IT",
    jobs: "245K+",
    image:
      "https://images.unsplash.com/photo-1608306448197-e83633f1261c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXZlbG9wZXIlMjBjb2RpbmclMjBzY3JlZW58ZW58MXx8fHwxNzc0NzY2NTAzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    skills: ["Web Development", "Mobile Apps", "AI/ML", "DevOps"],
  },
  {
    name: "Design & Creative",
    jobs: "189K+",
    image:
      "https://images.unsplash.com/photo-1728281144091-b743062a9bf0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGRlc2lnbmVyJTIwd29ya3NwYWNlfGVufDF8fHx8MTc3NDczNTc1MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    skills: ["Graphic Design", "UI/UX", "Video Editing", "3D Design"],
  },
  {
    name: "Sales & Marketing",
    jobs: "156K+",
    image:
      "https://images.unsplash.com/photo-1764173039056-3cc602fef942?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB3b21hbiUyMHByZXNlbnRhdGlvbnxlbnwxfHx8fDE3NzQ3NjE4MTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    skills: ["Digital Marketing", "SEO", "Content Strategy", "Social Media"],
  },
  {
    name: "Writing & Translation",
    jobs: "134K+",
    image:
      "https://images.unsplash.com/photo-1743796055672-438d6aa0b05e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVlbGFuY2VyJTIwd29ya2luZyUyMGxhcHRvcCUyMGNvZmZlZXxlbnwxfHx8fDE3NzQ4MDg4ODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    skills: ["Content Writing", "Copywriting", "Technical Writing", "Translation"],
  },
] as const;

export const SHOWCASE_STATS = [
  { value: "$5B+", label: "Paid to freelancers" },
  { value: "95%", label: "Job success rate" },
  { value: "24hrs", label: "Average hire time" },
] as const;

export const ENTERPRISE_BENEFITS = [
  {
    icon: Building2,
    title: "Dedicated Account Manager",
    description: "Personal support, strategic onboarding, and hands-on help as you scale.",
  },
  {
    icon: TrendingUp,
    title: "Priority Matching",
    description: "Get surfaced to top talent faster when your hiring window is tight.",
  },
  {
    icon: Users,
    title: "Team Management",
    description: "Coordinate hiring, approvals, and contracts across distributed teams.",
  },
  {
    icon: DollarSign,
    title: "Volume Discounts",
    description: "Lower operating costs with enterprise plans and consolidated workflows.",
  },
] as const;

export const ENTERPRISE_IMAGES = [
  "https://images.unsplash.com/photo-1759884247160-27b8465544b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGFydHVwJTIwdGVhbSUyMGJyYWluc3Rvcm1pbmd8ZW58MXx8fHwxNzc0NzYwOTQ5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  "https://images.unsplash.com/photo-1745847768380-2caeadbb3b71?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGhhbmRzaGFrZSUyMHBhcnRuZXJzaGlwfGVufDF8fHx8MTc3NDc1MTA1M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  "https://images.unsplash.com/photo-1759752394757-323a0adc0d62?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZW1vdGUlMjB0ZWFtJTIwY29sbGFib3JhdGlvbnxlbnwxfHx8fDE3NzQ4MDg4ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  "https://images.unsplash.com/photo-1758519290832-c7f1a5fb5c45?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB2aWRlbyUyMGNhbGwlMjBtZWV0aW5nfGVufDF8fHx8MTc3NDgwODg4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
] as const;

export const TESTIMONIALS = [
  {
    name: "Sarah Mitchell",
    role: "CEO, TechVenture Inc.",
    image:
      "https://images.unsplash.com/photo-1739298061707-cefee19941b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFtJTIwY29sbGFib3JhdGlvbiUyMG9mZmljZXxlbnwxfHx8fDE3NzQ3Njg1Njd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    quote:
      "SabaHub helped us scale from 5 to 50 developers in just six months. The talent quality is exceptional and the workflow feels incredibly smooth.",
    metric: "$2M+ saved in hiring costs",
  },
  {
    name: "James Rodriguez",
    role: "Freelance Developer",
    image:
      "https://images.unsplash.com/photo-1761623135057-e41b632694f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGdyYWRpZW50JTIwc29mdCUyMHBhc3RlbHxlbnwxfHx8fDE3NzQ3Njc2ODl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    quote:
      "I left my full-time role and now earn far more on SabaHub. The project quality, payout protection, and client trust are all stronger here.",
    metric: "Earning $180K/year",
  },
  {
    name: "Emily Parker",
    role: "Marketing Director, GrowthLabs",
    image:
      "https://images.unsplash.com/photo-1764173039056-3cc602fef942?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB3b21hbiUyMHByZXNlbnRhdGlvbnxlbnwxfHx8fDE3NzQ3NjE4MTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    quote:
      "Finding specialized marketing talent used to take weeks. SabaHub connected us with experts who immediately moved the needle.",
    metric: "350% ROI increase",
  },
  {
    name: "David Chen",
    role: "UX Designer",
    image:
      "https://images.unsplash.com/photo-1728281144091-b743062a9bf0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGRlc2lnbmVyJTIwd29ya3NwYWNlfGVufDF8fHx8MTc3NDczNTc1MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    quote:
      "The portfolio presentation and client discovery experience feel polished. I have steadier work and much stronger project alignment now.",
    metric: "45+ successful projects",
  },
] as const;

export const FOOTER_LINK_GROUPS = [
  {
    title: "For Clients",
    links: ["How to Hire", "Talent Marketplace", "Project Catalog", "Enterprise", "Hire Worldwide"],
  },
  {
    title: "For Freelancers",
    links: ["How to Find Work", "Find Freelance Jobs", "Build Portfolio", "Success Stories", "Resources"],
  },
  {
    title: "Company",
    links: ["About Us", "Leadership", "Careers", "Investor Relations", "Trust & Safety", "Press & Media"],
  },
  {
    title: "Support",
    links: ["Help Center", "Community", "Contact Us", "API Documentation", "System Status"],
  },
] as const;

export const SOCIAL_LINKS = [
  { label: "X", href: "https://x.com" },
  { label: "in", href: "https://linkedin.com" },
  { label: "IG", href: "https://instagram.com" },
] as const;
