"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import {
  AppBar,
  Avatar,
  Badge,
  Box,
  Divider,
  IconButton,
  InputAdornment,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Stack,
  TextField,
  Toolbar,
  Tooltip,
  Typography,
} from "@mui/material";
import { alpha, useTheme } from "@mui/material/styles";
import {
  AccountCircle,
  Forum,
  Logout,
  Menu as MenuIcon,
  Notifications,
  Search,
  Settings,
  Wallet,
} from "@mui/icons-material";
import RoleModeSwitch from "@/components/RoleModeSwitch";
import ThemeToggle from "@/components/mui/ThemeToggle";
import { WORKSPACE_HEADER_HEIGHT } from "@/components/workspace-shell";
import { getNotificationHref } from "@/lib/notificationRoutes";
import { getNotificationMessage, getNotificationTitle } from "@/lib/notificationPresentation";
import { useNotifications } from "@/lib/notifications";
import { useSession } from "@/lib/session";
import { workspaceRoutes } from "@/lib/workspace-routes";

export default function Navbar({ onMenuToggle }: { onMenuToggle?: () => void }) {
  const router = useRouter();
  const theme = useTheme();
  const [hasMounted, setHasMounted] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [notifAnchor, setNotifAnchor] = useState<null | HTMLElement>(null);
  const [userAnchor, setUserAnchor] = useState<null | HTMLElement>(null);

  const role = useSession((s) => s.role);
  const fullName = useSession((s) => s.fullName);
  const email = useSession((s) => s.email);
  const profilePictureUrl = useSession((s) => s.profilePictureUrl);
  const clear = useSession((s) => s.clear);
  const notifications = useNotifications((s) => s.items);
  const unread = useNotifications((s) => s.unread);
  const markRead = useNotifications((s) => s.markRead);
  const markAllRead = useNotifications((s) => s.markAllRead);

  const profileHref = role === "ADMIN" ? "/admin" : workspaceRoutes.settings;

  useEffect(() => {
    setHasMounted(true);
  }, []);

  const safeName = hasMounted ? fullName : "";
  const safeEmail = hasMounted ? email : "";
  const safeProfilePictureUrl = hasMounted ? profilePictureUrl : "";
  const avatarLetter = (safeName || safeEmail || "U").charAt(0).toUpperCase();

  const notificationItems = useMemo(
    () =>
      notifications.slice(0, 8).map((item) => ({
        id: item.id,
        href: getNotificationHref(item),
        title: getNotificationTitle(item),
        message: getNotificationMessage(item),
        time: item.createdAt ? new Date(item.createdAt).toISOString() : "No timestamp",
        unread: !item.read,
      })),
    [notifications]
  );

  const handleLogout = () => {
    clear();
    localStorage.removeItem("auth_token");
    window.location.href = "/login";
  };

  return (
    <AppBar
      position="fixed"
      color="inherit"
      elevation={0}
      sx={{
        height: WORKSPACE_HEADER_HEIGHT,
        justifyContent: "center",
        bgcolor: "background.paper",
        borderBottom: "1px solid",
        borderColor: "rgba(0, 0, 0, 0.1)",
        boxShadow: "none",
        zIndex: (muiTheme) => muiTheme.zIndex.drawer + 2,
      }}
    >
      <Toolbar
        sx={{
          minHeight: `${WORKSPACE_HEADER_HEIGHT}px !important`,
          px: { xs: 1.5, md: 3 },
          gap: 2,
        }}
      >
        <Tooltip title="Toggle sidebar">
          <IconButton edge="start" onClick={onMenuToggle} sx={{ mr: 0.25 }}>
            <MenuIcon />
          </IconButton>
        </Tooltip>

        <TextField
          size="small"
          placeholder="Search jobs, projects, talent..."
          value={searchQuery}
          onChange={(event) => setSearchQuery(event.target.value)}
          sx={{
            flex: 1,
            maxWidth: 576,
            "& .MuiOutlinedInput-root": {
              borderRadius: 2.5,
              bgcolor: theme.palette.mode === "light" ? "#e9ebef" : alpha(theme.palette.action.hover, 0.28),
              minHeight: 40,
              pr: 0.5,
            },
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Search fontSize="small" color="action" />
              </InputAdornment>
            ),
          }}
        />

        <Box sx={{ ml: "auto", display: "flex", alignItems: "center", gap: 2 }}>
          <ThemeToggle />

          <Tooltip title="Messages">
            <IconButton
              component={Link}
              href="/chat"
              sx={{
                p: 1,
                borderRadius: "8px",
                position: "relative",
              }}
            >
              <Forum />
              <Box
                sx={{
                  position: "absolute",
                  top: 8,
                  right: 8,
                  width: 7,
                  height: 7,
                  borderRadius: "50%",
                  bgcolor: "info.main",
                }}
              />
            </IconButton>
          </Tooltip>

          <Tooltip title="Notifications">
            <IconButton onClick={(event) => setNotifAnchor(event.currentTarget)} sx={{ p: 1, borderRadius: "8px" }}>
              <Badge badgeContent={unread > 99 ? "99+" : unread} color="error">
                <Notifications />
              </Badge>
            </IconButton>
          </Tooltip>

          <Divider flexItem orientation="vertical" sx={{ display: { xs: "none", md: "block" }, height: 32, alignSelf: "center" }} />

          <Box sx={{ display: { xs: "none", md: "block" } }}>
            <RoleModeSwitch variant="button" />
          </Box>

          <Stack direction="row" alignItems="center" spacing={1.5} sx={{ ml: { xs: 0, md: 0.5 } }}>
            <Box sx={{ display: { xs: "none", sm: "block" }, textAlign: "right" }}>
              <Typography sx={{ fontSize: "0.875rem", fontWeight: 500, lineHeight: 1.3 }} noWrap>
                {safeName || "Workspace User"}
              </Typography>
              <Typography sx={{ fontSize: "0.75rem", color: "#717182", textTransform: "capitalize", lineHeight: 1.25 }} noWrap>
                {role === "ADMIN" ? "administrator" : role === "EMPLOYER" ? "employer" : "freelancer"}
              </Typography>
            </Box>

            <Tooltip title="Open account menu">
              <IconButton onClick={(event) => setUserAnchor(event.currentTarget)} sx={{ p: 0 }}>
                <Avatar
                  src={safeProfilePictureUrl || undefined}
                  sx={{
                    width: 40,
                    height: 40,
                    fontWeight: 700,
                    color: "#ffffff",
                    background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
                  }}
                >
                  {avatarLetter}
                </Avatar>
              </IconButton>
            </Tooltip>

            <Tooltip title="Logout">
              <IconButton onClick={handleLogout} sx={{ display: { xs: "none", md: "inline-flex" }, p: 1, borderRadius: "8px", color: "#717182" }}>
                <Logout />
              </IconButton>
            </Tooltip>
          </Stack>
        </Box>
      </Toolbar>

      <Menu
        anchorEl={notifAnchor}
        open={Boolean(notifAnchor)}
        onClose={() => setNotifAnchor(null)}
        PaperProps={{
          sx: {
            mt: 1,
            width: { xs: "calc(100vw - 24px)", sm: 360 },
            maxWidth: "calc(100vw - 24px)",
            borderRadius: 3,
          },
        }}
      >
        <Box sx={{ px: 1.5, py: 1.25, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Typography variant="subtitle2" fontWeight={800}>
            Notifications
          </Typography>
          {unread > 0 ? (
            <Typography
              component="button"
              type="button"
              onClick={() => void markAllRead()}
              sx={{
                border: 0,
                background: "transparent",
                color: "primary.main",
                cursor: "pointer",
                fontSize: 12,
                fontWeight: 700,
                p: 0,
              }}
            >
              Mark all read
            </Typography>
          ) : null}
        </Box>
        <Divider />
        {notificationItems.length ? (
          notificationItems.map((item) => (
            <MenuItem
              key={item.id}
              onClick={async () => {
                await markRead(item.id);
                setNotifAnchor(null);
                router.push(item.href);
              }}
              sx={{
                alignItems: "flex-start",
                py: 1.25,
                gap: 1,
                borderLeft: item.unread ? `3px solid ${theme.palette.primary.main}` : "3px solid transparent",
              }}
            >
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography variant="body2" fontWeight={700} noWrap>
                  {item.title}
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: "block", whiteSpace: "normal" }}>
                  {item.message}
                </Typography>
                <Typography variant="caption" color="text.disabled">
                  {item.time}
                </Typography>
              </Box>
            </MenuItem>
          ))
        ) : (
          <Box sx={{ px: 1.5, py: 2 }}>
            <Typography variant="body2" color="text.secondary">
              No notifications yet.
            </Typography>
          </Box>
        )}
      </Menu>

      <Menu
        anchorEl={userAnchor}
        open={Boolean(userAnchor)}
        onClose={() => setUserAnchor(null)}
        PaperProps={{
          sx: {
            mt: 1,
            minWidth: 240,
            borderRadius: 3,
          },
        }}
      >
        <Box sx={{ px: 1.5, py: 1.25 }}>
          <Typography variant="body2" fontWeight={800} noWrap>
            {safeName || "Workspace User"}
          </Typography>
          <Typography variant="caption" color="text.secondary" noWrap>
            {safeEmail || "Signed in"}
          </Typography>
        </Box>
        <Divider />
        <Box sx={{ px: 1.5, py: 1.25, display: { xs: "block", md: "none" } }}>
          <RoleModeSwitch variant="button" />
        </Box>
        <Divider sx={{ display: { xs: "block", md: "none" } }} />
        <MenuItem component={Link} href={profileHref} onClick={() => setUserAnchor(null)}>
          <ListItemIcon>
            <AccountCircle fontSize="small" />
          </ListItemIcon>
          <ListItemText primary="Profile" />
        </MenuItem>
        <MenuItem component={Link} href={workspaceRoutes.wallet} onClick={() => setUserAnchor(null)}>
          <ListItemIcon>
            <Wallet fontSize="small" />
          </ListItemIcon>
          <ListItemText primary="Wallet" />
        </MenuItem>
        <MenuItem component={Link} href={workspaceRoutes.settings} onClick={() => setUserAnchor(null)}>
          <ListItemIcon>
            <Settings fontSize="small" />
          </ListItemIcon>
          <ListItemText primary="Settings" />
        </MenuItem>
        <Divider />
        <MenuItem
          onClick={() => {
            setUserAnchor(null);
            handleLogout();
          }}
        >
          <ListItemIcon>
            <Logout fontSize="small" />
          </ListItemIcon>
          <ListItemText primary="Logout" />
        </MenuItem>
      </Menu>
    </AppBar>
  );
}
