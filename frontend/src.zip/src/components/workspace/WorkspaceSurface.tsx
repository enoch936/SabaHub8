"use client";

import type { ReactNode } from "react";
import {
  Box,
  CardContent,
  Stack,
  Typography,
  type SxProps,
  type Theme,
} from "@mui/material";
import { alpha, useTheme } from "@mui/material/styles";
import SoftCard from "@/components/mui/SoftCard";

type WorkspacePanelProps = {
  children: ReactNode;
  sx?: SxProps<Theme>;
  contentSx?: SxProps<Theme>;
  noPadding?: boolean;
};

export function WorkspacePanel({ children, sx, contentSx, noPadding = false }: WorkspacePanelProps) {
  return (
    <SoftCard
      sx={[
        {
          borderRadius: 3,
          border: "1px solid",
          borderColor: "divider",
          bgcolor: "background.paper",
          backgroundImage: "none",
          boxShadow: "none",
        },
        ...(Array.isArray(sx) ? sx : sx ? [sx] : []),
      ]}
    >
      {noPadding ? (
        children
      ) : (
        <CardContent sx={[{ p: 2.25 }, ...(Array.isArray(contentSx) ? contentSx : contentSx ? [contentSx] : [])]}>
          {children}
        </CardContent>
      )}
    </SoftCard>
  );
}

export function WorkspacePageIntro({
  eyebrow,
  title,
  description,
  actions,
  meta,
  sx,
}: {
  eyebrow?: string;
  title: string;
  description: string;
  actions?: ReactNode;
  meta?: ReactNode;
  sx?: SxProps<Theme>;
}) {
  return (
    <WorkspacePanel sx={sx}>
      <Stack
        direction={{ xs: "column", md: "row" }}
        justifyContent="space-between"
        alignItems={{ xs: "flex-start", md: "center" }}
        spacing={2}
      >
        <Box sx={{ minWidth: 0 }}>
          {eyebrow ? (
            <Typography variant="overline" color="primary.main" fontWeight={800}>
              {eyebrow}
            </Typography>
          ) : null}
          <Typography variant="h4" fontWeight={800} sx={{ letterSpacing: "-0.03em" }}>
            {title}
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5, maxWidth: 860 }}>
            {description}
          </Typography>
          {meta ? <Box sx={{ mt: 1.25 }}>{meta}</Box> : null}
        </Box>
        {actions ? <Box sx={{ flexShrink: 0, width: { xs: "100%", md: "auto" } }}>{actions}</Box> : null}
      </Stack>
    </WorkspacePanel>
  );
}

export function WorkspaceStatTile({
  label,
  value,
  meta,
  icon,
  tone = "primary",
}: {
  label: string;
  value: string;
  meta?: string;
  icon?: ReactNode;
  tone?: "primary" | "success" | "warning" | "error";
}) {
  const theme = useTheme();
  const toneColor = theme.palette[tone].main;

  return (
    <WorkspacePanel contentSx={{ p: 2 }}>
      <Stack direction="row" justifyContent="space-between" spacing={1.25}>
        <Box sx={{ minWidth: 0 }}>
          <Typography variant="caption" color="text.secondary" fontWeight={700}>
            {label}
          </Typography>
          <Typography variant="h6" fontWeight={800} sx={{ mt: 0.55, letterSpacing: "-0.02em" }}>
            {value}
          </Typography>
          {meta ? (
            <Typography variant="caption" color="text.secondary">
              {meta}
            </Typography>
          ) : null}
        </Box>
        {icon ? (
          <Box
            sx={{
              width: 42,
              height: 42,
              borderRadius: 2.5,
              display: "grid",
              placeItems: "center",
              bgcolor: alpha(toneColor, 0.12),
              color: toneColor,
              flexShrink: 0,
            }}
          >
            {icon}
          </Box>
        ) : null}
      </Stack>
    </WorkspacePanel>
  );
}

export function WorkspaceSectionTitle({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <Stack
      direction={{ xs: "column", md: "row" }}
      justifyContent="space-between"
      alignItems={{ xs: "flex-start", md: "center" }}
      spacing={1}
      sx={{ mb: 1.75 }}
    >
      <Box>
        <Typography variant="h6" fontWeight={800}>
          {title}
        </Typography>
        {description ? (
          <Typography variant="body2" color="text.secondary">
            {description}
          </Typography>
        ) : null}
      </Box>
      {action ? <Box>{action}</Box> : null}
    </Stack>
  );
}
