"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Alert,
  Box,
  CardContent,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import AssignmentLateRoundedIcon from "@mui/icons-material/AssignmentLateRounded";
import FactCheckRoundedIcon from "@mui/icons-material/FactCheckRounded";
import GppMaybeRoundedIcon from "@mui/icons-material/GppMaybeRounded";
import RefreshRoundedIcon from "@mui/icons-material/RefreshRounded";
import ReportProblemRoundedIcon from "@mui/icons-material/ReportProblemRounded";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import SupportAgentRoundedIcon from "@mui/icons-material/SupportAgentRounded";
import TaskAltRoundedIcon from "@mui/icons-material/TaskAltRounded";
import TravelExploreRoundedIcon from "@mui/icons-material/TravelExploreRounded";
import SoftButton from "@/components/mui/SoftButton";
import SoftCard from "@/components/mui/SoftCard";
import SoftTextField from "@/components/mui/SoftTextField";
import {
  type Dispute,
  adminPatchDispute,
  listDisputes,
} from "@/lib/api";

const disputeStatuses = ["OPEN", "INVESTIGATING", "RESOLVED", "CLOSED"] as const;

function formatDateTime(value?: string) {
  if (!value) {
    return "Not recorded";
  }
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) {
    return value;
  }
  return new Date(parsed).toLocaleString();
}

function statusTone(status?: string): "default" | "success" | "warning" | "error" | "info" {
  switch ((status ?? "").toUpperCase()) {
    case "OPEN":
      return "warning";
    case "INVESTIGATING":
      return "info";
    case "RESOLVED":
      return "success";
    case "CLOSED":
      return "default";
    default:
      return "default";
  }
}

export default function AdminSupportOperationsWorkspace() {
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionStatus, setActionStatus] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedDispute, setSelectedDispute] = useState<Dispute | null>(null);
  const [reviewStatus, setReviewStatus] = useState("INVESTIGATING");
  const [reviewNote, setReviewNote] = useState("");
  const [busyDisputeId, setBusyDisputeId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await listDisputes();
      setDisputes(result);
    } catch (err) {
      const message = err instanceof Error && err.message ? err.message : "Failed to load support cases.";
      setError(message);
      setDisputes([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const metrics = useMemo(() => {
    const open = disputes.filter((item) => (item.status ?? "").toUpperCase() === "OPEN").length;
    const investigating = disputes.filter((item) => (item.status ?? "").toUpperCase() === "INVESTIGATING").length;
    const resolved = disputes.filter((item) => (item.status ?? "").toUpperCase() === "RESOLVED").length;
    const escalated = disputes.filter((item) => (item.evidenceAssetIds?.length ?? 0) > 0).length;
    return {
      total: disputes.length,
      open,
      investigating,
      resolved,
      escalated,
    };
  }, [disputes]);

  const filteredDisputes = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return disputes.filter((item) => {
      const status = (item.status ?? "").toUpperCase();
      if (statusFilter !== "all" && status !== statusFilter) {
        return false;
      }
      if (!normalized) {
        return true;
      }
      return [
        item.id,
        item.contractId ?? "",
        item.openedByUserId ?? "",
        item.reason ?? "",
        ...(item.adminNotes ?? []),
      ].some((value) => value.toLowerCase().includes(normalized));
    });
  }, [disputes, query, statusFilter]);

  const patchLocalDispute = (updated: Dispute) => {
    setDisputes((current) => current.map((item) => (item.id === updated.id ? updated : item)));
    setSelectedDispute((current) => (current?.id === updated.id ? updated : current));
  };

  const applyDisputeUpdate = async (target: Dispute, status: string, note?: string) => {
    if (!target?.id) {
      return;
    }
    setBusyDisputeId(target.id);
    setActionStatus(null);
    try {
      const updated = await adminPatchDispute(target.id, {
        status,
        adminNote: note?.trim() || undefined,
      });
      patchLocalDispute(updated);
      setActionStatus(`Dispute ${updated.id} moved to ${updated.status}.`);
      setSelectedDispute(updated);
    } catch (err) {
      const message = err instanceof Error && err.message ? err.message : "Failed to update dispute.";
      setActionStatus(message);
    } finally {
      setBusyDisputeId(null);
    }
  };

  const openReview = (item: Dispute) => {
    setSelectedDispute(item);
    setReviewStatus((item.status ?? "OPEN").toUpperCase());
    setReviewNote("");
  };

  const applyReview = async () => {
    if (!selectedDispute) {
      return;
    }
    await applyDisputeUpdate(selectedDispute, reviewStatus, reviewNote);
  };

  return (
    <Stack spacing={2.2}>
      <SoftCard
        sx={{
          border: "1px solid",
          borderColor: "rgba(24,40,59,0.16)",
          background: "linear-gradient(135deg, #1b2230 0%, #27384f 55%, #4c516a 100%)",
          color: "common.white",
        }}
      >
        <CardContent>
          <Stack spacing={1.2}>
            <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" alignItems={{ md: "center" }} gap={1}>
              <Box>
                <Typography variant="overline" sx={{ letterSpacing: "0.14em", opacity: 0.82 }}>
                  SUPPORT OPERATIONS
                </Typography>
                <Typography variant="h4" fontWeight={900} sx={{ lineHeight: 1.02 }}>
                  Support and dispute handling is now a real workspace
                </Typography>
                <Typography variant="body2" sx={{ mt: 0.4, opacity: 0.9, maxWidth: 780 }}>
                  Review live dispute cases, move incidents into investigation, resolve outcomes, close handled cases,
                  and record auditable admin notes from one support operations console.
                </Typography>
              </Box>
              <SoftButton
                variant="outlined"
                onClick={() => void load()}
                disabled={loading}
                startIcon={<RefreshRoundedIcon />}
                sx={{ color: "#fff", borderColor: "rgba(255,255,255,0.55)" }}
              >
                Refresh
              </SoftButton>
            </Stack>
          </Stack>
        </CardContent>
      </SoftCard>

      {error ? <Alert severity="error">{error}</Alert> : null}
      {actionStatus ? <Alert severity="info">{actionStatus}</Alert> : null}

      <Grid container spacing={2}>
        {[
          { label: "Total Cases", value: metrics.total, icon: <SupportAgentRoundedIcon fontSize="small" /> },
          { label: "Open Cases", value: metrics.open, icon: <AssignmentLateRoundedIcon fontSize="small" /> },
          { label: "Investigating", value: metrics.investigating, icon: <TravelExploreRoundedIcon fontSize="small" /> },
          { label: "Resolved", value: metrics.resolved, icon: <TaskAltRoundedIcon fontSize="small" /> },
          { label: "Evidence Attached", value: metrics.escalated, icon: <GppMaybeRoundedIcon fontSize="small" /> },
        ].map((metric) => (
          <Grid key={metric.label} size={{ xs: 12, sm: 6, xl: 2.4 }}>
            <SoftCard sx={{ border: "1px solid", borderColor: "divider", height: "100%" }}>
              <CardContent>
                <Stack spacing={0.8}>
                  <Stack direction="row" justifyContent="space-between" alignItems="center">
                    <Typography variant="body2" color="text.secondary">
                      {metric.label}
                    </Typography>
                    {metric.icon}
                  </Stack>
                  <Typography variant="h4" fontWeight={900}>
                    {metric.value}
                  </Typography>
                </Stack>
              </CardContent>
            </SoftCard>
          </Grid>
        ))}
      </Grid>

      <SoftCard sx={{ border: "1px solid", borderColor: "divider" }}>
        <CardContent>
          <Grid container spacing={1.2}>
            <Grid size={{ xs: 12, md: 8 }}>
              <SoftTextField
                fullWidth
                label="Search support cases"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Dispute ID, contract, user, reason, note"
                InputProps={{ startAdornment: <SearchRoundedIcon sx={{ fontSize: 18, mr: 1, color: "text.secondary" }} /> }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <FormControl fullWidth size="small">
                <InputLabel id="support-status-filter">Case Status</InputLabel>
                <Select
                  labelId="support-status-filter"
                  value={statusFilter}
                  label="Case Status"
                  onChange={(event) => setStatusFilter(event.target.value)}
                >
                  <MenuItem value="all">All statuses</MenuItem>
                  {disputeStatuses.map((status) => (
                    <MenuItem key={status} value={status}>
                      {status}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </CardContent>
      </SoftCard>

      <SoftCard sx={{ border: "1px solid", borderColor: "divider" }}>
        <CardContent sx={{ p: 0 }}>
          <Box sx={{ p: 2, pb: 1 }}>
            <Typography variant="h6" fontWeight={800}>
              Dispute Case Queue
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Review case context, update status, and add investigation notes without leaving the admin workspace.
            </Typography>
          </Box>
          <Box sx={{ overflowX: "auto" }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Case</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Reason</TableCell>
                  <TableCell>Opened</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredDisputes.map((item) => {
                  const status = (item.status ?? "OPEN").toUpperCase();
                  const busy = busyDisputeId === item.id;
                  return (
                    <TableRow key={item.id} hover>
                      <TableCell sx={{ minWidth: 220 }}>
                        <Stack spacing={0.25}>
                          <Typography variant="subtitle2" fontWeight={800}>
                            {item.id}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Contract: {item.contractId}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Reporter: {item.openedByUserId || "Unknown"}
                          </Typography>
                        </Stack>
                      </TableCell>
                      <TableCell>
                        <Chip label={status} size="small" color={statusTone(status)} variant="outlined" />
                      </TableCell>
                      <TableCell sx={{ minWidth: 280 }}>
                        <Typography variant="body2" color="text.secondary">
                          {item.reason || "No reason provided"}
                        </Typography>
                      </TableCell>
                      <TableCell>{formatDateTime(item.createdAt)}</TableCell>
                      <TableCell align="right" sx={{ minWidth: 250 }}>
                        <Stack direction="row" spacing={0.8} justifyContent="flex-end">
                          <SoftButton
                            variant="outlined"
                            size="small"
                            onClick={() => openReview(item)}
                            disabled={busy}
                          >
                            Review
                          </SoftButton>
                          <SoftButton
                            variant="outlined"
                            size="small"
                            color="info"
                            startIcon={<FactCheckRoundedIcon />}
                            onClick={() => void applyDisputeUpdate(item, "INVESTIGATING")}
                            disabled={busy || status === "INVESTIGATING"}
                          >
                            Investigate
                          </SoftButton>
                          <SoftButton
                            variant="outlined"
                            size="small"
                            color="success"
                            startIcon={<ReportProblemRoundedIcon />}
                            onClick={() => void applyDisputeUpdate(item, "RESOLVED")}
                            disabled={busy || status === "RESOLVED" || status === "CLOSED"}
                          >
                            Resolve
                          </SoftButton>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {!loading && filteredDisputes.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} align="center" sx={{ py: 4 }}>
                      No support cases match the current filters.
                    </TableCell>
                  </TableRow>
                ) : null}
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={5} align="center" sx={{ py: 4 }}>
                      Loading support case queue...
                    </TableCell>
                  </TableRow>
                ) : null}
              </TableBody>
            </Table>
          </Box>
        </CardContent>
      </SoftCard>

      <Dialog open={!!selectedDispute} onClose={() => setSelectedDispute(null)} fullWidth maxWidth="sm">
        <DialogTitle>Review Support Case</DialogTitle>
        <DialogContent dividers>
          {selectedDispute ? (
            <Stack spacing={1.2}>
              <Typography variant="body2" color="text.secondary">
                Case: {selectedDispute.id}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Contract: {selectedDispute.contractId}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Reporter: {selectedDispute.openedByUserId || "Unknown"}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Created: {formatDateTime(selectedDispute.createdAt)}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Evidence files: {selectedDispute.evidenceAssetIds?.length ?? 0}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Reason: {selectedDispute.reason || "No reason provided"}
              </Typography>
              <FormControl fullWidth size="small">
                <InputLabel id="support-review-status">Next Status</InputLabel>
                <Select
                  labelId="support-review-status"
                  value={reviewStatus}
                  label="Next Status"
                  onChange={(event) => setReviewStatus(event.target.value)}
                >
                  {disputeStatuses.map((status) => (
                    <MenuItem key={status} value={status}>
                      {status}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <SoftTextField
                fullWidth
                label="Admin note"
                value={reviewNote}
                onChange={(event) => setReviewNote(event.target.value)}
                multiline
                minRows={3}
              />
              {(selectedDispute.adminNotes?.length ?? 0) > 0 ? (
                <Stack spacing={0.6}>
                  <Typography variant="caption" color="text.secondary">
                    Existing admin notes
                  </Typography>
                  {selectedDispute.adminNotes?.slice(-3).map((note, index) => (
                    <SoftCard key={`${selectedDispute.id}-note-${index}`} sx={{ border: "1px solid", borderColor: "divider" }}>
                      <CardContent sx={{ py: 1.2 }}>
                        <Typography variant="body2" color="text.secondary">
                          {note}
                        </Typography>
                      </CardContent>
                    </SoftCard>
                  ))}
                </Stack>
              ) : null}
            </Stack>
          ) : null}
        </DialogContent>
        <DialogActions>
          <SoftButton variant="outlined" onClick={() => setSelectedDispute(null)}>
            Close
          </SoftButton>
          <SoftButton
            variant="contained"
            onClick={() => void applyReview()}
            disabled={!selectedDispute || (selectedDispute ? busyDisputeId === selectedDispute.id : false)}
          >
            Apply Update
          </SoftButton>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}
