export const workspaceRoutes = {
  home: "/jobs",
  manageJobs: "/jobs/manage",
  createJob: "/jobs/post",
  analytics: "/jobs/analytics",
  wallet: "/jobs/wallet",
  settings: "/jobs/settings",
  notifications: "/jobs/notifications",
  contracts: "/jobs/contracts",
  proposals: "/jobs/proposals",
  help: "/jobs/help",
  assistant: "/jobs/assistant",
  publicJobDetail: (jobId: string) => `/jobs/${encodeURIComponent(jobId)}`,
  manageJobDetail: (jobId: string) => `/jobs/manage/${encodeURIComponent(jobId)}`,
  contractDetail: (contractId: string) => `/jobs/contracts/${encodeURIComponent(contractId)}`,
  proposalQueue: (projectId: string) => `/jobs/proposals/${encodeURIComponent(projectId)}`,
} as const;

export function normalizeLegacyWorkspaceRoute(path: string): string {
  if (!path.trim()) {
    return path;
  }

  let pathname = path;
  let search = "";

  try {
    const url = new URL(path, "http://localhost");
    pathname = url.pathname;
    search = url.search;
  } catch {
    return path;
  }

  let destination = pathname;

  if (pathname === "/dashboard") {
    destination = workspaceRoutes.home;
  } else if (pathname === "/dashboard/jobs") {
    destination = workspaceRoutes.manageJobs;
  } else if (pathname === "/dashboard/jobs/new") {
    destination = workspaceRoutes.createJob;
  } else if (pathname.startsWith("/dashboard/jobs/")) {
    destination = workspaceRoutes.manageJobDetail(pathname.slice("/dashboard/jobs/".length));
  } else if (pathname === "/dashboard/analytics") {
    destination = workspaceRoutes.analytics;
  } else if (pathname === "/dashboard/wallet") {
    destination = workspaceRoutes.wallet;
  } else if (pathname === "/dashboard/settings") {
    destination = workspaceRoutes.settings;
  } else if (pathname === "/dashboard/notifications") {
    destination = workspaceRoutes.notifications;
  } else if (pathname === "/dashboard/contracts") {
    destination = workspaceRoutes.contracts;
  } else if (pathname.startsWith("/dashboard/contracts/")) {
    destination = workspaceRoutes.contractDetail(pathname.slice("/dashboard/contracts/".length));
  } else if (pathname === "/dashboard/proposals") {
    destination = workspaceRoutes.proposals;
  } else if (pathname === "/dashboard/content") {
    destination = workspaceRoutes.help;
  } else if (pathname === "/dashboard/ai") {
    destination = workspaceRoutes.assistant;
  }

  return `${destination}${search}`;
}
