"use client";

import type { ReactNode } from "react";
import PrecisionManufacturingRoundedIcon from "@mui/icons-material/PrecisionManufacturingRounded";
import SecurityRoundedIcon from "@mui/icons-material/SecurityRounded";
import InsightsRoundedIcon from "@mui/icons-material/InsightsRounded";
import ManageAccountsRoundedIcon from "@mui/icons-material/ManageAccountsRounded";
import ApartmentRoundedIcon from "@mui/icons-material/ApartmentRounded";
import SmartToyRoundedIcon from "@mui/icons-material/SmartToyRounded";
import AccountBalanceWalletRoundedIcon from "@mui/icons-material/AccountBalanceWalletRounded";
import MonitorHeartRoundedIcon from "@mui/icons-material/MonitorHeartRounded";
import PolicyRoundedIcon from "@mui/icons-material/PolicyRounded";
import ApiRoundedIcon from "@mui/icons-material/ApiRounded";
import HubRoundedIcon from "@mui/icons-material/HubRounded";
import StorageRoundedIcon from "@mui/icons-material/StorageRounded";
import WorkRoundedIcon from "@mui/icons-material/WorkRounded";
import DescriptionRoundedIcon from "@mui/icons-material/DescriptionRounded";
import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";
import ArticleRoundedIcon from "@mui/icons-material/ArticleRounded";
import ReportProblemRoundedIcon from "@mui/icons-material/ReportProblemRounded";
import ChatRoundedIcon from "@mui/icons-material/ChatRounded";
import SettingsEthernetRoundedIcon from "@mui/icons-material/SettingsEthernetRounded";
import SettingsBackupRestoreRoundedIcon from "@mui/icons-material/SettingsBackupRestoreRounded";
import GppGoodRoundedIcon from "@mui/icons-material/GppGoodRounded";
import ManageSearchRoundedIcon from "@mui/icons-material/ManageSearchRounded";

const primaryIconSx = { fontSize: 16 };
const secondaryIconSx = { fontSize: 14 };

export type AdminHierarchyChild = {
  key: string;
  label: string;
  href: string;
  icon: ReactNode;
  section?: string;
};

export type AdminHierarchyItem = {
  key: string;
  label: string;
  href: string;
  icon: ReactNode;
  description: string;
  children?: AdminHierarchyChild[];
};

export type AdminNavigationGroup = {
  key: string;
  label: string;
  accent: string;
  items: AdminHierarchyItem[];
};

export const adminNavigationGroups: AdminNavigationGroup[] = [
  {
    key: "executive",
    label: "Executive",
    accent: "#304764",
    items: [
      {
        key: "platform-control",
        label: "Platform Control",
        href: "/admin/platform-control",
        icon: <PrecisionManufacturingRoundedIcon sx={primaryIconSx} />,
        description: "Release controls and recovery.",
        children: [
          {
            key: "runtime-controls",
            label: "Runtime Controls",
            href: "/admin/platform-control",
            section: "runtime-controls",
            icon: <SettingsEthernetRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "recovery-operations",
            label: "Recovery Operations",
            href: "/admin/platform-control",
            section: "recovery-operations",
            icon: <SettingsBackupRestoreRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
      {
        key: "security-governance",
        label: "Security Governance",
        href: "/admin/security-governance",
        icon: <SecurityRoundedIcon sx={primaryIconSx} />,
        description: "Threat posture and access control.",
        children: [
          {
            key: "threat-monitoring",
            label: "Threat Monitoring",
            href: "/admin/security-governance",
            section: "threat-monitoring",
            icon: <ManageSearchRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "policy-enforcement",
            label: "Policy Enforcement",
            href: "/admin/security-governance",
            section: "policy-enforcement",
            icon: <GppGoodRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
      {
        key: "analytics",
        label: "Analytics & Reporting",
        href: "/admin/analytics",
        icon: <InsightsRoundedIcon sx={primaryIconSx} />,
        description: "Reporting and operating intelligence.",
      },
    ],
  },
  {
    key: "operations",
    label: "Operations",
    accent: "#355851",
    items: [
      {
        key: "users-access",
        label: "Users & Access",
        href: "/admin/users",
        icon: <ManageAccountsRoundedIcon sx={primaryIconSx} />,
        description: "Directory, roles, and access.",
        children: [
          {
            key: "role-governance",
            label: "Role Governance",
            href: "/admin/domain/user-role-management",
            icon: <ManageAccountsRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "tenant-management",
            label: "Tenant Management",
            href: "/admin/tenants",
            icon: <ApartmentRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
      {
        key: "marketplace-operations",
        label: "Marketplace Operations",
        href: "/admin/jobs",
        icon: <WorkRoundedIcon sx={primaryIconSx} />,
        description: "Jobs, proposals, disputes, moderation.",
        children: [
          {
            key: "proposal-pipeline",
            label: "Proposal Pipeline",
            href: "/admin/proposals",
            icon: <DescriptionRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "content-review",
            label: "Content Review",
            href: "/admin/content",
            icon: <ArticleRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "dispute-resolution",
            label: "Dispute Resolution",
            href: "/admin/disputes",
            icon: <ReportProblemRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
      {
        key: "content-moderation",
        label: "Content Moderation",
        href: "/admin/content-moderation",
        icon: <ReportProblemRoundedIcon sx={primaryIconSx} />,
        description: "Full trust and safety moderation workspace.",
        children: [
          {
            key: "moderation-jobs",
            label: "Job Moderation",
            href: "/admin/jobs",
            icon: <WorkRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "moderation-content",
            label: "Policy Content",
            href: "/admin/content",
            icon: <ArticleRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "moderation-disputes",
            label: "Dispute Cases",
            href: "/admin/disputes",
            icon: <DescriptionRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
      {
        key: "revenue-risk",
        label: "Revenue & Risk",
        href: "/admin/transactions",
        icon: <AccountBalanceWalletRoundedIcon sx={primaryIconSx} />,
        description: "Transactions, exposure, payout review.",
        children: [
          {
            key: "financial-oversight",
            label: "Financial Oversight",
            href: "/admin/domain/payment-financial-oversight",
            icon: <ReceiptLongRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
      {
        key: "financial-operations",
        label: "Financial Operations",
        href: "/admin/financial-operations",
        icon: <ReceiptLongRoundedIcon sx={primaryIconSx} />,
        description: "Payments, billing, withdrawals, fraud, and reports.",
        children: [
          {
            key: "finance-live-queues",
            label: "Payment & Withdrawal Queues",
            href: "/admin/transactions",
            icon: <AccountBalanceWalletRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "finance-runbooks",
            label: "Financial Runbooks",
            href: "/admin/financial-operations",
            icon: <ReceiptLongRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "financial-oversight-domain",
            label: "Financial Oversight Domain",
            href: "/admin/domain/payment-financial-oversight",
            icon: <PolicyRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
      {
        key: "chat-operations",
        label: "Chat Operations",
        href: "/admin/chat",
        icon: <ChatRoundedIcon sx={primaryIconSx} />,
        description: "Conversation oversight and escalation.",
      },
    ],
  },
  {
    key: "platform",
    label: "Platform Systems",
    accent: "#6a5a32",
    items: [
      {
        key: "ai-operations",
        label: "AI Operations",
        href: "/admin/ai-models",
        icon: <SmartToyRoundedIcon sx={primaryIconSx} />,
        description: "Model lifecycle and governance.",
        children: [
          {
            key: "ai-governance",
            label: "AI Governance Workspace",
            href: "/admin/domain/ai-governance-model-management",
            icon: <SmartToyRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
      {
        key: "infrastructure",
        label: "Infrastructure",
        href: "/admin/domain/system-monitoring-health-management",
        icon: <MonitorHeartRoundedIcon sx={primaryIconSx} />,
        description: "Health, deployments, integration reliability.",
        children: [
          {
            key: "devops-deployments",
            label: "DevOps & Deployments",
            href: "/admin/domain/devops-infrastructure-management",
            icon: <HubRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "api-integrations",
            label: "API & Integrations",
            href: "/admin/domain/api-integration-management",
            icon: <ApiRoundedIcon sx={secondaryIconSx} />,
          },
          {
            key: "data-operations",
            label: "Data Operations",
            href: "/admin/domain/data-management",
            icon: <StorageRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
      {
        key: "audit-compliance",
        label: "Audit & Compliance",
        href: "/admin/audit-logs",
        icon: <PolicyRoundedIcon sx={primaryIconSx} />,
        description: "Audit trails, governance, privacy controls.",
        children: [
          {
            key: "compliance-workspace",
            label: "Compliance Workspace",
            href: "/admin/domain/platform-governance",
            icon: <PolicyRoundedIcon sx={secondaryIconSx} />,
          },
        ],
      },
    ],
  },
];

export const adminHierarchy: AdminHierarchyItem[] = adminNavigationGroups.flatMap((group) => group.items);

export function createInitialExpandedParents() {
  return Object.fromEntries(adminHierarchy.map((item) => [item.key, true])) as Record<string, boolean>;
}

export function toBranchKey(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}
