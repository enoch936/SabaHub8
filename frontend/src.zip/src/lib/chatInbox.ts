"use client";

import { create } from "zustand";
import { listThreads, type ChatThread } from "./api";

type State = {
  threads: ChatThread[];
  unreadMessages: number;
  sync: (threads: ChatThread[]) => void;
  refresh: () => Promise<void>;
  connect: () => Promise<void>;
};

let refreshTimer: number | null = null;

export const useChatInbox = create<State>((set, get) => ({
  threads: [],
  unreadMessages: 0,
  sync: (threads) => set(toState(threads)),
  refresh: async () => {
    const remote = await listThreads().catch(() => []);
    if (!Array.isArray(remote)) {
      return;
    }
    set(toState(remote));
  },
  connect: async () => {
    if (typeof window !== "undefined" && refreshTimer == null) {
      refreshTimer = window.setInterval(() => {
        void get().refresh();
      }, 15000);
    }

    await get().refresh();
  },
}));

function toState(threads: ChatThread[]) {
  const normalizedThreads = [...threads].sort((left, right) => {
    const leftTime = left.lastMessageAt ? Date.parse(left.lastMessageAt) : 0;
    const rightTime = right.lastMessageAt ? Date.parse(right.lastMessageAt) : 0;
    return rightTime - leftTime;
  });

  return {
    threads: normalizedThreads,
    unreadMessages: normalizedThreads.reduce((sum, thread) => sum + Math.max(0, thread.unreadCount || 0), 0),
  };
}
