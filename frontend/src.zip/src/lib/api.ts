import axios from "axios";
import { ACTIVE_ROLE_STORAGE_KEY } from "./role-mode";

// Use Next.js API proxy for all environments
// The proxy is configured in route.ts to forward to backend at localhost:8080
const API_BASE = "/api";

export const api = axios.create({
  baseURL: API_BASE,
  withCredentials: false,
});

api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("auth_token");
    const activeRole = localStorage.getItem(ACTIVE_ROLE_STORAGE_KEY);
    if (token) {
      config.headers = config.headers || {};
      config.headers.Authorization = `Bearer ${token}`;
      if (activeRole) {
        config.headers["X-Active-Role"] = activeRole;
      }
    }
  }
  return config;
});

api.interceptors.response.use(
  (r) => {
    // Normalize empty responses
    if (r && (r.status === 204 || r.data === "")) {
      r.data = null;
    }
    return r;
  },
  (error) => {
    const status = error?.response?.status;
    // Reject only for network unreachable or true server errors
    const networkUnreachable = !error?.response;
    if (networkUnreachable || (typeof status === "number" && status >= 500)) {
      return Promise.reject(error);
    }
    
    // Always reject PATCH/PUT for settings - we need to know if it failed
    const method = error.config?.method?.toUpperCase();
    if (method === "PATCH" || method === "PUT") {
      return Promise.reject(error);
    }
    
    // Reject 403 Forbidden (authorization error)
    if (status === 403) {
      return Promise.reject(error);
    }
    
    // For other statuses (e.g., 4xx), resolve with empty payload
    const emptyResponse = {
      data: error?.response?.data ?? null,
      status: typeof status === "number" ? status : 0,
      statusText: error?.response?.statusText ?? "EMPTY",
      headers: error?.response?.headers ?? {},
      config: error.config,
      request: error.request,
    } as typeof error.response;

    // Optionally handle 401 navigation without throwing
    if (status === 401 && typeof window !== "undefined") {
      // window.location.href = "/login";
    }

    return Promise.resolve(emptyResponse);
  }
);

export type Page<T> = {
  items: T[];
  total: number;
};

// Auth
export async function login(input: { identifier: string; password: string }) {
  const { data } = await api.post("/auth/login", input);
  return data as { token: string; email: string; username?: string; fullName: string };
}

export async function register(input: { email: string; username?: string; password: string; fullName: string }) {
  const { data } = await api.post("/auth/register", input);
  return data as { token: string; email: string; username?: string; fullName: string };
}

export async function logoutApi() {
  try {
    await api.post("/auth/logout");
  } catch {
    // Ignore errors - client logout still proceeds
  }
}

// User Settings & Profile
export type UserProfile = {
  userId?: string;
  username?: string;
  bio?: string;
  profilePictureUrl?: string;
  location?: string;
  timezone?: string;
  phoneNumber?: string;
  language?: string;
  skills?: string[];
  certifications?: string[];
  expertise?: string;
  yearsOfExperience?: number;
  portfolioUrls?: string[];
  completedProjects?: number;
  averageRating?: number;
  totalReviews?: number;
  hourlyRate?: string;
  availability?: string;
  preferredCategories?: string[];
  openToOpportunities?: boolean;
  paymentMethod?: string;
  taxId?: string;
  emailNotifications?: boolean;
  smsNotifications?: boolean;
  hideProfile?: boolean;
  showEarnings?: boolean;
  preferredLanguage?: string;
  phoneVerified?: boolean;
  emailVerified?: boolean;
  identityVerified?: boolean;
  identityVerificationMethod?: string;
  identityVerifiedAt?: number;
  profileViewsCount?: number;
  proposalsSentCount?: number;
  contractsCompletedCount?: number;
  totalEarnings?: number;
  successRate?: number;
};

export async function getUserSettings() {
  const { data } = await api.get("/user/settings");
  return data as UserProfile;
}

export async function updateUserSettings(profile: Partial<UserProfile>) {
  const { data } = await api.patch("/user/settings", profile);
  return data as UserProfile;
}

export async function verifyPhone() {
  const { data } = await api.post("/user/settings/verify-phone");
  return data;
}

export async function requestPhoneVerification() {
  const { data } = await api.post("/user/settings/verify-phone/request");
  return data as { message?: string; success?: boolean };
}

export async function confirmPhoneVerification(otpCode: string) {
  const { data } = await api.post("/user/settings/verify-phone/confirm", { otpCode });
  return data as UserProfile;
}

export async function requestEmailVerification() {
  const { data } = await api.post("/user/settings/verify-email/request");
  return data as { message?: string; success?: boolean };
}

export async function confirmEmailVerification(otpCode: string) {
  const { data } = await api.post("/user/settings/verify-email/confirm", { otpCode });
  return data as UserProfile;
}

export async function verifyIdentity(method: string) {
  const { data } = await api.post("/user/settings/verify-identity", {}, { params: { method } });
  return data;
}

export async function getPublicProfile(userId: string) {
  const { data } = await api.get(`/user/settings/public/${userId}`);
  return data as UserProfile;
}

export async function me() {
  const { data } = await api.get("/auth/me");
  return data as { id: string; email: string; username?: string; fullName: string; roles: string[] };
}

// Jobs
export type Job = {
  id: string;
  title: string;
  description: string;
  overviewText?: string;
  employerId?: string;
  budget?: { min?: number; max?: number; currency?: string };
  budgetMin?: number;
  budgetMax?: number;
  currency?: string;
  status?: string;
  createdAt?: string;
  updatedAt?: string;
  engagementType?: string;
  deliverableType?: string;
  deliverableScopes?: string[];
  workLocation?: string;
  pricingModel?: string;
  rateBreakdown?: Record<string, number>;
  slaDeliveryDays?: number;
  maxConcurrentProjects?: number;
  includedRevisionRounds?: number;
  qualityStandards?: string[];
  requiredFormats?: string[];
  minYearsExperience?: number;
  requiredSkills?: string[];
  requiredTools?: string[];
  requiredQualifications?: string[];
  preferredExperience?: string[];
  requiresPortfolio?: boolean;
  requiresReferences?: boolean;
  minReferenceCount?: number;
  requiresNDA?: boolean;
  requiresBGCheck?: boolean;
  requiresInsurance?: boolean;
  complianceRequirements?: string[];
  dataClassifications?: string[];
  pilotProjectRequired?: boolean;
  pilotProjectScope?: string;
  pilotEstimatedHours?: number;
  preferredVendorOpportunity?: boolean;
  minimumMonthlyCommitment?: number;
  contractTermMonths?: number;
  rateStabilityGuarantee?: boolean;
  categoryId?: string;
  skills?: string[];
  industry?: string[];
  teamSize?: string[];
  companyName?: string;
  closingDate?: string;
  evaluationProcess?: string;
  applicationGuidelineUrls?: string[];
  sampleDocumentUrls?: string[];
  sampleImageUrls?: string[];
  sampleVideoUrls?: string[];
  sampleAudioUrls?: string[];
  isEnterpriseOnly?: boolean;
};

export type PaginatedResult<T> = {
  items: T[];
  total: number;
  page: number;
  size: number;
  totalPages: number;
  hasPrevious: boolean;
  hasNext: boolean;
};

type RawPagePayload<T> = {
  content?: T[];
  items?: T[];
  totalElements?: number;
  total?: number;
  number?: number;
  page?: number;
  size?: number;
  totalPages?: number;
  first?: boolean;
  last?: boolean;
  pageable?: {
    pageNumber?: number;
    pageSize?: number;
  };
};

function toFiniteNumber(value: unknown, fallback: number) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function normalizePage<T>(
  payload: RawPagePayload<T> | T[] | null | undefined,
  fallbackPage: number,
  fallbackSize: number
): PaginatedResult<T> {
  const page = Math.max(0, fallbackPage);
  const size = Math.max(1, fallbackSize);

  if (Array.isArray(payload)) {
    const total = payload.length;
    const totalPages = total > 0 ? Math.ceil(total / size) : 0;
    return {
      items: payload,
      total,
      page,
      size,
      totalPages,
      hasPrevious: page > 0,
      hasNext: page + 1 < totalPages,
    };
  }

  const raw = (payload && typeof payload === "object" ? payload : {}) as RawPagePayload<T>;
  const items = Array.isArray(raw.content) ? raw.content : Array.isArray(raw.items) ? raw.items : [];

  const resolvedSize = Math.max(
    1,
    toFiniteNumber(raw.size, toFiniteNumber(raw.pageable?.pageSize, size))
  );
  const resolvedPage = Math.max(
    0,
    toFiniteNumber(raw.number, toFiniteNumber(raw.page, toFiniteNumber(raw.pageable?.pageNumber, page)))
  );
  const total = Math.max(0, toFiniteNumber(raw.totalElements, toFiniteNumber(raw.total, items.length)));
  const totalPages = Math.max(0, toFiniteNumber(raw.totalPages, total > 0 ? Math.ceil(total / resolvedSize) : 0));

  const hasPrevious = typeof raw.first === "boolean" ? !raw.first : resolvedPage > 0;
  const hasNext = typeof raw.last === "boolean" ? !raw.last : resolvedPage + 1 < totalPages;

  return {
    items,
    total,
    page: resolvedPage,
    size: resolvedSize,
    totalPages,
    hasPrevious,
    hasNext,
  };
}

export type ListOpenJobsPageOptions = {
  page?: number;
  size?: number;
  q?: string;
  categoryId?: string;
  budgetBand?: string;
  experienceBand?: string;
  mediaFilter?: string;
  openOnly?: boolean;
  sortBy?: string;
  skills?: string[];
};

export async function listOpenJobsPage(options?: ListOpenJobsPageOptions) {
  const page = Math.max(0, options?.page ?? 0);
  const size = Math.max(1, options?.size ?? 20);

  const params: Record<string, string | number | boolean> = { page, size };
  if (options?.q) params.q = options.q;
  if (options?.categoryId) params.categoryId = options.categoryId;
  if (options?.budgetBand) params.budgetBand = options.budgetBand;
  if (options?.experienceBand) params.experienceBand = options.experienceBand;
  if (options?.mediaFilter) params.mediaFilter = options.mediaFilter;
  if (options?.openOnly) params.openOnly = true;
  if (options?.sortBy) params.sortBy = options.sortBy;
  if (options?.skills?.length) params.skills = options.skills.join(",");

  const { data } = await api.get("/jobs/browse/open", {
    params,
  });

  return normalizePage<Job>(data as RawPagePayload<Job> | Job[] | null | undefined, page, size);
}

type SeedMarketplaceJobPayload = {
  title: string;
  description: string;
  overviewText?: string;
  employerId?: string;
  status?: "OPEN";
  isEnterpriseOnly?: boolean;
  engagementType: "PROJECT_BASED" | "CONTRACT" | "LONG_TERM_PARTNERSHIP" | "RETAINER";
  deliverableType: "IMAGE_DESIGN" | "VIDEO_PRODUCTION" | "AUDIO_PRODUCTION" | "DOCUMENT_DEVELOPMENT" | "MIXED";
  workLocation?: string;
  budgetMin?: number;
  budgetMax?: number;
  currency?: string;
  pricingModel: "FIXED_PRICE" | "HOURLY" | "RETAINER" | "VOLUME_BASED";
  requiredSkills?: string[];
  skills?: string[];
  industry?: string[];
  companyName?: string;
  minYearsExperience?: number;
  categoryId?: string;
};

const DEFAULT_MARKETPLACE_SEED_JOBS: SeedMarketplaceJobPayload[] = [
  {
    title: "Brand Motion Graphics Package",
    description: "Create a cohesive set of animated brand assets for a product launch campaign.",
    overviewText: "Deliver short logo stings, lower thirds, and polished intro animations for paid and organic channels.",
    employerId: "seed-employer-01",
    status: "OPEN",
    isEnterpriseOnly: false,
    engagementType: "PROJECT_BASED",
    deliverableType: "VIDEO_PRODUCTION",
    workLocation: "Remote",
    budgetMin: 1200,
    budgetMax: 2800,
    currency: "USD",
    pricingModel: "FIXED_PRICE",
    requiredSkills: ["After Effects", "Motion Design", "Branding"],
    skills: ["After Effects", "Motion Design", "Branding"],
    industry: ["SaaS", "Marketing"],
    companyName: "SabaHub Studio",
    minYearsExperience: 3,
    categoryId: "motion-design",
  },
  {
    title: "Design System UI Kit for B2B Platform",
    description: "Build a scalable UI kit and component library for a finance dashboard product.",
    overviewText: "Create tokens, reusable components, and usage guidelines across desktop and tablet breakpoints.",
    employerId: "seed-employer-02",
    status: "OPEN",
    isEnterpriseOnly: false,
    engagementType: "CONTRACT",
    deliverableType: "IMAGE_DESIGN",
    workLocation: "Hybrid",
    budgetMin: 2500,
    budgetMax: 6000,
    currency: "USD",
    pricingModel: "HOURLY",
    requiredSkills: ["Figma", "Design Systems", "UX"],
    skills: ["Figma", "Design Systems", "UX"],
    industry: ["Finance", "B2B"],
    companyName: "Finorama",
    minYearsExperience: 4,
    categoryId: "design-systems",
  },
  {
    title: "Document Automation Templates",
    description: "Create reusable contract and reporting templates that teams can edit without design drift.",
    overviewText: "Deliver editable layouts with strong typography, brand compliance, and approval-ready exports.",
    employerId: "seed-employer-03",
    status: "OPEN",
    isEnterpriseOnly: false,
    engagementType: "RETAINER",
    deliverableType: "DOCUMENT_DEVELOPMENT",
    workLocation: "Remote",
    budgetMin: 800,
    budgetMax: 2000,
    currency: "USD",
    pricingModel: "FIXED_PRICE",
    requiredSkills: ["Document Design", "Brand Compliance", "Templates"],
    skills: ["Document Design", "Brand Compliance", "Templates"],
    industry: ["Legal", "Operations"],
    companyName: "DocuCraft",
    minYearsExperience: 2,
    categoryId: "document-design",
  },
  {
    title: "Podcast Editing and Audio Mastering",
    description: "Edit and master weekly podcast episodes with a clean, modern sound and consistent loudness.",
    overviewText: "Handle noise cleanup, music beds, ad inserts, and final mastering for distribution platforms.",
    employerId: "seed-employer-04",
    status: "OPEN",
    isEnterpriseOnly: false,
    engagementType: "LONG_TERM_PARTNERSHIP",
    deliverableType: "AUDIO_PRODUCTION",
    workLocation: "Remote",
    budgetMin: 600,
    budgetMax: 1600,
    currency: "USD",
    pricingModel: "RETAINER",
    requiredSkills: ["Audio Editing", "Sound Design", "Podcasting"],
    skills: ["Audio Editing", "Sound Design", "Podcasting"],
    industry: ["Media", "Education"],
    companyName: "WaveCast",
    minYearsExperience: 2,
    categoryId: "audio-production",
  },
  {
    title: "Product Demo Video Series",
    description: "Produce a set of polished short demo videos for newly launched SaaS features.",
    overviewText: "Own scripting, motion treatment, editing, and delivery in multiple aspect ratios for paid campaigns.",
    employerId: "seed-employer-05",
    status: "OPEN",
    isEnterpriseOnly: false,
    engagementType: "PROJECT_BASED",
    deliverableType: "VIDEO_PRODUCTION",
    workLocation: "Remote",
    budgetMin: 3000,
    budgetMax: 9000,
    currency: "USD",
    pricingModel: "FIXED_PRICE",
    requiredSkills: ["Video Editing", "Animation", "Storyboarding"],
    skills: ["Video Editing", "Animation", "Storyboarding"],
    industry: ["SaaS", "Product"],
    companyName: "FlowSuite",
    minYearsExperience: 4,
    categoryId: "video-production",
  },
  {
    title: "Mixed Media Launch Campaign",
    description: "Deliver a bundle of launch-week creative assets across social, email, and web placements.",
    overviewText: "Package graphics, short-form videos, and supporting audio cues for a coordinated campaign rollout.",
    employerId: "seed-employer-06",
    status: "OPEN",
    isEnterpriseOnly: false,
    engagementType: "CONTRACT",
    deliverableType: "MIXED",
    workLocation: "Remote",
    budgetMin: 2000,
    budgetMax: 5500,
    currency: "USD",
    pricingModel: "VOLUME_BASED",
    requiredSkills: ["Creative Direction", "Content Production", "Brand Design"],
    skills: ["Creative Direction", "Content Production", "Brand Design"],
    industry: ["E-commerce", "Retail"],
    companyName: "Brightlane",
    minYearsExperience: 3,
    categoryId: "creative-production",
  },
];

export async function listJobs() {
  const response = await listOpenJobsPage({ page: 0, size: 20 });
  return response.items;
}

export async function getJob(id: string) {
  const { data } = await api.get(`/jobs/${id}`);
  return data as Job;
}

export async function createJob(job: Partial<Job>) {
  const { data } = await api.post("/jobs", job);
  return data as Job;
}

async function uploadMediaFile(endpoint: string, file: File) {
  const formData = new FormData();
  formData.append("file", file);
  const { data } = await api.post(endpoint, formData);
  return data?.url as string | undefined;
}

async function uploadMediaFiles(endpoint: string, files: File[]) {
  if (!files.length) return [] as string[];
  const uploads = await Promise.all(files.map((file) => uploadMediaFile(endpoint, file)));
  return uploads.filter((url): url is string => Boolean(url));
}

export async function uploadJobSampleDocuments(files: File[]) {
  return uploadMediaFiles("/media/upload/report", files);
}

export async function uploadJobSampleImages(files: File[]) {
  return uploadMediaFiles("/media/upload/gallery-image", files);
}

export async function uploadJobSampleVideos(files: File[]) {
  return uploadMediaFiles("/media/upload/promo-video", files);
}

export async function uploadJobSampleAudio(files: File[]) {
  return uploadMediaFiles("/media/upload/audio-content", files);
}

export async function uploadProfileImage(file: File) {
  const formData = new FormData();
  formData.append("file", file);
  const response = await api.post("/user/settings/avatar", formData);
  if (response.status >= 400) {
    const message =
      typeof response.data === "string"
        ? response.data
        : response.data?.message || "Failed to upload avatar.";
    throw new Error(message);
  }
  const { data } = response;
  return (data?.profilePictureUrl as string | undefined) ?? (data?.url as string | undefined);
}

export async function listEmployerJobs(options?: { page?: number; size?: number }) {
  const page = Math.max(0, options?.page ?? 0);
  const size = Math.max(1, options?.size ?? 20);
  const { data } = await api.get("/jobs/employer/my-jobs", {
    params: { page, size },
  });
  return normalizePage<Job>(data as RawPagePayload<Job> | Job[] | null | undefined, page, size).items;
}

export async function listTrendingJobs(limit = 10) {
  const { data } = await api.get("/jobs/trending", { params: { limit } });
  return Array.isArray(data) ? (data as Job[]) : ([] as Job[]);
}

export type MarketplaceFreelancer = {
  id: string;
  userId?: string | null;
  name: string;
  title?: string | null;
  bio?: string | null;
  profileImageUrl?: string | null;
  skills: string[];
  hourlyRate?: number | null;
  currency?: string | null;
  rating?: number | null;
  reviewCount?: number | null;
  completedProjects?: number | null;
  availability?: string | null;
  location?: string | null;
  languages?: string[];
  certifications?: string[];
  lastActive?: string | null;
  verified?: boolean;
};

export async function listMarketplaceFreelancers(options?: { page?: number; size?: number }) {
  const page = Math.max(0, options?.page ?? 0);
  const size = Math.max(1, options?.size ?? 24);
  const { data } = await api.get("/freelancer/discover", {
    params: { page, size },
  });
  return normalizePage<MarketplaceFreelancer>(
    data as RawPagePayload<MarketplaceFreelancer> | MarketplaceFreelancer[] | null | undefined,
    page,
    size,
  );
}

export type SeedFreelancerReviewsResult = {
  seededCount: number;
  clearedCount: number;
  preview: FeaturedFreelancerReview[];
};

export async function seedMarketplaceJobs(options?: { clear?: boolean }) {
  const response = await api.post("/jobs/seed", DEFAULT_MARKETPLACE_SEED_JOBS, {
    params: { clear: options?.clear ?? false },
  });

  if (response.status >= 400) {
    const message =
      typeof response.data === "string"
        ? response.data
        : response.data?.message || "Failed to seed marketplace jobs.";
    throw new Error(message);
  }

  return Array.isArray(response.data) ? (response.data as Job[]) : ([] as Job[]);
}

export async function seedMarketplaceFreelancers(options?: { count?: number; clear?: boolean }) {
  const response = await api.post("/freelancer/seed/featured-reviews", null, {
    params: {
      count: Math.max(3, options?.count ?? 6),
      clear: options?.clear ?? false,
    },
  });

  if (response.status >= 400) {
    const message =
      typeof response.data === "string"
        ? response.data
        : response.data?.message || "Failed to seed marketplace freelancers.";
    throw new Error(message);
  }

  const data = (response.data ?? {}) as Partial<SeedFreelancerReviewsResult>;
  return {
    seededCount: typeof data.seededCount === "number" ? data.seededCount : 0,
    clearedCount: typeof data.clearedCount === "number" ? data.clearedCount : 0,
    preview: Array.isArray(data.preview) ? data.preview : [],
  } satisfies SeedFreelancerReviewsResult;
}

export async function bootstrapMarketplaceCatalog() {
  const [jobsResult, freelancersResult] = await Promise.allSettled([
    seedMarketplaceJobs(),
    seedMarketplaceFreelancers({ count: 6 }),
  ]);

  return {
    jobsCreated: jobsResult.status === "fulfilled" ? jobsResult.value.length : 0,
    freelancersCreated:
      freelancersResult.status === "fulfilled" ? freelancersResult.value.seededCount : 0,
    createdAny:
      (jobsResult.status === "fulfilled" && jobsResult.value.length > 0) ||
      (freelancersResult.status === "fulfilled" && freelancersResult.value.seededCount > 0),
  };
}

export type WorkspaceBootstrapResult = {
  createdAny: boolean;
  employerSeeded: boolean;
  freelancerSeeded: boolean;
  supportUsersCreated: number;
  employerProfilesCreated: number;
  freelancerProfilesCreated: number;
  jobsCreated: number;
  proposalsCreated: number;
  contractsCreated: number;
};

export async function bootstrapWorkspaceDemoData() {
  const response = await api.post("/workspace/bootstrap");

  if (response.status >= 400) {
    const message =
      typeof response.data === "string"
        ? response.data
        : response.data?.message || "Failed to bootstrap workspace demo data.";
    throw new Error(message);
  }

  const data = (response.data ?? {}) as Partial<WorkspaceBootstrapResult>;
  return {
    createdAny: Boolean(data.createdAny),
    employerSeeded: Boolean(data.employerSeeded),
    freelancerSeeded: Boolean(data.freelancerSeeded),
    supportUsersCreated: typeof data.supportUsersCreated === "number" ? data.supportUsersCreated : 0,
    employerProfilesCreated: typeof data.employerProfilesCreated === "number" ? data.employerProfilesCreated : 0,
    freelancerProfilesCreated: typeof data.freelancerProfilesCreated === "number" ? data.freelancerProfilesCreated : 0,
    jobsCreated: typeof data.jobsCreated === "number" ? data.jobsCreated : 0,
    proposalsCreated: typeof data.proposalsCreated === "number" ? data.proposalsCreated : 0,
    contractsCreated: typeof data.contractsCreated === "number" ? data.contractsCreated : 0,
  } satisfies WorkspaceBootstrapResult;
}

export type FeaturedFreelancerReview = {
  id: string;
  quote: string;
  name: string;
  role: string;
  rating: number;
  reviewCount: number;
  avatarUrl?: string | null;
};

export async function listFeaturedFreelancerReviews(limit = 3) {
  try {
    const { data } = await api.get("/freelancer/featured-reviews", { params: { limit } });
    if (!Array.isArray(data)) return [] as FeaturedFreelancerReview[];

    return data
      .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === "object"))
      .map((item) => ({
        id: typeof item.id === "string" ? item.id : "",
        quote: typeof item.quote === "string" ? item.quote : "",
        name: typeof item.name === "string" ? item.name : "Verified Freelancer",
        role: typeof item.role === "string" ? item.role : "Freelancer",
        rating: typeof item.rating === "number" ? item.rating : 0,
        reviewCount: typeof item.reviewCount === "number" ? item.reviewCount : 0,
        avatarUrl: typeof item.avatarUrl === "string" ? item.avatarUrl : undefined,
      }))
      .filter((item) => Boolean(item.id));
  } catch {
    return [] as FeaturedFreelancerReview[];
  }
}

// Proposals
export type Proposal = {
  id: string;
  jobId: string;
  freelancerId?: string;
  coverLetter: string;
  bidAmount: number;
  timelineDays: number;
  status: string;
  createdAt?: string;
  updatedAt?: string;
};

export async function submitProposal(jobId: string, body: { coverLetter: string; bidAmount: number; timelineDays: number }) {
  const { data } = await api.post(`/jobs/${jobId}/proposals`, body);
  return data as Proposal;
}

export async function listJobProposals(jobId: string) {
  const { data } = await api.get(`/employer/jobs/${jobId}/proposals`);
  return data as Proposal[];
}

export async function acceptProposal(proposalId: string) {
  const { data } = await api.post(`/employer/proposals/${proposalId}/accept`);
  return data as any; // Contract
}

export type Gig = {
  id: string;
  freelancerId?: string;
  title: string;
  description: string;
  skills?: string[];
  price?: number;
  currency?: string;
  deliveryDays?: number;
  active?: boolean;
  createdAt?: string;
  updatedAt?: string;
};

export async function listMyGigs() {
  const { data } = await api.get("/gigs/mine");
  return Array.isArray(data) ? (data as Gig[]) : ([] as Gig[]);
}

export async function createGig(input: Partial<Gig>) {
  const { data } = await api.post("/gigs", input);
  return data as Gig;
}

export async function updateGig(id: string, input: Partial<Gig>) {
  const { data } = await api.put(`/gigs/${id}`, input);
  return data as Gig;
}

export async function deleteGig(id: string) {
  await api.delete(`/gigs/${id}`);
}

export type DirectoryUser = {
  id: string;
  email?: string;
  username?: string;
  fullName?: string;
  roles: string[];
  online?: boolean;
  createdAt?: string | null;
  lastSeenAt?: string | null;
};

export async function listDirectoryUsers(limit = 100) {
  const { data } = await api.get("/users/list", { params: { limit } });
  return {
    total: typeof data?.total === "number" ? data.total : 0,
    users: Array.isArray(data?.users) ? (data.users as DirectoryUser[]) : ([] as DirectoryUser[]),
  };
}

export async function listMyApplications() {
  const { data } = await api.get("/freelancer/proposals");
  return Array.isArray(data) ? (data as Proposal[]) : ([] as Proposal[]);
}

export type FreelancerWorkspaceMonthlyEarning = {
  month: string;
  amount: number;
  projectCount: number;
};

export type FreelancerWorkspaceAnalytics = {
  totalEarnings: number;
  currentBalance: number;
  pendingBalance: number;
  completedProjects: number;
  activeProjects: number;
  totalProposals: number;
  acceptedProposals: number;
  successRate: number;
  rating: number;
  reviewCount: number;
  jobSuccessScore: number;
  monthlyEarnings: FreelancerWorkspaceMonthlyEarning[];
};

export async function getFreelancerWorkspaceAnalytics() {
  const { data } = await api.get("/freelancer/workspace/analytics");
  return data as FreelancerWorkspaceAnalytics;
}

export type EmployerAnalytics = {
  totalProjectsPosted: number;
  activeProjects: number;
  completedProjects: number;
  totalSpent: number;
  averageRating: number;
  totalHired: number;
  repeatHireRate: number;
  topSkillsRequested: string[];
  spendByCategory: Record<string, number>;
  activityOverTime: Array<{
    date?: string;
    count?: number;
    amount?: number;
  }>;
};

export async function getEmployerAnalytics() {
  const { data } = await api.get("/employer/analytics");
  return (data?.data ?? null) as EmployerAnalytics | null;
}

// Contracts
export type Contract = {
  id: string;
  jobId: string;
  employerId: string;
  freelancerId: string;
  status: string;
  escrow?: { totalHeld?: number; currency?: string };
};

export async function listContracts() {
  const { data } = await api.get("/contracts");
  return data as Contract[];
}

export async function getContract(id: string) {
  const { data } = await api.get(`/contracts/${id}`);
  return data as Contract;
}

export async function deliverContract(id: string, input: { note?: string; deliveryAssetId?: string }) {
  const { data } = await api.post(`/contracts/${id}/deliver`, input);
  return data as Contract;
}

export async function completeContract(id: string) {
  const { data } = await api.post(`/contracts/${id}/complete`);
  return data as Contract;
}

// Wallet / Payments
export type WalletTransaction = {
  id: string;
  provider?: string | null;
  direction?: "IN" | "OUT" | null;
  status?: string | null;
  reason?: string | null;
  amount?: number | null;
  currency?: string | null;
  referenceId?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  metadata?: Record<string, unknown> | null;
};

export type WalletSnapshot = {
  userId?: string | null;
  balance: number;
  availableBalance?: number;
  currency: string;
  escrowHeld?: number;
  pendingPayouts?: number;
  holds?: number;
  pendingLocalTopups?: number;
  entries?: Record<string, unknown>[];
  transactions?: WalletTransaction[];
};

export type WalletForecastPoint = {
  key: string;
  label: string;
  projectedNet: number;
  projectedCumulative: number;
  confidenceLower: number;
  confidenceUpper: number;
  confidenceBand: number;
};

export type WalletForecastResponse = {
  points: WalletForecastPoint[];
  source: "backend" | "heuristic";
  model?: string;
  generatedAt?: string;
};

type WalletForecastOptions = {
  range: "7D" | "14D" | "30D" | "90D" | "1Y";
  currency?: string;
  horizon?: number;
  baselineCumulative?: number;
};

function asFinite(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") {
    const parsed = Number(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  return null;
}

function toForecastPoints(payload: unknown, baselineCumulative = 0): WalletForecastPoint[] {
  const record = payload && typeof payload === "object" ? (payload as Record<string, unknown>) : null;
  const collection = Array.isArray(payload)
    ? payload
    : Array.isArray(record?.points)
      ? record?.points
      : Array.isArray(record?.forecast)
        ? record?.forecast
        : record?.forecast && typeof record.forecast === "object" && Array.isArray((record.forecast as Record<string, unknown>).points)
          ? ((record.forecast as Record<string, unknown>).points as unknown[])
          : [];

  let runningCumulative = asFinite(record?.startCumulative) ?? baselineCumulative;

  const points: WalletForecastPoint[] = [];
  collection.forEach((entry, index) => {
    if (!entry || typeof entry !== "object") return;
    const item = entry as Record<string, unknown>;
    const projectedNet =
      asFinite(item.projectedNet) ??
      asFinite(item.net) ??
      asFinite(item.forecastNet) ??
      asFinite(item.predictedNet) ??
      asFinite(item.value);

    if (projectedNet === null) return;

    const key =
      (typeof item.key === "string" && item.key) ||
      (typeof item.date === "string" && item.date) ||
      (typeof item.timestamp === "string" && item.timestamp) ||
      `p-${index + 1}`;

    const label =
      (typeof item.label === "string" && item.label) ||
      (typeof item.period === "string" && item.period) ||
      (typeof item.bucket === "string" && item.bucket) ||
      key;

    const projectedCumulativeCandidate =
      asFinite(item.projectedCumulative) ?? asFinite(item.cumulative) ?? asFinite(item.forecastCumulative);
    const projectedCumulative = projectedCumulativeCandidate ?? runningCumulative + projectedNet;
    runningCumulative = projectedCumulative;

    const confidenceLower =
      asFinite(item.confidenceLower) ??
      asFinite(item.lowerBound) ??
      asFinite(item.lower) ??
      asFinite(item.p10) ??
      projectedNet;

    const confidenceUpper =
      asFinite(item.confidenceUpper) ??
      asFinite(item.upperBound) ??
      asFinite(item.upper) ??
      asFinite(item.p90) ??
      projectedNet;

    const lower = Math.min(confidenceLower, confidenceUpper);
    const upper = Math.max(confidenceLower, confidenceUpper);

    points.push({
      key,
      label,
      projectedNet,
      projectedCumulative,
      confidenceLower: lower,
      confidenceUpper: upper,
      confidenceBand: upper - lower,
    });
  });

  return points;
}

export async function getWallet() {
  const { data } = await api.get(`/wallet`);
  return data as WalletSnapshot;
}

export async function getWalletForecast(options: WalletForecastOptions) {
  const params = {
    range: options.range,
    currency: options.currency,
    horizon: options.horizon,
  };

  // Canonical backend contract: GET /wallet/forecast -> { source, model, generatedAt, points[] }
  const primary = await api.get("/wallet/forecast", { params });
  if (primary.status < 400) {
    const points = toForecastPoints(primary.data, options.baselineCumulative ?? 0);
    if (points.length > 0) {
      const data = primary.data as Record<string, unknown> | null;
      const sourceRaw = typeof data?.source === "string" ? data.source.toLowerCase() : "backend";
      return {
        points,
        source: sourceRaw === "heuristic" ? "heuristic" : "backend",
        model: typeof data?.model === "string" ? data.model : undefined,
        generatedAt: typeof data?.generatedAt === "string" ? data.generatedAt : undefined,
      } satisfies WalletForecastResponse;
    }
  }

  // Backward-compatible fallback shapes/routes.
  const endpoints = ["/wallet/analytics/forecast", "/wallet/projection", "/wallet/analytics/projection"];

  for (const endpoint of endpoints) {
    const response = await api.get(endpoint, { params });
    if (response.status >= 400) {
      continue;
    }

    const points = toForecastPoints(response.data, options.baselineCumulative ?? 0);
    if (points.length > 0) {
      const data = response.data as Record<string, unknown> | null;
      const sourceRaw = typeof data?.source === "string" ? data.source.toLowerCase() : "backend";
      return {
        points,
        source: sourceRaw === "heuristic" ? "heuristic" : "backend",
        model: typeof data?.model === "string" ? data.model : undefined,
        generatedAt: typeof data?.generatedAt === "string" ? data.generatedAt : undefined,
      } satisfies WalletForecastResponse;
    }
  }

  throw new Error("Wallet forecast endpoint unavailable");
}

export async function initChapa(input: { amount: number; currency?: string }, idempotencyKey?: string) {
  const { data } = await api.post(`/payments/chapa/init`, input, { headers: idempotencyKey ? { "Idempotency-Key": idempotencyKey } : undefined });
  return data as {
    transactionId: string;
    providerRef?: string;
    checkoutUrl?: string;
    idempotent?: boolean;
  } & Record<string, any>;
}

export async function localTopupRequest(input: { amount: number; currency?: string; referenceId?: string }, idempotencyKey?: string) {
  const { data } = await api.post(`/payments/local/request`, input, { headers: idempotencyKey ? { "Idempotency-Key": idempotencyKey } : undefined });
  return data as { transactionId: string; status?: string; message?: string };
}

export async function internalWalletTransfer(
  input: { recipient: string; amount: number; currency?: string; note?: string; adminReviewRequired?: boolean },
  idempotencyKey?: string
) {
  const { data } = await api.post(`/payments/internal/transfer`, input, {
    headers: idempotencyKey ? { "Idempotency-Key": idempotencyKey } : undefined,
  });
  return data as {
    ok: boolean;
    transferReference: string;
    transactionId: string;
    amount: number;
    currency: string;
    status?: string;
    senderBalanceAfter?: number;
    recipient: { id: string; email: string; fullName?: string };
    idempotent?: boolean;
  };
}

export type PendingLocalTopup = {
  id: string;
  userId: string;
  amount: number;
  currency: string;
  providerRef?: string;
  status: string;
  createdAt?: string;
  metadata?: Record<string, unknown>;
};

export type AdminPendingInternalTransfer = {
  id: string;
  userId: string;
  provider?: string;
  direction?: "IN" | "OUT";
  amount?: number;
  currency?: string;
  status?: string;
  providerRef?: string;
  metadata?: Record<string, unknown>;
  createdAt?: string;
  updatedAt?: string;
};

export type AdminPaymentTransaction = {
  id: string;
  userId: string;
  senderUserId?: string;
  senderLabel?: string;
  receiverUserId?: string;
  receiverLabel?: string;
  provider?: string;
  direction?: "IN" | "OUT";
  status?: string;
  amount?: number;
  currency?: string;
  providerRef?: string;
  metadata?: Record<string, unknown>;
  createdAt?: string;
  updatedAt?: string;
};

export type AdminWithdrawal = {
  id: string;
  freelancerId?: string;
  userId?: string;
  amount?: string | number;
  amountDecimal?: number;
  currency?: string;
  fee?: string | number;
  netAmount?: string | number;
  paymentMethod?: string;
  accountDetails?: string;
  accountHolderName?: string;
  bankName?: string;
  accountNumber?: string;
  swiftCode?: string;
  routingNumber?: string;
  bankDetails?: Record<string, string>;
  status?: string;
  statusEnum?: string;
  failureReason?: string;
  transactionId?: string;
  referenceNumber?: string;
  requestedAt?: string;
  processedAt?: string;
  completedAt?: string;
  expectedArrivalDate?: string;
  createdAt?: string;
  updatedAt?: string;
  notes?: string;
};

export async function listPendingLocalTopups(options?: { page?: number; size?: number }) {
  const { data } = await api.get(`/admin/payments/local/pending`, {
    params: { page: options?.page ?? 0, size: options?.size ?? 20 },
  });
  return data as {
    content: PendingLocalTopup[];
    totalElements: number;
    totalPages: number;
    number: number;
    size: number;
  };
}

export async function adminReviewLocal(
  input: { transactionId: string; approved?: boolean; note?: string },
  idempotencyKey?: string
) {
  const { data } = await api.post(`/admin/payments/local/verify`, input, {
    headers: idempotencyKey ? { "Idempotency-Key": idempotencyKey } : undefined,
  });
  return data as { ok: boolean; status?: string; walletCredited?: boolean; idempotent?: boolean };
}

export async function adminVerifyLocal(input: { transactionId: string }, idempotencyKey?: string) {
  return adminReviewLocal({ transactionId: input.transactionId, approved: true }, idempotencyKey);
}

export async function adminListPendingInternalTransfers(options?: { page?: number; size?: number }) {
  const { data } = await api.get(`/admin/payments/internal/pending`, {
    params: { page: options?.page ?? 0, size: options?.size ?? 20 },
  });
  return data as {
    content: AdminPendingInternalTransfer[];
    totalElements: number;
    totalPages: number;
    number: number;
    size: number;
  };
}

export async function adminListPaymentTransactions(options?: {
  provider?: string;
  status?: string;
  direction?: string;
  userId?: string;
  query?: string;
  page?: number;
  size?: number;
}) {
  const { data } = await api.get(`/admin/payments/transactions`, {
    params: {
      provider: options?.provider,
      status: options?.status,
      direction: options?.direction,
      userId: options?.userId,
      query: options?.query,
      page: options?.page ?? 0,
      size: options?.size ?? 20,
    },
  });
  return data as {
    content: AdminPaymentTransaction[];
    totalElements: number;
    totalPages: number;
    number: number;
    size: number;
    generatedAt?: string;
  };
}

export async function adminReviewInternalTransfer(id: string, input: { approved?: boolean; note?: string }) {
  const { data } = await api.post(`/admin/payments/internal/${id}/review`, input);
  return data as {
    ok: boolean;
    transactionId: string;
    status: string;
    message?: string;
    transferReference?: string;
    amount?: number;
    currency?: string;
    senderBalanceAfter?: number;
    recipientBalanceAfter?: number;
    idempotent?: boolean;
  };
}

export async function adminListWithdrawals(options?: { status?: string; page?: number; size?: number }) {
  const { data } = await api.get(`/admin/withdrawals`, {
    params: {
      status: options?.status ?? "PENDING,PROCESSING",
      page: options?.page ?? 0,
      size: options?.size ?? 20,
    },
  });
  return data as {
    content: AdminWithdrawal[];
    totalElements: number;
    totalPages: number;
    number: number;
    size: number;
  };
}

export async function adminUpdateWithdrawal(id: string, input: { status: string; note?: string }) {
  const { data } = await api.patch(`/admin/withdrawals/${id}`, input);
  return data as AdminWithdrawal;
}

export async function adminWalletTopup(input: { userId: string; amount: number; currency?: string }) {
  const { data } = await api.post(`/v2/wallet/topup`, input);
  return data as { message: string; transactionId: string; amount: number; newBalance: number };
}

export async function adminWalletAdjust(input: {
  userId: string;
  amount: number;
  currency?: string;
  action: "COMMIT" | "ROLLBACK";
  note?: string;
}) {
  const { data } = await api.post(`/admin/wallet/adjust`, input);
  return data as { message: string; transactionId: string; action: "COMMIT" | "ROLLBACK"; amount: number; newBalance: number };
}

// Escrow
export async function escrowFund(input: { contractId: string; amount: number; currency?: string }) {
  const { data } = await api.post(`/escrow/fund`, input);
  return data as Contract;
}

export async function escrowRelease(input: { contractId: string; amount: number; platformFeeAmount?: number }) {
  const { data } = await api.post(`/escrow/release`, input);
  return data as Contract;
}

export async function escrowRefund(input: { contractId: string; amount: number }) {
  const { data } = await api.post(`/escrow/refund`, input);
  return data as Contract;
}

// Assets
export type Asset = {
  id: string;
  url: string;
  downloadUrl?: string;
  scope: string;
  resourceType: string;
  mimeType?: string;
  size?: number;
};

export async function listAssets() {
  const { data } = await api.get(`/assets`);
  return data as Asset[];
}

export async function getAsset(id: string) {
  const { data } = await api.get(`/assets/${id}`);
  return data as Asset;
}

export async function uploadSignature(params: Record<string, any>) {
  const { data } = await api.post(`/assets/signature`, params);
  return data as any;
}

export async function saveAssetMetadata(body: { scope: string; title?: string; secureUrl: string; publicId: string; resourceType?: string; mimeType?: string; size?: number }) {
  const { data } = await api.post(`/assets`, body);
  return data as Asset;
}

export async function deleteAsset(id: string) {
  const { data } = await api.delete(`/assets/${id}`);
  return data as { ok: boolean };
}

// Chat
export type ChatThread = {
  id: string;
  participantIds: string[];
  threadType?: "DIRECT" | "GROUP" | "CHANNEL";
  groupName?: string;
  channelDescription?: string;
  ownerUserId?: string;
  memberMessagingEnabled?: boolean;
  lastMessageAt?: string;
  lastMessage?: string;
  lastMessageSenderId?: string;
  unreadCount?: number;
};
export type ChatMessage = { id: string; threadId: string; senderId: string; type: "TEXT" | "ASSET"; text?: string; assetId?: string; createdAt?: string };
export type AppNotification = {
  id: string;
  userId: string;
  type: string;
  payload?: Record<string, unknown>;
  read: boolean;
  createdAt?: string;
};

function asChatThreadOrThrow(payload: unknown, fallbackMessage: string) {
  if (
    payload &&
    typeof payload === "object" &&
    typeof (payload as { id?: unknown }).id === "string" &&
    Array.isArray((payload as { participantIds?: unknown }).participantIds)
  ) {
    return payload as ChatThread;
  }

  const message =
    payload &&
    typeof payload === "object" &&
    typeof (payload as { message?: unknown }).message === "string"
      ? (payload as { message: string }).message
      : fallbackMessage;

  throw new Error(message);
}

export async function listThreads() {
  const { data } = await api.get(`/chat/threads`);
  return data as ChatThread[];
}

export async function createThread(input: {
  participantIds: string[];
  threadType?: "DIRECT" | "GROUP" | "CHANNEL";
  groupName?: string;
  channelDescription?: string;
  memberMessagingEnabled?: boolean;
}) {
  const { data } = await api.post(`/chat/threads`, input);
  return asChatThreadOrThrow(data, "Failed to create chat thread.");
}

export async function listMessages(threadId: string) {
  const { data } = await api.get(`/chat/threads/${threadId}/messages`);
  return data as ChatMessage[];
}

export async function sendMessage(threadId: string, message: { type: "TEXT" | "ASSET"; text?: string; assetId?: string }) {
  const { data } = await api.post(`/chat/threads/${threadId}/messages`, message);
  return data as ChatMessage;
}

export async function markThreadRead(threadId: string) {
  const { data } = await api.post(`/chat/threads/${threadId}/read`);
  return asChatThreadOrThrow(data, "Failed to update chat thread.");
}

// Notifications
export async function listNotifications() {
  const { data } = await api.get(`/notifications`);
  return Array.isArray(data) ? (data as AppNotification[]) : [];
}

export async function markNotificationRead(id: string) {
  const { data } = await api.post(`/notifications/${id}/read`);
  return data as AppNotification;
}

export async function markAllNotificationsRead() {
  const { data } = await api.post(`/notifications/read-all`);
  return data as { updated: number };
}

// Disputes
export type Dispute = {
  id: string;
  contractId: string;
  openedByUserId?: string;
  status: string;
  reason?: string;
  adminNotes?: string[];
  evidenceAssetIds?: string[];
  createdAt?: string;
  updatedAt?: string;
};

export async function openDispute(input: { contractId: string; reason?: string; evidenceAssetIds?: string[] }) {
  const { data } = await api.post(`/disputes`, input);
  return data as Dispute;
}

export async function listDisputes() {
  const { data } = await api.get(`/disputes`);
  return data as Dispute[];
}

export async function adminPatchDispute(id: string, body: { status?: string; adminNote?: string }) {
  const { data } = await api.patch(`/admin/disputes/${id}`, body);
  return data as Dispute;
}

// Content
export type ContentItem = {
  id: string;
  type: string;
  slug?: string;
  title: string;
  body: string;
  status: string;
  mediaAssetIds?: string[];
  createdAt?: string;
  updatedAt?: string;
};

export async function listContent(type = "FAQ") {
  const { data } = await api.get(`/content`, { params: { type } });
  return data as ContentItem[];
}

export async function adminListContent(options?: { type?: string; status?: string }) {
  const { data } = await api.get(`/admin/content`, {
    params: {
      type: options?.type,
      status: options?.status,
    },
  });
  return data as ContentItem[];
}

export async function adminCreateContent(item: Partial<ContentItem>) {
  const { data } = await api.post(`/admin/content`, item);
  return data as ContentItem;
}

export async function adminUpdateContent(id: string, patch: Partial<ContentItem>) {
  const { data } = await api.patch(`/admin/content/${id}`, patch);
  return data as ContentItem;
}

// Admin Users
export type AppUser = {
  id: string;
  email: string;
  username?: string;
  fullName: string;
  roles: string[];
  suspended?: boolean;
  documentsVerified?: boolean;
  createdAt?: string;
  lastSeenAt?: string;
  online?: boolean;
  accountType?: string;
  companyName?: string | null;
  employerKycStatus?: string | null;
  freelancerVerificationStatus?: string | null;
  identity?: {
    status: string;
    emailVerified: boolean;
    phoneVerified: boolean;
    documentVerified: boolean;
    reviewNote?: string | null;
    kycMethod?: string | null;
    verifiedBy?: string | null;
    verifiedAt?: string | null;
  };
  access?: {
    accessLevel: string;
    accessScope: string;
    permissions: string[];
    privilegeNote?: string | null;
    elevatedUntil?: string | null;
    roleVersion?: string | null;
  };
  security?: {
    mfaRequired: boolean;
    mfaEnabled: boolean;
    oauthEnabled: boolean;
    ssoEnabled: boolean;
    adaptiveAuthEnabled: boolean;
    forcePasswordReset: boolean;
    banned: boolean;
    riskLevel: string;
    riskReason?: string | null;
    failedLoginAttempts: number;
    passwordUpdatedAt?: string | null;
    lastCredentialResetAt?: string | null;
    credentialResetChannel?: string | null;
    lastWarningAt?: string | null;
    blacklistedIps: string[];
    blacklistedDevices: string[];
  };
  warnings?: Array<{
    id: string;
    severity: string;
    reason: string;
    note?: string | null;
    status: string;
    issuedBy?: string | null;
    issuedAt?: string | null;
    resolvedAt?: string | null;
    resolutionNote?: string | null;
  }>;
};

export type AdminIdentityRoleDefinition = {
  id: string;
  key: string;
  label: string;
  description?: string | null;
  systemRole: boolean;
  version: number;
  inherits: string[];
  permissions: string[];
  assignedUsers: number;
};

export type AdminIdentityPolicySummary = {
  passwordPolicy: {
    minLength: number;
    requireUppercase: boolean;
    requireLowercase: boolean;
    requireNumber: boolean;
    requireSymbol: boolean;
    expiryDays: number;
    passwordReuseLimit: number;
  };
  authenticationPolicy: {
    mfaRequiredForAdmins: boolean;
    oauthEnabled: boolean;
    ssoEnabled: boolean;
    adaptiveAuthEnabled: boolean;
    zeroTrustEnabled: boolean;
    abacEnabled: boolean;
    rateLimitPerMinute: number;
    maxFailedLoginAttempts: number;
    sessionTimeoutMinutes: number;
  };
  governancePolicy: {
    leastPrivilegeEnforced: boolean;
    auditTrailEnabled: boolean;
    anomalyAlertsEnabled: boolean;
    automatedProvisioningEnabled: boolean;
  };
  updatedAt?: string;
};

export type AdminIdentityWorkspace = {
  generatedAt: string;
  metrics: Array<{
    key: string;
    label: string;
    value: string;
    tone: string;
  }>;
  activityTrend: Array<{
    month: string;
    newUsers: number;
    activeUsers: number;
    credentialResets: number;
    suspensions: number;
  }>;
  roleDistribution: Array<{
    label: string;
    value: number;
    tone: string;
  }>;
  verificationDistribution: Array<{
    label: string;
    value: number;
    tone: string;
  }>;
  stateDistribution: Array<{
    label: string;
    value: number;
    tone: string;
  }>;
  users: AppUser[];
  roles: AdminIdentityRoleDefinition[];
  policies: AdminIdentityPolicySummary;
  alerts: Array<{
    key: string;
    title: string;
    detail: string;
    severity: string;
    userId?: string | null;
    actionHint?: string | null;
  }>;
  auditTrail: Array<{
    id: string;
    action: string;
    entityType?: string | null;
    entityId?: string | null;
    actorUserId?: string | null;
    createdAt?: string | null;
    metadata?: Record<string, unknown>;
  }>;
};

export type AdminCreateUserInput = {
  email: string;
  username?: string;
  fullName: string;
  password: string;
  roles: string[];
  suspended?: boolean;
  documentsVerified?: boolean;
};

export type AdminUpdateUserInput = Partial<AppUser> & {
  password?: string;
  roles?: string[];
};

export async function adminListUsers() {
  const { data } = await api.get(`/admin/users`);
  return data as AppUser[];
}

export async function adminUsersWorkspace() {
  const { data } = await api.get(`/admin/users/workspace`);
  return data as AdminIdentityWorkspace;
}

export async function adminPatchUser(id: string, patch: AdminUpdateUserInput) {
  const { data } = await api.patch(`/admin/users/${id}`, patch);
  return data as AppUser;
}

export async function adminCreateUser(input: AdminCreateUserInput) {
  const { data } = await api.post(`/admin/users`, input);
  return data as AppUser;
}

export async function adminDeleteUser(id: string) {
  const { data } = await api.delete(`/admin/users/${id}`);
  return data as { deleted: boolean; id: string };
}

export async function adminGrantUserRole(id: string, role: string) {
  const { data } = await api.post(`/admin/users/${id}/roles/grant`, { role });
  return data as AppUser;
}

export async function adminRevokeUserRole(id: string, role: string) {
  const { data } = await api.post(`/admin/users/${id}/roles/revoke`, { role });
  return data as AppUser;
}

export async function adminCreateRoleDefinition(input: {
  key: string;
  label: string;
  description?: string;
  inherits?: string[];
  permissions?: string[];
}) {
  const { data } = await api.post(`/admin/users/roles`, input);
  return data as AdminIdentityRoleDefinition;
}

export async function adminUpdateRoleDefinition(id: string, patch: {
  label?: string;
  description?: string;
  inherits?: string[];
  permissions?: string[];
}) {
  const { data } = await api.patch(`/admin/users/roles/${id}`, patch);
  return data as AdminIdentityRoleDefinition;
}

export async function adminApplyUserAccessControl(id: string, patch: {
  accessLevel?: string;
  accessScope?: string;
  permissions?: string[];
  privilegeNote?: string;
  elevatedUntil?: string | null;
  mfaRequired?: boolean;
  mfaEnabled?: boolean;
  oauthEnabled?: boolean;
  ssoEnabled?: boolean;
  adaptiveAuthEnabled?: boolean;
  forcePasswordReset?: boolean;
  riskLevel?: string;
  riskReason?: string;
  failedLoginAttempts?: number;
}) {
  const { data } = await api.post(`/admin/users/${id}/access-control`, patch);
  return data as AppUser;
}

export async function adminReviewUserIdentity(id: string, patch: {
  emailVerified?: boolean;
  phoneVerified?: boolean;
  documentVerified?: boolean;
  status?: string;
  reviewNote?: string;
  kycMethod?: string;
}) {
  const { data } = await api.post(`/admin/users/${id}/identity-verification`, patch);
  return data as AppUser;
}

export async function adminResetUserCredentials(id: string, input: {
  newPassword?: string;
  forceReset?: boolean;
  channel?: string;
}) {
  const { data } = await api.post(`/admin/users/${id}/credential-reset`, input);
  return data as AppUser;
}

export async function adminIssueUserWarning(id: string, input: {
  severity?: string;
  reason: string;
  note?: string;
  suspendUser?: boolean;
}) {
  const { data } = await api.post(`/admin/users/${id}/warnings`, input);
  return data as AppUser;
}

export async function adminResolveUserWarning(id: string, warningId: string, input?: { note?: string }) {
  const { data } = await api.post(`/admin/users/${id}/warnings/${warningId}/resolve`, input ?? {});
  return data as AppUser;
}

export async function adminHandleMaliciousUser(id: string, input: {
  action?: string;
  reason: string;
  ipAddresses?: string[];
  deviceIds?: string[];
}) {
  const { data } = await api.post(`/admin/users/${id}/malicious-control`, input);
  return data as AppUser;
}

export async function adminUpdateIdentityPolicies(input: {
  passwordPolicy?: AdminIdentityPolicySummary["passwordPolicy"];
  authenticationPolicy?: AdminIdentityPolicySummary["authenticationPolicy"];
  governancePolicy?: AdminIdentityPolicySummary["governancePolicy"];
}) {
  const { data } = await api.post(`/admin/users/policies`, input);
  return data as AdminIdentityPolicySummary;
}

// Admin Tenants
export type AdminTenantQuota = {
  maxActiveProjects?: number;
  maxTeamMembers?: number;
  storageLimitGb?: number;
  apiRateLimitPerMinute?: number;
};

export type AdminTenantBilling = {
  plan?: string;
  status?: string;
  model?: string;
  billingEmail?: string;
  currency?: string;
  provider?: string;
  accountId?: string;
  renewalDate?: string;
};

export type AdminTenantMigration = {
  status?: string;
  targetRegion?: string;
  note?: string;
  requestedAt?: string;
  completedAt?: string;
};

export type AdminTenantEnvironment = {
  deploymentMode?: string;
  namespace?: string;
  cluster?: string;
  region?: string;
  infrastructureProvider?: string;
  computeProfile?: string;
  storageProfile?: string;
  networkSegment?: string;
  environmentTemplate?: string;
  status?: string;
  autoScalingEnabled?: boolean;
  selfServiceOnboardingEnabled?: boolean;
  provisionedAt?: string;
};

export type AdminTenantUsage = {
  cpuCoresUsed?: number;
  memoryGbUsed?: number;
  storageGbUsed?: number;
  apiRequestsCurrentPeriod?: number;
  bandwidthMbpsUsed?: number;
  anomalyStatus?: string;
  anomalyScore?: number;
  lastCollectedAt?: string;
};

export type AdminTenantResourceLimits = {
  softCpuCores?: number;
  hardCpuCores?: number;
  softMemoryGb?: number;
  hardMemoryGb?: number;
  softStorageGb?: number;
  hardStorageGb?: number;
  softBandwidthMbps?: number;
  hardBandwidthMbps?: number;
  throttlingEnabled?: boolean;
  autoScaleEnabled?: boolean;
};

export type AdminTenantPermissionProfile = {
  accessModel?: string;
  adminRoles?: string[];
  permissions?: string[];
  isolationEnforced?: boolean;
};

export type AdminTenantIsolationProfile = {
  databaseIsolationMode?: string;
  networkPolicy?: string;
  encryptionAtRest?: boolean;
  encryptionInTransit?: boolean;
  crossTenantViolationCount?: number;
  securityPolicy?: string;
};

export type AdminTenantSuspension = {
  status?: string;
  reason?: string;
  note?: string;
  suspendedAt?: string;
  resumedAt?: string;
};

export type AdminTenantSummary = {
  id: string;
  userId?: string;
  ownerName: string;
  ownerEmail?: string;
  ownerUsername?: string;
  companyName: string;
  companyWebsite?: string;
  industry?: string;
  country?: string;
  employeeCount?: number;
  tier?: string;
  active: boolean;
  ownerSuspended?: boolean;
  businessVerified?: boolean;
  paymentVerified?: boolean;
  kycStatus?: string;
  totalProjects?: number;
  openProjects?: number;
  totalJobs?: number;
  activeContracts?: number;
  totalSpent?: number;
  quota?: AdminTenantQuota;
  billing?: AdminTenantBilling;
  migration?: AdminTenantMigration;
  environment?: AdminTenantEnvironment;
  usage?: AdminTenantUsage;
  resourceLimits?: AdminTenantResourceLimits;
  permissionProfile?: AdminTenantPermissionProfile;
  isolationProfile?: AdminTenantIsolationProfile;
  suspension?: AdminTenantSuspension;
  ownerCreatedAt?: string;
  updatedAt?: string;
};

export type AdminTenantWorkspaceResponse = {
  generatedAt?: string;
  tenants: AdminTenantSummary[];
};

export type AdminTenantOperationsWorkspace = {
  generatedAt?: string;
  metrics: Array<{
    key: string;
    label: string;
    value: string;
    tone: string;
  }>;
  lifecycleDistribution: Array<{
    label: string;
    value: number;
    tone: string;
  }>;
  billingDistribution: Array<{
    label: string;
    value: number;
    tone: string;
  }>;
  usageSnapshots: Array<{
    tenantId: string;
    tenantName: string;
    cpuCoresUsed: number;
    memoryGbUsed: number;
    storageGbUsed: number;
    apiRequestsCurrentPeriod: number;
    bandwidthMbpsUsed: number;
  }>;
  alerts: Array<{
    key: string;
    title: string;
    detail: string;
    severity: string;
    tenantId?: string;
    actionHint?: string;
  }>;
  auditTrail: Array<{
    id: string;
    action: string;
    entityType?: string;
    entityId?: string;
    actorUserId?: string;
    createdAt?: string;
  }>;
  tenants: AdminTenantSummary[];
};

export type AdminCreateTenantInput = {
  ownerFullName: string;
  ownerEmail: string;
  ownerUsername?: string;
  ownerPassword: string;
  companyName: string;
  companyWebsite?: string;
  industry?: string;
  country?: string;
  employeeCount?: number;
  tier?: string;
  plan?: string;
  billingModel?: string;
  billingEmail?: string;
  billingCurrency?: string;
  billingProvider?: string;
  billingAccountId?: string;
  maxActiveProjects?: number;
  maxTeamMembers?: number;
  storageLimitGb?: number;
  apiRateLimitPerMinute?: number;
};

export type AdminUpdateTenantInput = {
  ownerFullName?: string;
  ownerEmail?: string;
  ownerUsername?: string;
  companyName?: string;
  companyWebsite?: string;
  industry?: string;
  country?: string;
  employeeCount?: number;
  tier?: string;
  active?: boolean;
  businessVerified?: boolean;
  paymentVerified?: boolean;
  kycStatus?: string;
  verificationNote?: string;
  plan?: string;
  billingStatus?: string;
  billingModel?: string;
  billingEmail?: string;
  billingCurrency?: string;
  billingProvider?: string;
  billingAccountId?: string;
  renewalDate?: string;
  maxActiveProjects?: number;
  maxTeamMembers?: number;
  storageLimitGb?: number;
  apiRateLimitPerMinute?: number;
};

export async function adminListTenants() {
  const { data } = await api.get(`/admin/tenants`);
  return data as AdminTenantWorkspaceResponse;
}

export async function adminTenantWorkspace() {
  const { data } = await api.get(`/admin/tenants/workspace`);
  return data as AdminTenantOperationsWorkspace;
}

export async function adminCreateTenant(input: AdminCreateTenantInput) {
  const { data } = await api.post(`/admin/tenants`, input);
  return data as AdminTenantSummary;
}

export async function adminPatchTenant(id: string, patch: AdminUpdateTenantInput) {
  const { data } = await api.patch(`/admin/tenants/${id}`, patch);
  return data as AdminTenantSummary;
}

export async function adminMigrateTenant(id: string, input: { targetRegion: string; note?: string }) {
  const { data } = await api.post(`/admin/tenants/${id}/migrate`, input);
  return data as AdminTenantSummary;
}

export async function adminDeleteTenant(id: string) {
  const { data } = await api.delete(`/admin/tenants/${id}`);
  return data as AdminTenantSummary;
}

export async function adminProvisionTenantEnvironment(id: string, input: {
  deploymentMode?: string;
  namespace?: string;
  cluster?: string;
  region?: string;
  infrastructureProvider?: string;
  computeProfile?: string;
  storageProfile?: string;
  networkSegment?: string;
  environmentTemplate?: string;
  autoScalingEnabled?: boolean;
  selfServiceOnboardingEnabled?: boolean;
}) {
  const { data } = await api.post(`/admin/tenants/${id}/environment`, input);
  return data as AdminTenantSummary;
}

export async function adminConfigureTenantLimits(id: string, input: {
  softCpuCores?: number;
  hardCpuCores?: number;
  softMemoryGb?: number;
  hardMemoryGb?: number;
  softStorageGb?: number;
  hardStorageGb?: number;
  softBandwidthMbps?: number;
  hardBandwidthMbps?: number;
  throttlingEnabled?: boolean;
  autoScaleEnabled?: boolean;
}) {
  const { data } = await api.post(`/admin/tenants/${id}/limits`, input);
  return data as AdminTenantSummary;
}

export async function adminUpdateTenantPermissions(id: string, input: {
  accessModel?: string;
  adminRoles?: string[];
  permissions?: string[];
  isolationEnforced?: boolean;
}) {
  const { data } = await api.post(`/admin/tenants/${id}/permissions`, input);
  return data as AdminTenantSummary;
}

export async function adminUpdateTenantIsolation(id: string, input: {
  databaseIsolationMode?: string;
  networkPolicy?: string;
  encryptionAtRest?: boolean;
  encryptionInTransit?: boolean;
  crossTenantViolationCount?: number;
  securityPolicy?: string;
}) {
  const { data } = await api.post(`/admin/tenants/${id}/isolation`, input);
  return data as AdminTenantSummary;
}

export async function adminChangeTenantLifecycle(id: string, input: {
  action?: string;
  reason: string;
  note?: string;
}) {
  const { data } = await api.post(`/admin/tenants/${id}/lifecycle`, input);
  return data as AdminTenantSummary;
}

export async function adminRefreshTenantUsage(id: string) {
  const { data } = await api.post(`/admin/tenants/${id}/usage-refresh`);
  return data as AdminTenantSummary;
}

// Admin Jobs
export async function adminListJobs(status?: string) {
  const { data } = await api.get(`/admin/jobs`, { params: status ? { status } : undefined });
  return data as Job[];
}

export async function adminPatchJob(id: string, patch: Partial<Job>) {
  const { data } = await api.patch(`/admin/jobs/${id}`, patch);
  return data as Job;
}

// Admin Proposals
export async function adminListProposals(status?: string) {
  const { data } = await api.get(`/admin/proposals`, { params: status ? { status } : undefined });
  return data as Proposal[];
}

export async function adminPatchProposal(id: string, patch: Partial<Proposal>) {
  const { data } = await api.patch(`/admin/proposals/${id}`, patch);
  return data as Proposal;
}

// Admin Analytics
export async function adminAnalyticsSummary() {
  const { data } = await api.get(`/admin/analytics/summary`);
  return data as { users: number; jobs: number; revenue: number; disputesOpen: number };
}

export async function adminAnalyticsDaily() {
  const { data } = await api.get(`/admin/analytics/daily`);
  return data as { dates: string[]; users: number[]; jobs: number[]; revenue: number[] };
}

export type AdminAnalyticsMetricCard = {
  id: string;
  label: string;
  value: string;
  helper: string;
  tone: string;
};

export type AdminAnalyticsTrendPoint = {
  period: string;
  users: number;
  jobs: number;
  proposals: number;
  hires: number;
  revenue: number;
};

export type AdminAnalyticsBreakdownItem = {
  label: string;
  value: number;
  helper: string;
};

export type AdminAnalyticsRevenueSlice = {
  label: string;
  value: number;
  transactions: number;
};

export type AdminAnalyticsInsightItem = {
  title: string;
  detail: string;
  tone: string;
};

export type AdminAnalyticsAiStatus = {
  engine: string;
  version: string;
  mode: string;
  inferenceMode: string;
  pythonBridgeReachable: boolean;
  pythonJobsEnabled: boolean;
  pythonFreelancersEnabled: boolean;
  pythonFraudEnabled: boolean;
  pythonChatEnabled: boolean;
  blendJobs: number;
  blendFreelancers: number;
  blendFraud: number;
  blendChat: number;
};

export type AdminAnalyticsWorkspaceResponse = {
  generatedAt: string;
  windowDays: number;
  headlineMetrics: AdminAnalyticsMetricCard[];
  trend: AdminAnalyticsTrendPoint[];
  roleDistribution: AdminAnalyticsBreakdownItem[];
  hiringFunnel: AdminAnalyticsBreakdownItem[];
  jobStatusBreakdown: AdminAnalyticsBreakdownItem[];
  proposalStatusBreakdown: AdminAnalyticsBreakdownItem[];
  topCategories: AdminAnalyticsBreakdownItem[];
  revenueByProvider: AdminAnalyticsRevenueSlice[];
  engagementMetrics: AdminAnalyticsMetricCard[];
  operationsMetrics: AdminAnalyticsMetricCard[];
  insights: AdminAnalyticsInsightItem[];
  aiStatus: AdminAnalyticsAiStatus;
};

export type AdminAnalyticsReportSection = {
  id: string;
  title: string;
  highlights: string[];
};

export type AdminAnalyticsExecutiveReportResponse = {
  generatedAt: string;
  windowDays: number;
  title: string;
  summary: string;
  headlineMetrics: AdminAnalyticsMetricCard[];
  sections: AdminAnalyticsReportSection[];
  insights: AdminAnalyticsInsightItem[];
  aiStatus: AdminAnalyticsAiStatus;
};

export type AdminAnalyticsExportBundle = {
  generatedAt: string;
  windowDays: number;
  workspace: AdminAnalyticsWorkspaceResponse;
  report: AdminAnalyticsExecutiveReportResponse;
};

export async function adminAnalyticsWorkspace(days = 30) {
  const { data } = await api.get(`/admin/analytics/workspace`, { params: { days } });
  return data as AdminAnalyticsWorkspaceResponse;
}

export async function adminGenerateExecutiveReport(days = 30) {
  const { data } = await api.post(`/admin/analytics/reports/executive`, undefined, { params: { days } });
  return data as AdminAnalyticsExecutiveReportResponse;
}

export async function adminAnalyticsExportJson(days = 30) {
  const { data } = await api.get(`/admin/analytics/export/json`, { params: { days } });
  return data as AdminAnalyticsExportBundle;
}

export async function adminAnalyticsExportCsv(days = 30) {
  const { data } = await api.get(`/admin/analytics/export/csv`, {
    params: { days },
    responseType: "text",
  });
  return data as string;
}

// Admin Announcements
export async function adminBroadcast(message: string) {
  const { data } = await api.post(`/admin/announcements`, { message });
  return data as { ok: boolean };
}

// Enterprise Admin Command Center
export type AdminCommandCenterMetricCard = {
  id: string;
  label: string;
  value: string;
  trend: string;
  tone: string;
};

export type AdminCommandCenterAlert = {
  id: string;
  level: string;
  title: string;
  detail: string;
};

export type AdminCommandCenterDomainSummary = {
  id: string;
  title: string;
  description: string;
  route: string;
  responsibilitiesCount: number;
  status: string;
};

export type AdminCommandCenterOperation = {
  id: string;
  title: string;
  description: string;
  impact: string;
  status: string;
};

export type AdminCommandCenterDomain = {
  id: string;
  title: string;
  description: string;
  route: string;
  responsibilities: string[];
  operations: AdminCommandCenterOperation[];
  status: string;
  owner: string;
};

export type AdminCommandCenterFeatureFlag = {
  key: string;
  enabled: boolean;
  owner: string;
  description: string;
  updatedAt: string;
};

export type AdminCommandCenterOverviewResponse = {
  generatedAt: string;
  metrics: AdminCommandCenterMetricCard[];
  alerts: AdminCommandCenterAlert[];
  domains: AdminCommandCenterDomainSummary[];
  featureFlags: AdminCommandCenterFeatureFlag[];
};

export type AdminCommandCenterDomainResponse = {
  generatedAt: string;
  domain: AdminCommandCenterDomain;
  metrics: AdminCommandCenterMetricCard[];
  alerts: AdminCommandCenterAlert[];
  featureFlags: AdminCommandCenterFeatureFlag[];
};

export type AdminCommandCenterCapabilityGroup = {
  id: string;
  title: string;
  objective: string;
  responsibilities: string[];
  operations: AdminCommandCenterOperation[];
  status: string;
  owner: string;
};

export type AdminPlatformControlResponse = {
  generatedAt: string;
  title: string;
  objective: string;
  metrics: AdminCommandCenterMetricCard[];
  capabilityGroups: AdminCommandCenterCapabilityGroup[];
  alerts: AdminCommandCenterAlert[];
  featureFlags: AdminCommandCenterFeatureFlag[];
};

export type AdminThreatDistribution = {
  label: string;
  value: number;
  tone: string;
};

export type AdminThreatTrendPoint = {
  period: string;
  threats: number;
  baseline: number;
};

export type AdminComplianceGauge = {
  id: string;
  label: string;
  value: number;
  tone: string;
};

export type AdminSecurityGovernanceResponse = {
  generatedAt: string;
  title: string;
  objective: string;
  metrics: AdminCommandCenterMetricCard[];
  capabilityGroups: AdminCommandCenterCapabilityGroup[];
  topThreats: AdminThreatDistribution[];
  monthlyThreats: AdminThreatTrendPoint[];
  complianceGauges: AdminComplianceGauge[];
  alerts: AdminCommandCenterAlert[];
  featureFlags: AdminCommandCenterFeatureFlag[];
};

export type AdminSectionSignal = {
  label: string;
  value: string;
  trend: string;
};

export type AdminSectionInsightResponse = {
  generatedAt: string;
  parentKey: string;
  sectionKey: string;
  sectionLabel: string;
  status: string;
  statusNote: string;
  signals: AdminSectionSignal[];
  actions: string[];
  checklist: string[];
};

export async function adminCommandCenterOverview() {
  const { data } = await api.get(`/admin/command-center/overview`);
  return data as AdminCommandCenterOverviewResponse;
}

export async function adminCommandCenterDomains() {
  const { data } = await api.get(`/admin/command-center/domains`);
  return data as AdminCommandCenterDomain[];
}

export async function adminCommandCenterDomain(domainId: string) {
  const { data } = await api.get(`/admin/command-center/domains/${domainId}`);
  return data as AdminCommandCenterDomainResponse;
}

export async function adminCommandCenterFeatureFlags() {
  const { data } = await api.get(`/admin/command-center/feature-flags`);
  return data as AdminCommandCenterFeatureFlag[];
}

export async function adminPlatformControl() {
  const { data } = await api.get(`/admin/command-center/core/platform-control`);
  return data as AdminPlatformControlResponse;
}

export async function adminSecurityGovernance() {
  const { data } = await api.get(`/admin/command-center/core/security-governance`);
  return data as AdminSecurityGovernanceResponse;
}

export async function adminSectionInsight(parentKey: string, sectionKey: string) {
  const { data } = await api.get(`/admin/command-center/sections/${encodeURIComponent(parentKey)}/${encodeURIComponent(sectionKey)}`);
  return data as AdminSectionInsightResponse;
}

export async function adminCommandCenterUpdateFeatureFlag(
  key: string,
  body: Partial<Pick<AdminCommandCenterFeatureFlag, "enabled" | "owner" | "description">>,
) {
  const { data } = await api.patch(`/admin/command-center/feature-flags/${key}`, body);
  return data as AdminCommandCenterFeatureFlag;
}

export async function adminCommandCenterExecuteOperation(
  domainId: string,
  operationId: string,
  body?: { note?: string; dryRun?: boolean; parameters?: Record<string, unknown> },
) {
  const { data } = await api.post(`/admin/command-center/domains/${domainId}/operations/${operationId}`, body ?? {});
  return data as AdminCommandCenterOperation;
}

// AI features
export type AIJobRecommendation = {
  jobId: string;
  title: string;
  score: number;
  budgetMin?: number;
  budgetMax?: number;
  currency?: string;
  reasons: string[];
};

export type AIFreelancerMatch = {
  freelancerId: string;
  userId?: string;
  professionalTitle?: string;
  score: number;
  reasons: string[];
  jobId: string;
};

export type AIFraudRisk = {
  riskScore: number;
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
  flags: string[];
  currency: string;
  recommendedAction: string;
};

export type AIChatbotResponse = {
  answer: string;
  contextType: string;
  contextId?: string;
  suggestedActions: string[];
  confidence: number;
  engine?: string;
  engineVersion?: string;
  inferenceMode?: string;
  externalAiApiUsed?: boolean;
};

export type AIEngineStatus = {
  engine: string;
  version: string;
  inferenceMode: string;
  externalAiApiEnabled: boolean;
  externalAiApiUsed: boolean;
  dataSource: string;
  message: string;
};

export type AIModelRelease = {
  version: string;
  path?: string;
  trainedAt?: string;
  trainingSummary?: Record<string, unknown>;
};

export type AIModelVersionsResponse = {
  ok: boolean;
  activeVersion?: string;
  versions: AIModelRelease[];
  count?: number;
  message?: string;
};

export type AIModelOperationResponse = {
  ok: boolean;
  message?: string;
  activeVersion?: string;
  previousVersion?: string;
  release?: AIModelRelease;
  requestedBy?: string;
  requestedAt?: string;
  steps?: number;
  returncode?: number;
  stdout?: string;
  stderr?: string;
};

export type AIDatasetStats = {
  totalRecords: number;
  jobsRecords: number;
  freelancersRecords: number;
  transactionsRecords: number;
  genericRecords: number;
  mode?: string;
};

export type AIDatasetImportResponse = {
  ok: boolean;
  batchId?: string;
  datasetType?: string;
  format?: string;
  sourcePath?: string;
  importedRows?: number;
  engineMode?: string;
  message?: string;
};

export async function aiRecommendJobs(limit = 8) {
  const { data } = await api.get(`/ai/recommend/jobs`, { params: { limit } });
  return data as AIJobRecommendation[];
}

export async function aiEngineStatus() {
  const { data } = await api.get(`/ai/engine/status`);
  return data as AIEngineStatus;
}

export async function aiMatchFreelancers(jobId: string, limit = 10) {
  const { data } = await api.get(`/ai/match/freelancers/${jobId}`, { params: { limit } });
  return data as AIFreelancerMatch[];
}

export async function aiCheckFraudRisk(input: {
  amount: number;
  currency?: string;
  paymentMethod?: string;
  recipientCountry?: string;
}) {
  const { data } = await api.post(`/ai/fraud/check`, input);
  return data as AIFraudRisk;
}

export async function aiChatbotAssist(input: {
  prompt: string;
  contextType?: string;
  contextId?: string;
}) {
  const { data } = await api.post(`/ai/chatbot/assist`, input);
  return data as AIChatbotResponse;
}

export async function aiTrainModel(activate = true) {
  const { data } = await api.post(`/ai/model/train`, { activate });
  return data as AIModelOperationResponse;
}

export async function aiListModelVersions() {
  const { data } = await api.get(`/ai/model/versions`);
  return data as AIModelVersionsResponse;
}

export async function aiActivateModel(version: string) {
  const { data } = await api.post(`/ai/model/activate`, { version });
  return data as AIModelOperationResponse;
}

export async function aiRollbackModel(steps = 1) {
  const { data } = await api.post(`/ai/model/rollback`, { steps });
  return data as AIModelOperationResponse;
}

export async function aiReloadModels() {
  const { data } = await api.post(`/ai/model/reload`);
  return data as AIModelOperationResponse;
}

export async function aiDatasetStats() {
  const { data } = await api.get(`/ai/dataset/stats`);
  return data as AIDatasetStats;
}

export async function aiImportDataset(input: {
  datasetType: string;
  path: string;
  format?: string;
  delimiter?: string;
  maxRows?: number;
}) {
  const { data } = await api.post(`/ai/dataset/import-local`, input);
  return data as AIDatasetImportResponse;
}

export type AuditLogEntry = {
  id: string;
  actorUserId?: string;
  action?: string;
  entityType?: string;
  entityId?: string;
  ip?: string;
  userAgent?: string;
  metadata?: Record<string, unknown>;
  createdAt?: string;
};

export async function adminListAuditLogs(options?: {
  query?: string;
  actorUserId?: string;
  entityType?: string;
  limit?: number;
}) {
  const { data } = await api.get(`/admin/audit-logs`, {
    params: {
      query: options?.query,
      actorUserId: options?.actorUserId,
      entityType: options?.entityType,
      limit: options?.limit ?? 200,
    },
  });
  return data as AuditLogEntry[];
}

// User Search
/**
 * Get user by ID (primary search method)
 * Every user has a unique MongoDB ID that can be searched
 */
export async function getUserById(userId: string) {
  const { data } = await api.get(`/users/${userId}`);
  return data as AppUser;
}

/**
 * Search user by email
 * Returns single user if found
 */
export async function searchUserByEmail(email: string) {
  const { data } = await api.get(`/users/search/email`, { params: { email } });
  return data as AppUser;
}

/**
 * Search users by name (partial match)
 * Returns array of matching users (max 20 results)
 */
export async function searchUsersByName(name: string) {
  const { data } = await api.get(`/users/search/name`, { params: { name } });
  return data as { query: string; results: AppUser[]; count: number };
}

/**
 * List all users (limited to 100 by default)
 * Useful for admin panels and user discovery
 */
export async function listAllUsers(limit = 100) {
  const { data } = await api.get(`/users/list`, { params: { limit } });
  return data as { total: number; users: AppUser[] };
}
